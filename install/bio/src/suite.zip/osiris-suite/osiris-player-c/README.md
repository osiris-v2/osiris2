# Osiris Player (FFmpeg + SDL2, C)

Reproductor avanzado orientado a la red: User-Agent y cabeceras configurables, proxy, reconexión, resolución de enlaces con yt-dlp y probador de enlaces. Usa `../share-lib-sdl-c` y `../share-fonts`.

    cd osiris-player-c && ./build.sh        # requiere libav*-dev y SDL2 (ver ../install-deps.sh)
    ./build/osiris-player video.mp4 | https://…/lista.m3u8 | --net
    ./tests/run-tests.sh                    # suite completa (ffmpeg + python3)

Manual: `manual/index.html` (uso, red y yt-dlp, arquitectura, pruebas, problemas).
