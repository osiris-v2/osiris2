#!/usr/bin/env bash
# Compila el reproductor (usa ../share-lib-sdl-c y ../share-fonts). Requiere las librerías de desarrollo de FFmpeg.
set -e
cd "$(dirname "$0")"
[ -d ../share-lib-sdl-c ] || { echo "Falta ../share-lib-sdl-c: descomprime el paquete completo." >&2; exit 1; }
for p in libavformat libavcodec libswscale libswresample libavutil sdl2 SDL2_ttf; do
  pkg-config --exists $p || { echo "Falta $p (instala: libavformat-dev libavcodec-dev libswscale-dev libswresample-dev libavutil-dev libsdl2-dev libsdl2-ttf-dev)" >&2; exit 1; }
done
if command -v make >/dev/null; then make release
else cmake -S . -B build/cmake -DCMAKE_BUILD_TYPE=Release && cmake --build build/cmake && mkdir -p build && cp build/cmake/bin/osiris-player build/; fi
echo; echo "Ejecuta: ./build/osiris-player [fichero|URL ...]"
