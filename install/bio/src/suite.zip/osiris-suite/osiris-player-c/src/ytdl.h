/* ytdl.h - resolvedor de enlaces con yt-dlp (-J). Bloqueante: llámalo desde un hilo de trabajo. */
#ifndef PLAYER_YTDL_H
#define PLAYER_YTDL_H
#include "netopts.h"

typedef struct {
    char id[40], ext[16], protocol[28], note[72], vcodec[28], acodec[28];
    int w, h;
    double tbr, fps;
    char *url;
    ItemHdr hdr;                 /* User-Agent / Referer / cabeceras que yt-dlp asocia a ese formato */
    bool has_v, has_a;
} YtFormat;
typedef struct { char *url, *title; } YtEntry;
typedef struct {
    char title[256], webpage[512];
    YtFormat *f; int nf, best;   /* best: índice recomendado (-1 = ninguno) */
    YtEntry *entries; int ne;    /* si la URL es una lista */
    bool is_playlist;
} YtResult;

bool ytdl_resolve(const NetOptions *net, const char *url, YtResult **out, char *err, size_t ec);
void ytdl_free(YtResult *r);
void ytdl_format_label(const YtFormat *f, char *out, size_t n);
#endif
