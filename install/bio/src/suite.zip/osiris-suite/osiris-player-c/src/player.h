/* player.h - motor de reproducción (FFmpeg: avformat/avcodec/swscale/swresample + SDL2 audio/vídeo).
 * Hilos: demux, vídeo y audio. Reloj maestro = audio (o reloj de pared si no hay audio).
 * Todas las funciones son seguras entre hilos; pl_video_update() debe llamarse desde el hilo del renderer. */
#ifndef PLAYER_H
#define PLAYER_H
#include <SDL.h>
#include <stdbool.h>
#include <stddef.h>
#include "netopts.h"

typedef enum { PL_IDLE, PL_OPENING, PL_PLAYING, PL_PAUSED, PL_BUFFERING, PL_ENDED, PL_ERROR } PlState;
enum { PL_AUDIO = 1, PL_SUB = 2 };

typedef struct { int id; char lang[8], title[64], codec[24]; int channels, rate; bool selected, external; } PlTrack;
typedef struct {
    char format[48], vcodec[32], acodec[32], pixfmt[24], title[160];
    int w, h, sar_num, sar_den, achannels, arate;
    double fps, duration;
    long bitrate, vbitrate, abitrate;
    bool has_video, has_audio, seekable, live;
} PlInfo;
typedef struct {
    double clock, duration, av_diff;
    int dropped, decoded, vq_pkts, aq_pkts, fq_frames;
    size_t qbytes;
    bool buffering;
} PlStats;

typedef struct Player Player;
Player *pl_create(void);
void    pl_destroy(Player *p);
/* Abre de forma asíncrona (no bloquea). start: posición inicial en segundos. */
bool    pl_open(Player *p, const char *url, const NetOptions *net, const ItemHdr *item, double start);
void    pl_close(Player *p);
PlState pl_state(Player *p);
void    pl_error(Player *p, char *out, size_t n);        /* último error (si PL_ERROR) */
void    pl_pause(Player *p, int mode);                   /* 1 pausa, 0 reanuda, -1 alterna */
void    pl_seek(Player *p, double pos, bool relative);
double  pl_position(Player *p);
double  pl_duration(Player *p);                          /* 0 si es directo/desconocida */
void    pl_set_volume(Player *p, int pct);               /* 0..200 */
int     pl_volume(Player *p);
void    pl_set_mute(Player *p, bool m);
bool    pl_muted(Player *p);
void    pl_set_speed(Player *p, double s);               /* 0.25..4 (cambia el tono) */
double  pl_speed(Player *p);
void    pl_set_av_delay(Player *p, double s);            /* + = audio más tarde */
void    pl_set_sub_delay(Player *p, double s);           /* + = subtítulos más tarde */
double  pl_av_delay(Player *p);
double  pl_sub_delay(Player *p);
bool    pl_info(Player *p, PlInfo *out);                 /* false hasta que el fichero esté abierto */
int     pl_tracks(Player *p, int kind, PlTrack *out, int max);
void    pl_select_track(Player *p, int kind, int id);    /* id=-1 apaga subtítulos */
bool    pl_load_subtitle_file(Player *p, const char *path, char *err, size_t ec);   /* selecciona la nueva pista */
bool    pl_subtitle_text(Player *p, char *buf, size_t n);
void    pl_step_frame(Player *p);                        /* avanza un fotograma (en pausa) */
void    pl_stats(Player *p, PlStats *s);
/* Sube al renderer el fotograma que toca. *tex se crea/recrea según el tamaño. true si hay imagen válida. */
bool    pl_video_update(Player *p, SDL_Renderer *r, SDL_Texture **tex, int *w, int *h);
/* Sonda bloqueante de un enlace: escribe un informe legible. true si se pudo abrir. cancel: puntero a un flag para abortar. */
bool    pl_probe(const char *url, const NetOptions *net, const ItemHdr *item, char *report, size_t cap, volatile int *cancel);
#endif
