/* netopts.h - opciones de red del reproductor (User-Agent, cabeceras, proxy, reconexión...). Sin dependencias de FFmpeg. */
#ifndef PLAYER_NETOPTS_H
#define PLAYER_NETOPTS_H
#include <stdbool.h>
#include <stddef.h>
#include "osl/osl_json.h"

#define UA_COUNT 9
#define UA_CUSTOM 8
#define UA_FFMPEG 7
extern const char *const UA_NAMES[UA_COUNT];
extern const char *const UA_STRINGS[UA_COUNT];
enum { YTDL_NEVER = 0, YTDL_FALLBACK = 1, YTDL_ALWAYS = 2 };

typedef struct {
    int ua_preset;                       /* índice en UA_NAMES; UA_CUSTOM usa user_agent; UA_FFMPEG = el de FFmpeg */
    char user_agent[512];
    char referer[512];
    char headers[1024];                  /* "Nombre: valor | Otro: valor" */
    char cookies[1024];                  /* "a=1; b=2" */
    char proxy[256];                     /* http://host:puerto */
    char extra[512];                     /* opciones de FFmpeg "clave=valor;clave=valor" */
    char ytdlp[512];                     /* ruta de yt-dlp ("" = buscar en PATH) */
    char ytdl_args[256];                 /* argumentos extra de yt-dlp, p.ej. --cookies-from-browser firefox */
    int timeout_s, reconnect_max_s, probesize_kb, analyze_ms, buffer_mb, ytdl_mode;
    bool reconnect, tls_verify, low_latency;
} NetOptions;

/* Cabeceras específicas de una entrada (p.ej. las que devuelve yt-dlp); si no están vacías, mandan sobre las globales. */
typedef struct { char ua[512], referer[512], headers[1024]; } ItemHdr;

void net_defaults(NetOptions *n);
void net_load(NetOptions *n, const OslJson *o);          /* o puede ser NULL */
OslJson *net_save(const NetOptions *n);
/* Valores efectivos tras combinar preset/personalizado y entrada. ua vacío = el de FFmpeg. */
void net_effective(const NetOptions *n, const ItemHdr *it, char *ua, size_t uan, char *ref, size_t refn, char *hdr, size_t hdrn);
/* Comandos equivalentes (para depurar con otras herramientas). Escriben una línea de shell. */
void net_cmd_ffplay(const NetOptions *n, const ItemHdr *it, const char *url, char *out, size_t cap);
void net_cmd_mpv(const NetOptions *n, const ItemHdr *it, const char *url, char *out, size_t cap);
void net_cmd_curl(const NetOptions *n, const ItemHdr *it, const char *url, char *out, size_t cap);
void net_cmd_ytdlp(const NetOptions *n, const char *url, char *out, size_t cap);
#endif
