/* player.c - motor de reproducción. Un único mutex (p->mu) protege colas, anillo de audio, reloj y banderas;
 * los hilos esperan con p->cv (broadcast en cada cambio). Nunca se decodifica con el mutex tomado. */
#define _GNU_SOURCE
#include "player.h"
#include "osl/osl_safe.h"
#include <libavcodec/avcodec.h>
#include <libavformat/avformat.h>
#include <libavutil/avutil.h>
#include <libavutil/opt.h>
#include <libavutil/pixdesc.h>
#include <libavutil/time.h>
#include <libswresample/swresample.h>
#include <libswscale/swscale.h>
#include <math.h>
#include <pthread.h>
#include <stdatomic.h>

#if LIBAVUTIL_VERSION_INT >= AV_VERSION_INT(57, 24, 100)
#define NEW_CHLAYOUT 1                       /* API AVChannelLayout (FFmpeg >= 5.1) */
#endif

#define MAX_FQ 4
#define RING_SECONDS 0.4
#define DEV_RATE 48000
#define MAX_TRACKS 48

typedef struct PktNode { AVPacket *pkt; int serial; struct PktNode *next; } PktNode;
typedef struct { PktNode *head, *tail; int n; size_t bytes; } PQ;
typedef struct { AVFrame *f; double pts, dur; int serial; } VFrame;
typedef struct { double start, end; int track; char *text; } Cue;

struct Player {
    pthread_mutex_t mu;
    pthread_cond_t cv;
    pthread_t th_demux, th_video, th_audio;
    bool th_demux_on, th_video_on, th_audio_on;
    atomic_bool abort;
    PlState state;
    char err[320], url[2048];
    NetOptions net;
    ItemHdr item;
    double start_pos;
    int64_t open_deadline_us;
    /* FFmpeg */
    AVFormatContext *ic;
    AVStream *vst, *ast;
    AVCodecContext *vctx, *sctx;
    int vi, ai, si;                       /* streams actuales (si: -1 apagado, >=1000 externo) */
    double start_time;                    /* offset del contenedor (s) */
    PlInfo info;
    bool info_ok, seekable;
    PlTrack tracks[MAX_TRACKS];
    int ntracks;
    /* colas */
    PQ vq, aq;
    int serial;
    VFrame fq[MAX_FQ];
    int fq_r, fq_n;
    bool eof_demux, v_eof, a_eof;
    size_t qlimit;
    /* audio */
    SDL_AudioDeviceID adev;
    bool audio_active;
    int a_rate;
    double a_hw_delay;
    uint8_t *ring;
    size_t ring_sz, ring_r, ring_w, ring_n;
    uint64_t w_total, r_total;
    double ring_pts_end;
    uint32_t underrun_tick;
    atomic_int volume;
    atomic_bool mute;
    atomic_int speed_milli;               /* velocidad*1000 */
    /* reloj / control */
    bool paused;
    double vc_base_media;
    int64_t vc_base_wall;
    double seek_target;                   /* <0: sin descarte */
    bool need_first;
    int step_req;
    double last_vpts;
    bool seek_req, reconfig_req;
    double seek_pos;
    int ai_req, si_req;
    double av_delay, sub_delay;
    int dropped, decoded;
    /* subtítulos */
    Cue *cues; int ncues, capcues;
    int ext_count;
    char ext_name[8][64];
};

/* ---------------------------------------------------------------- utilidades */
static void set_error(Player *p, const char *fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    pthread_mutex_lock(&p->mu);
    vsnprintf(p->err, sizeof p->err, fmt, ap);
    p->state = PL_ERROR;
    pthread_cond_broadcast(&p->cv);
    pthread_mutex_unlock(&p->mu);
    va_end(ap);
}
static void errstr(int e, char *buf, size_t n) { av_strerror(e, buf, n); }
static int intr_cb(void *o) {
    Player *p = (Player *)o;
    return atomic_load(&p->abort) || (p->open_deadline_us && av_gettime_relative() > p->open_deadline_us);
}
static double speed_of(Player *p) { return atomic_load(&p->speed_milli) / 1000.0; }

/* ----------------------------------------------------------- colas de paquetes */
static void pq_put(Player *p, PQ *q, AVPacket *pkt, int serial) {   /* pkt NULL = marca de fin de fichero */
    PktNode *n = (PktNode *)safe_calloc(1, sizeof *n);
    n->pkt = pkt ? pkt : av_packet_alloc();
    n->serial = serial;
    pthread_mutex_lock(&p->mu);
    if (q->tail) q->tail->next = n; else q->head = n;
    q->tail = n; q->n++; q->bytes += (size_t)n->pkt->size;
    pthread_cond_broadcast(&p->cv);
    pthread_mutex_unlock(&p->mu);
}
static int pq_get(Player *p, PQ *q, AVPacket **out, int *serial) {
    pthread_mutex_lock(&p->mu);
    while (!q->head && !atomic_load(&p->abort)) pthread_cond_wait(&p->cv, &p->mu);
    if (atomic_load(&p->abort)) { pthread_mutex_unlock(&p->mu); return -1; }
    PktNode *n = q->head;
    q->head = n->next;
    if (!q->head) q->tail = NULL;
    q->n--; q->bytes -= (size_t)n->pkt->size;
    pthread_cond_broadcast(&p->cv);
    pthread_mutex_unlock(&p->mu);
    *out = n->pkt; *serial = n->serial;
    free(n);
    return 0;
}
static void pq_flush(PQ *q) {                       /* con p->mu tomado */
    for (PktNode *n = q->head, *nx; n; n = nx) { nx = n->next; av_packet_free(&n->pkt); free(n); }
    memset(q, 0, sizeof *q);
}

/* ------------------------------------------------------------------- reloj */
static double clock_now(Player *p) {               /* con mu tomado */
    if (p->audio_active) {
        double buffered = (double)(p->w_total - p->r_total) / ((double)p->a_rate * 4.0);
        return p->ring_pts_end - (buffered + p->a_hw_delay) * speed_of(p);
    }
    if (p->paused) return p->vc_base_media;
    return p->vc_base_media + (double)(av_gettime_relative() - p->vc_base_wall) / 1e6 * speed_of(p);
}
static void clock_rebase(Player *p) {               /* fija el reloj de pared al valor actual */
    p->vc_base_media = clock_now(p);
    p->vc_base_wall = av_gettime_relative();
}

/* Reinicia toda la tubería (seek o cambio de pista). target<0: sin descartar fotogramas. con mu NO tomado */
static void flush_pipeline(Player *p, double newpos, bool target_valid) {
    pthread_mutex_lock(&p->mu);
    p->serial++;
    pq_flush(&p->vq); pq_flush(&p->aq);
    for (int i = 0; i < p->fq_n; i++) av_frame_free(&p->fq[(p->fq_r + i) % MAX_FQ].f);
    p->fq_n = 0; p->fq_r = 0;
    p->ring_r = p->ring_w = p->ring_n = 0; p->w_total = p->r_total = 0;
    p->ring_pts_end = newpos;
    int k = 0;                                       /* se descartan los subtítulos embebidos; los externos (>=1000) se conservan */
    for (int i = 0; i < p->ncues; i++) { if (p->cues[i].track >= 1000) p->cues[k++] = p->cues[i]; else free(p->cues[i].text); }
    p->ncues = k;
    p->seek_target = target_valid ? newpos : -1;
    p->need_first = true;
    p->vc_base_media = newpos; p->vc_base_wall = av_gettime_relative();
    p->eof_demux = p->v_eof = p->a_eof = false;
    pthread_cond_broadcast(&p->cv);
    pthread_mutex_unlock(&p->mu);
}

/* ------------------------------------------------------------- subtítulos */
static void cue_add(Player *p, double start, double end, int track, const char *text) {
    if (!text || !*text) return;
    pthread_mutex_lock(&p->mu);
    for (int i = p->ncues - 1; i >= 0 && i >= p->ncues - 8; i--)
        if (p->cues[i].track == track && fabs(p->cues[i].start - start) < 0.001 && !strcmp(p->cues[i].text, text)) { pthread_mutex_unlock(&p->mu); return; }
    if (p->ncues == p->capcues) { p->capcues = p->capcues ? p->capcues * 2 : 64; p->cues = (Cue *)safe_reallocarray(p->cues, (size_t)p->capcues, sizeof *p->cues); }
    p->cues[p->ncues++] = (Cue){start, end, track, safe_strdup(text)};
    pthread_mutex_unlock(&p->mu);
}
/* "ReadOrder,Layer,Style,Name,MarginL,MarginR,MarginV,Effect,Text" -> texto plano */
static char *ass_to_text(const char *ass) {
    const char *t = ass;
    int commas = 0;
    while (*t && commas < 8) { if (*t == ',') commas++; t++; }
    if (commas < 8) t = ass;
    SBuf b = {0};
    for (; *t; t++) {
        if (*t == '{') { while (*t && *t != '}') t++; if (!*t) break; continue; }
        if (*t == '\\' && (t[1] == 'N' || t[1] == 'n')) { sb_push(&b, '\n'); t++; continue; }
        if (*t == '\\' && t[1] == 'h') { sb_push(&b, ' '); t++; continue; }
        sb_push(&b, *t);
    }
    return sb_take(&b);
}
static void decode_sub_packet(Player *p, AVCodecContext *c, AVStream *st, AVPacket *pkt, int track, double offset) {
    AVSubtitle sub;
    int got = 0;
    if (avcodec_decode_subtitle2(c, &sub, &got, pkt) < 0 || !got) return;
    double base = pkt->pts != AV_NOPTS_VALUE ? pkt->pts * av_q2d(st->time_base) - offset
                : (sub.pts != AV_NOPTS_VALUE ? (double)sub.pts / AV_TIME_BASE - offset : 0);
    double start = base + sub.start_display_time / 1000.0, end;
    if (sub.end_display_time > sub.start_display_time) end = base + sub.end_display_time / 1000.0;
    else if (pkt->duration > 0) end = base + pkt->duration * av_q2d(st->time_base);
    else end = start + 3.0;
    SBuf txt = {0};
    for (unsigned i = 0; i < sub.num_rects; i++) {
        AVSubtitleRect *r = sub.rects[i];
        char *t = NULL;
        if (r->type == SUBTITLE_ASS && r->ass) t = ass_to_text(r->ass);
        else if (r->type == SUBTITLE_TEXT && r->text) t = safe_strdup(r->text);
        if (t) { if (txt.len) sb_push(&txt, '\n'); sb_str(&txt, t); free(t); }
    }
    avsubtitle_free(&sub);
    if (txt.len) cue_add(p, start, end, track, txt.d);
    sb_free(&txt);
}
static AVCodecContext *open_decoder(AVStream *st, int threads) {
    const AVCodec *codec = avcodec_find_decoder(st->codecpar->codec_id);
    if (!codec) return NULL;
    AVCodecContext *c = avcodec_alloc_context3(codec);
    if (!c) return NULL;
    avcodec_parameters_to_context(c, st->codecpar);
    c->pkt_timebase = st->time_base;
    if (threads) { c->thread_count = 0; c->thread_type = FF_THREAD_FRAME | FF_THREAD_SLICE; }
    if (avcodec_open2(c, codec, NULL) < 0) { avcodec_free_context(&c); return NULL; }
    return c;
}

bool pl_load_subtitle_file(Player *p, const char *path, char *err, size_t ec) {
    AVFormatContext *ic = NULL;
    int r = avformat_open_input(&ic, path, NULL, NULL);
    if (r < 0) { errstr(r, err, ec); return false; }
    avformat_find_stream_info(ic, NULL);
    int si = av_find_best_stream(ic, AVMEDIA_TYPE_SUBTITLE, -1, -1, NULL, 0);
    if (si < 0) { avformat_close_input(&ic); snprintf(err, ec, "el fichero no contiene subtítulos de texto"); return false; }
    AVCodecContext *c = open_decoder(ic->streams[si], 0);
    if (!c) { avformat_close_input(&ic); snprintf(err, ec, "no hay decodificador para esos subtítulos"); return false; }
    pthread_mutex_lock(&p->mu);
    int id = 1000 + p->ext_count;
    if (p->ext_count >= 8) { pthread_mutex_unlock(&p->mu); avcodec_free_context(&c); avformat_close_input(&ic); snprintf(err, ec, "demasiados subtítulos externos"); return false; }
    safe_strlcpy(p->ext_name[p->ext_count], strrchr(path, '/') ? strrchr(path, '/') + 1 : path, 64);
    p->ext_count++;
    pthread_mutex_unlock(&p->mu);
    AVPacket *pkt = av_packet_alloc();
    while (av_read_frame(ic, pkt) >= 0) {
        if (pkt->stream_index == si) decode_sub_packet(p, c, ic->streams[si], pkt, id, 0);
        av_packet_unref(pkt);
    }
    av_packet_free(&pkt); avcodec_free_context(&c); avformat_close_input(&ic);
    pl_select_track(p, PL_SUB, id);
    return true;
}

/* ---------------------------------------------------------------- opciones */
static void build_opts(AVDictionary **d, const NetOptions *n, const ItemHdr *it, const char *url) {
    char ua[512], ref[512], hdr[2048];
    net_effective(n, it, ua, sizeof ua, ref, sizeof ref, hdr, sizeof hdr);
    bool http = !strncmp(url, "http://", 7) || !strncmp(url, "https://", 8);
    if (http) {
        if (ua[0]) av_dict_set(d, "user_agent", ua, 0);
        if (ref[0]) av_dict_set(d, "referer", ref, 0);
        if (hdr[0]) {
            SBuf h = {0};
            safe_ptr(char) cp = safe_strdup(hdr);
            for (char *s = cp; s && *s;) {
                char *e = strstr(s, " | ");
                if (e) *e = 0;
                while (*s == ' ') s++;
                if (*s) { sb_str(&h, s); sb_str(&h, "\r\n"); }
                s = e ? e + 3 : NULL;
            }
            if (h.d) av_dict_set(d, "headers", h.d, 0);
            sb_free(&h);
        }
        if (n->proxy[0]) av_dict_set(d, "http_proxy", n->proxy, 0);
        if (n->reconnect) {
            av_dict_set(d, "reconnect", "1", 0); av_dict_set(d, "reconnect_streamed", "1", 0);
            av_dict_set_int(d, "reconnect_delay_max", n->reconnect_max_s, 0);
        }
        av_dict_set(d, "tls_verify", n->tls_verify ? "1" : "0", 0);
        av_dict_set(d, "multiple_requests", "1", 0);
        av_dict_set(d, "allowed_extensions", "ALL", 0);            /* HLS con segmentos de extensión rara */
    }
    av_dict_set_int(d, "rw_timeout", (int64_t)n->timeout_s * 1000000, 0);
    av_dict_set_int(d, "timeout", (int64_t)n->timeout_s * 1000000, 0);
    av_dict_set_int(d, "probesize", (int64_t)n->probesize_kb * 1024, 0);
    av_dict_set_int(d, "analyzeduration", (int64_t)n->analyze_ms * 1000, 0);
    if (n->low_latency) { av_dict_set(d, "fflags", "nobuffer", 0); av_dict_set(d, "flags", "low_delay", 0); }
    av_dict_set(d, "protocol_whitelist", "file,http,https,tcp,tls,crypto,data,udp,rtp,rtsp,rtmp", 0);
    if (n->extra[0]) {                                             /* "clave=valor;clave=valor" */
        safe_ptr(char) cp = safe_strdup(n->extra);
        char *sv = NULL;
        for (char *t = strtok_r(cp, ";", &sv); t; t = strtok_r(NULL, ";", &sv)) {
            char *eq = strchr(t, '=');
            if (!eq) continue;
            *eq = 0;
            while (*t == ' ') t++;
            if (*t) av_dict_set(d, t, eq + 1, 0);
        }
    }
}

/* -------------------------------------------------------------- audio (SDL) */
static void audio_cb(void *ud, Uint8 *stream, int len) {
    Player *p = (Player *)ud;
    pthread_mutex_lock(&p->mu);
    size_t n = p->ring_n < (size_t)len ? p->ring_n : (size_t)len;
    size_t first = p->ring_sz - p->ring_r < n ? p->ring_sz - p->ring_r : n;
    memcpy(stream, p->ring + p->ring_r, first);
    if (n > first) memcpy(stream + first, p->ring, n - first);
    p->ring_r = (p->ring_r + n) % p->ring_sz;
    p->ring_n -= n;
    p->r_total += n;
    if (n < (size_t)len) { memset(stream + n, 0, (size_t)len - n); if (!p->a_eof) p->underrun_tick = SDL_GetTicks(); }
    pthread_cond_broadcast(&p->cv);
    pthread_mutex_unlock(&p->mu);
    int vol = atomic_load(&p->volume);
    if (atomic_load(&p->mute)) vol = 0;
    if (vol != 100) {
        int16_t *s = (int16_t *)stream;
        for (int i = 0; i < len / 2; i++) { int v = s[i] * vol / 100; s[i] = (int16_t)(v > 32767 ? 32767 : v < -32768 ? -32768 : v); }
    }
}
static bool audio_device_open(Player *p) {
    SDL_AudioSpec want, have;
    SDL_zero(want);
    want.freq = DEV_RATE; want.format = AUDIO_S16SYS; want.channels = 2; want.samples = 1024; want.callback = audio_cb; want.userdata = p;
    p->adev = SDL_OpenAudioDevice(NULL, 0, &want, &have, SDL_AUDIO_ALLOW_FREQUENCY_CHANGE);
    if (!p->adev) return false;
    if (have.format != AUDIO_S16SYS || have.channels != 2) { SDL_CloseAudioDevice(p->adev); p->adev = 0; return false; }
    p->a_rate = have.freq;
    p->a_hw_delay = (double)have.samples / have.freq;
    p->ring_sz = (size_t)(p->a_rate * 4 * RING_SECONDS);
    p->ring = (uint8_t *)safe_malloc(p->ring_sz);
    return true;
}

/* ------------------------------------------------------------- hilo de vídeo */
static void push_frame(Player *p, AVFrame *f, double pts, double dur, int serial) {
    pthread_mutex_lock(&p->mu);
    while (p->fq_n == MAX_FQ && !atomic_load(&p->abort) && serial == p->serial) pthread_cond_wait(&p->cv, &p->mu);
    if (atomic_load(&p->abort) || serial != p->serial) { pthread_mutex_unlock(&p->mu); av_frame_free(&f); return; }
    p->fq[(p->fq_r + p->fq_n) % MAX_FQ] = (VFrame){f, pts, dur, serial};
    p->fq_n++;
    pthread_cond_broadcast(&p->cv);
    pthread_mutex_unlock(&p->mu);
}
static void *video_main(void *arg) {
    Player *p = (Player *)arg;
    AVFrame *fr = av_frame_alloc();
    struct SwsContext *sws = NULL;
    int my = -1;
    double fps = p->info.fps > 1 ? p->info.fps : 25, last = 0;
    AVPacket *pkt;
    int ps;
    while (pq_get(p, &p->vq, &pkt, &ps) == 0) {
        pthread_mutex_lock(&p->mu);
        bool stale = ps != p->serial;
        pthread_mutex_unlock(&p->mu);
        if (stale) { av_packet_free(&pkt); continue; }
        if (ps != my) { avcodec_flush_buffers(p->vctx); my = ps; }
        bool eof = !pkt->data;
        avcodec_send_packet(p->vctx, eof ? NULL : pkt);
        av_packet_free(&pkt);
        while (avcodec_receive_frame(p->vctx, fr) == 0) {
            double pts = fr->best_effort_timestamp != AV_NOPTS_VALUE ? fr->best_effort_timestamp * av_q2d(p->vst->time_base) - p->start_time : last + 1.0 / fps;
            last = pts;
            pthread_mutex_lock(&p->mu);
            p->decoded++;
            bool skip = my != p->serial || (p->seek_target >= 0 && pts < p->seek_target - 0.5 / fps);
            pthread_mutex_unlock(&p->mu);
            if (!skip) {
                AVFrame *out;
                if (fr->format == AV_PIX_FMT_YUV420P) out = av_frame_clone(fr);
                else {
                    out = av_frame_alloc();
                    out->format = AV_PIX_FMT_YUV420P; out->width = fr->width; out->height = fr->height;
                    av_frame_get_buffer(out, 32);
                    sws = sws_getCachedContext(sws, fr->width, fr->height, (enum AVPixelFormat)fr->format, fr->width, fr->height, AV_PIX_FMT_YUV420P, SWS_BILINEAR, NULL, NULL, NULL);
                    if (sws) sws_scale(sws, (const uint8_t *const *)fr->data, fr->linesize, 0, fr->height, out->data, out->linesize);
                }
                push_frame(p, out, pts, 1.0 / fps, my);
            }
            av_frame_unref(fr);
        }
        if (eof) { pthread_mutex_lock(&p->mu); if (my == p->serial) p->v_eof = true; pthread_cond_broadcast(&p->cv); pthread_mutex_unlock(&p->mu); }
    }
    sws_freeContext(sws);
    av_frame_free(&fr);
    return NULL;
}

/* ------------------------------------------------------------- hilo de audio */
static SwrContext *make_swr(const AVFrame *f, int out_rate) {
    SwrContext *s = NULL;
#ifdef NEW_CHLAYOUT
    AVChannelLayout out, in;
    av_channel_layout_default(&out, 2);
    if (f->ch_layout.nb_channels > 0 && f->ch_layout.order != AV_CHANNEL_ORDER_UNSPEC) av_channel_layout_copy(&in, &f->ch_layout);
    else av_channel_layout_default(&in, f->ch_layout.nb_channels > 0 ? f->ch_layout.nb_channels : 2);
    int r = swr_alloc_set_opts2(&s, &out, AV_SAMPLE_FMT_S16, out_rate, &in, (enum AVSampleFormat)f->format, f->sample_rate, 0, NULL);
    av_channel_layout_uninit(&in); av_channel_layout_uninit(&out);
    if (r < 0) return NULL;
#else
    int64_t inl = f->channel_layout ? (int64_t)f->channel_layout : av_get_default_channel_layout(f->channels);
    s = swr_alloc_set_opts(NULL, AV_CH_LAYOUT_STEREO, AV_SAMPLE_FMT_S16, out_rate, inl, (enum AVSampleFormat)f->format, f->sample_rate, 0, NULL);
    if (!s) return NULL;
#endif
    if (swr_init(s) < 0) swr_free(&s);
    return s;
}
static void ring_write(Player *p, const uint8_t *data, size_t bytes, int serial, double pts0, double dur) {
    size_t done = 0;
    while (done < bytes) {
        pthread_mutex_lock(&p->mu);
        while (p->ring_n == p->ring_sz && !atomic_load(&p->abort) && serial == p->serial) pthread_cond_wait(&p->cv, &p->mu);
        if (atomic_load(&p->abort) || serial != p->serial) { pthread_mutex_unlock(&p->mu); return; }
        size_t chunk = p->ring_sz - p->ring_n < bytes - done ? p->ring_sz - p->ring_n : bytes - done;
        size_t first = p->ring_sz - p->ring_w < chunk ? p->ring_sz - p->ring_w : chunk;
        memcpy(p->ring + p->ring_w, data + done, first);
        if (chunk > first) memcpy(p->ring, data + done + first, chunk - first);
        p->ring_w = (p->ring_w + chunk) % p->ring_sz;
        p->ring_n += chunk; p->w_total += chunk;
        done += chunk;
        p->ring_pts_end = pts0 + dur * (double)done / (double)bytes;
        pthread_cond_broadcast(&p->cv);
        pthread_mutex_unlock(&p->mu);
    }
}
static void *audio_main(void *arg) {
    Player *p = (Player *)arg;
    AVFrame *fr = av_frame_alloc();
    AVCodecContext *ctx = NULL;
    SwrContext *swr = NULL;
    int ctx_stream = -1, my = -1, sw_rate = 0, sw_fmt = -1, sw_ch = 0, sw_speed = 0;
    uint8_t *buf = NULL;
    size_t bufsz = 0;
    double next_pts = 0;
    AVPacket *pkt;
    int ps;
    while (pq_get(p, &p->aq, &pkt, &ps) == 0) {
        pthread_mutex_lock(&p->mu);
        bool stale = ps != p->serial;
        int want = p->ai;
        pthread_mutex_unlock(&p->mu);
        if (stale) { av_packet_free(&pkt); continue; }
        if (ps != my || want != ctx_stream) {                     /* tras un seek o cambio de pista */
            if (want != ctx_stream || !ctx) {
                avcodec_free_context(&ctx);
                ctx = open_decoder(p->ic->streams[want], 0);
                ctx_stream = want;
                p->ast = p->ic->streams[want];
            } else avcodec_flush_buffers(ctx);
            if (swr) swr_free(&swr);
            my = ps; next_pts = -1;
        }
        if (!ctx) { av_packet_free(&pkt); continue; }
        bool eof = !pkt->data;
        avcodec_send_packet(ctx, eof ? NULL : pkt);
        av_packet_free(&pkt);
        while (avcodec_receive_frame(ctx, fr) == 0) {
            int spd = atomic_load(&p->speed_milli);
            int ch = 
#ifdef NEW_CHLAYOUT
                fr->ch_layout.nb_channels;
#else
                fr->channels;
#endif
            if (!swr || sw_rate != fr->sample_rate || sw_fmt != fr->format || sw_ch != ch || sw_speed != spd) {
                if (swr) swr_free(&swr);
                swr = make_swr(fr, (int)((double)p->a_rate * 1000.0 / spd));   /* velocidad = remuestreo (cambia el tono) */
                sw_rate = fr->sample_rate; sw_fmt = fr->format; sw_ch = ch; sw_speed = spd;
            }
            if (!swr) { av_frame_unref(fr); continue; }
            double dur = (double)fr->nb_samples / fr->sample_rate;
            double pts = fr->best_effort_timestamp != AV_NOPTS_VALUE ? fr->best_effort_timestamp * av_q2d(ctx->pkt_timebase) - p->start_time : (next_pts >= 0 ? next_pts : 0);
            next_pts = pts + dur;
            pthread_mutex_lock(&p->mu);
            bool skip = my != p->serial || (p->seek_target >= 0 && pts + dur < p->seek_target);
            pthread_mutex_unlock(&p->mu);
            if (!skip) {
                int out_max = swr_get_out_samples(swr, fr->nb_samples) + 64;
                if ((size_t)out_max * 4 > bufsz) { bufsz = (size_t)out_max * 4; buf = (uint8_t *)safe_realloc(buf, bufsz); }
                int n = swr_convert(swr, &buf, out_max, (const uint8_t **)fr->extended_data, fr->nb_samples);
                if (n > 0) ring_write(p, buf, (size_t)n * 4, my, pts, dur);
            }
            av_frame_unref(fr);
        }
        if (eof) { pthread_mutex_lock(&p->mu); if (my == p->serial) p->a_eof = true; pthread_cond_broadcast(&p->cv); pthread_mutex_unlock(&p->mu); }
    }
    free(buf);
    if (swr) swr_free(&swr);
    avcodec_free_context(&ctx);
    av_frame_free(&fr);
    return NULL;
}

/* ------------------------------------------------------------ hilo de demux */
static void fill_info(Player *p) {
    AVFormatContext *ic = p->ic;
    PlInfo *i = &p->info;
    memset(i, 0, sizeof *i);
    safe_strlcpy(i->format, ic->iformat ? ic->iformat->name : "?", sizeof i->format);
    i->duration = ic->duration != AV_NOPTS_VALUE ? (double)ic->duration / AV_TIME_BASE : 0;
    i->live = ic->duration == AV_NOPTS_VALUE || (ic->pb && !(ic->pb->seekable & AVIO_SEEKABLE_NORMAL) && i->duration <= 0);
    i->seekable = p->seekable;
    i->bitrate = (long)ic->bit_rate;
    AVDictionaryEntry *t = av_dict_get(ic->metadata, "title", NULL, 0);
    if (t) safe_strlcpy(i->title, t->value, sizeof i->title);
    if (p->vst) {
        AVCodecParameters *c = p->vst->codecpar;
        i->has_video = true; i->w = c->width; i->h = c->height;
        i->sar_num = c->sample_aspect_ratio.num; i->sar_den = c->sample_aspect_ratio.den;
        AVRational fr = av_guess_frame_rate(ic, p->vst, NULL);
        i->fps = fr.den ? av_q2d(fr) : 0;
        safe_strlcpy(i->vcodec, avcodec_get_name(c->codec_id), sizeof i->vcodec);
        const char *pf = av_get_pix_fmt_name((enum AVPixelFormat)c->format);
        safe_strlcpy(i->pixfmt, pf ? pf : "?", sizeof i->pixfmt);
        i->vbitrate = (long)c->bit_rate;
    }
    if (p->ast) {
        AVCodecParameters *c = p->ast->codecpar;
        i->has_audio = true; i->arate = c->sample_rate; i->abitrate = (long)c->bit_rate;
        i->achannels =
#ifdef NEW_CHLAYOUT
            c->ch_layout.nb_channels;
#else
            c->channels;
#endif
        safe_strlcpy(i->acodec, avcodec_get_name(c->codec_id), sizeof i->acodec);
    }
    p->ntracks = 0;
    for (unsigned k = 0; k < ic->nb_streams && p->ntracks < MAX_TRACKS; k++) {
        AVStream *s = ic->streams[k];
        if (s->codecpar->codec_type != AVMEDIA_TYPE_AUDIO && s->codecpar->codec_type != AVMEDIA_TYPE_SUBTITLE) continue;
        PlTrack *tr = &p->tracks[p->ntracks++];
        memset(tr, 0, sizeof *tr);
        tr->id = (int)k;
        AVDictionaryEntry *l = av_dict_get(s->metadata, "language", NULL, 0), *ti = av_dict_get(s->metadata, "title", NULL, 0);
        if (l) safe_strlcpy(tr->lang, l->value, sizeof tr->lang);
        if (ti) safe_strlcpy(tr->title, ti->value, sizeof tr->title);
        safe_strlcpy(tr->codec, avcodec_get_name(s->codecpar->codec_id), sizeof tr->codec);
        tr->rate = s->codecpar->sample_rate;
        tr->channels =
#ifdef NEW_CHLAYOUT
            s->codecpar->ch_layout.nb_channels;
#else
            s->codecpar->channels;
#endif
        tr->external = s->codecpar->codec_type == AVMEDIA_TYPE_SUBTITLE ? false : false;
    }
    p->info_ok = true;
}

static bool is_text_sub(AVStream *s) {
    const AVCodecDescriptor *d = avcodec_descriptor_get(s->codecpar->codec_id);
    return d && (d->props & AV_CODEC_PROP_TEXT_SUB);
}

static void apply_reconfig(Player *p) {                 /* hilo demux */
    pthread_mutex_lock(&p->mu);
    int ai = p->ai_req, si = p->si_req;
    double pos = clock_now(p);
    bool changed_a = (ai >= 0 && ai != p->ai && p->audio_active);
    p->reconfig_req = false;
    if (changed_a) p->ai = ai;
    pthread_mutex_unlock(&p->mu);
    if (si != p->si || changed_a) {
        if (si != p->si) {
            if (p->sctx) avcodec_free_context(&p->sctx);
            p->si = si;
            if (si >= 0 && si < 1000) { p->sctx = open_decoder(p->ic->streams[si], 0); if (!p->sctx) p->si = -1; }
        }
        bool need_refill = changed_a || (p->si >= 0 && p->si < 1000);   /* audio nuevo o subtítulos embebidos: hay que releer */
        if (need_refill && p->seekable) {                               /* el demuxer pudo haber leído ya hasta el final: se vuelve a la posición actual */
            pthread_mutex_lock(&p->mu); p->seek_req = true; p->seek_pos = pos; pthread_mutex_unlock(&p->mu);
        } else if (changed_a) flush_pipeline(p, pos, false);
    }
}

static void *demux_main(void *arg) {
    Player *p = (Player *)arg;
    char eb[160];
    AVDictionary *opts = NULL;
    p->ic = avformat_alloc_context();
    p->ic->interrupt_callback.callback = intr_cb;
    p->ic->interrupt_callback.opaque = p;
    build_opts(&opts, &p->net, &p->item, p->url);
    p->open_deadline_us = av_gettime_relative() + (int64_t)(p->net.timeout_s * 3 + 10) * 1000000;
    int r = avformat_open_input(&p->ic, p->url, NULL, &opts);
    av_dict_free(&opts);
    if (r < 0) { errstr(r, eb, sizeof eb); if (!atomic_load(&p->abort)) set_error(p, "No se pudo abrir: %s", eb); return NULL; }
    r = avformat_find_stream_info(p->ic, NULL);
    p->open_deadline_us = 0;
    if (r < 0) { errstr(r, eb, sizeof eb); if (!atomic_load(&p->abort)) set_error(p, "No se pudo analizar el flujo: %s", eb); return NULL; }
    AVFormatContext *ic = p->ic;
    p->start_time = ic->start_time != AV_NOPTS_VALUE ? (double)ic->start_time / AV_TIME_BASE : 0;
    p->seekable = ic->pb && (ic->pb->seekable & AVIO_SEEKABLE_NORMAL) && ic->duration != AV_NOPTS_VALUE;
    int vi = av_find_best_stream(ic, AVMEDIA_TYPE_VIDEO, -1, -1, NULL, 0);
    int ai = av_find_best_stream(ic, AVMEDIA_TYPE_AUDIO, -1, -1, NULL, 0);
    AVStream *vst = NULL, *ast = NULL;
    AVCodecContext *vctx = NULL;
    bool aon = false;
    for (unsigned k = 0; k < ic->nb_streams; k++) ic->streams[k]->discard = AVDISCARD_ALL;
    if (vi >= 0) {
        vst = ic->streams[vi];
        if (vst->disposition & AV_DISPOSITION_ATTACHED_PIC) vi = -1;             /* carátulas: se ignoran */
    }
    if (vi >= 0) { vctx = open_decoder(vst, 1); if (!vctx) vi = -1; else vst->discard = AVDISCARD_DEFAULT; }
    if (vi < 0) vst = NULL;
    if (ai >= 0) {
        if (audio_device_open(p)) { aon = true; ast = ic->streams[ai]; ast->discard = AVDISCARD_DEFAULT; }
        else ai = -1;
    }
    if (vi < 0 && ai < 0) { avcodec_free_context(&vctx); set_error(p, "El enlace no contiene audio ni vídeo reproducibles"); return NULL; }
    pthread_mutex_lock(&p->mu);                       /* se publica todo de una vez: otros hilos leen estos campos con el mutex */
    p->vi = vi; p->ai = ai; p->vst = vst; p->ast = ast; p->vctx = vctx; p->audio_active = aon;
    pthread_mutex_unlock(&p->mu);
    for (unsigned k = 0; k < ic->nb_streams; k++) if (ic->streams[k]->codecpar->codec_type == AVMEDIA_TYPE_SUBTITLE && is_text_sub(ic->streams[k])) ic->streams[k]->discard = AVDISCARD_DEFAULT;
    p->qlimit = (size_t)p->net.buffer_mb * 1024 * 1024;
    pthread_mutex_lock(&p->mu);
    fill_info(p);
    pthread_mutex_unlock(&p->mu);
    p->si = -1; p->si_req = -1; p->ai_req = p->ai;
    if (p->vi >= 0) { pthread_create(&p->th_video, NULL, video_main, p); p->th_video_on = true; }
    if (p->audio_active) { pthread_create(&p->th_audio, NULL, audio_main, p); p->th_audio_on = true; SDL_PauseAudioDevice(p->adev, p->paused ? 1 : 0); }
    pthread_mutex_lock(&p->mu);
    p->vc_base_wall = av_gettime_relative();
    p->state = PL_PLAYING;
    if (p->start_pos > 1 && p->seekable) { p->seek_req = true; p->seek_pos = p->start_pos; }
    pthread_mutex_unlock(&p->mu);

    AVPacket *pkt = av_packet_alloc();
    int read_errs = 0;
    while (!atomic_load(&p->abort)) {
        pthread_mutex_lock(&p->mu);
        bool sreq = p->seek_req, rcfg = p->reconfig_req;
        double spos = p->seek_pos;
        pthread_mutex_unlock(&p->mu);
        if (rcfg) { apply_reconfig(p); continue; }
        if (sreq) {
            if (spos < 0) spos = 0;
            if (p->info.duration > 0 && spos > p->info.duration) spos = p->info.duration;
            int64_t ts = (int64_t)((spos + p->start_time) * AV_TIME_BASE);
            int sr = av_seek_frame(ic, -1, ts, AVSEEK_FLAG_BACKWARD);
            if (sr < 0) { errstr(sr, eb, sizeof eb); }
            if (p->sctx) avcodec_flush_buffers(p->sctx);
            flush_pipeline(p, spos, true);
            pthread_mutex_lock(&p->mu); p->seek_req = false; pthread_mutex_unlock(&p->mu);
            continue;
        }
        pthread_mutex_lock(&p->mu);
        bool full = (p->vq.bytes + p->aq.bytes) > p->qlimit || p->eof_demux;
        if (full) { struct timespec ts; clock_gettime(CLOCK_REALTIME, &ts); ts.tv_nsec += 20 * 1000000; if (ts.tv_nsec >= 1000000000) { ts.tv_sec++; ts.tv_nsec -= 1000000000; } pthread_cond_timedwait(&p->cv, &p->mu, &ts); }
        pthread_mutex_unlock(&p->mu);
        if (full) continue;
        r = av_read_frame(ic, pkt);
        if (r < 0) {
            if (r == AVERROR_EOF || avio_feof(ic->pb)) {
                pthread_mutex_lock(&p->mu); p->eof_demux = true; int ser = p->serial; pthread_mutex_unlock(&p->mu);
                if (p->vi >= 0) pq_put(p, &p->vq, NULL, ser); else { pthread_mutex_lock(&p->mu); p->v_eof = true; pthread_mutex_unlock(&p->mu); }
                if (p->audio_active) pq_put(p, &p->aq, NULL, ser); else { pthread_mutex_lock(&p->mu); p->a_eof = true; pthread_mutex_unlock(&p->mu); }
            } else if (++read_errs > 25) { errstr(r, eb, sizeof eb); set_error(p, "Error de lectura: %s", eb); break; }
            else av_usleep(200000);
            continue;
        }
        read_errs = 0;
        pthread_mutex_lock(&p->mu); int ser = p->serial; int ai = p->ai, si = p->si; pthread_mutex_unlock(&p->mu);
        if (pkt->stream_index == p->vi && p->vi >= 0) { AVPacket *c = av_packet_alloc(); av_packet_move_ref(c, pkt); pq_put(p, &p->vq, c, ser); }
        else if (pkt->stream_index == ai && p->audio_active) { AVPacket *c = av_packet_alloc(); av_packet_move_ref(c, pkt); pq_put(p, &p->aq, c, ser); }
        else if (pkt->stream_index == si && p->sctx) { decode_sub_packet(p, p->sctx, ic->streams[si], pkt, si, p->start_time); av_packet_unref(pkt); }
        else av_packet_unref(pkt);
    }
    av_packet_free(&pkt);
    return NULL;
}

/* ------------------------------------------------------------------ API */
Player *pl_create(void) {
    static bool init;
    if (!init) { SDL_InitSubSystem(SDL_INIT_AUDIO); init = true; }
    Player *p = (Player *)safe_calloc(1, sizeof *p);
    pthread_mutex_init(&p->mu, NULL);
    pthread_cond_init(&p->cv, NULL);
    atomic_init(&p->abort, false); atomic_init(&p->volume, 100); atomic_init(&p->mute, false); atomic_init(&p->speed_milli, 1000);
    p->state = PL_IDLE; p->seek_target = -1;
    return p;
}
void pl_close(Player *p) {
    atomic_store(&p->abort, true);
    pthread_mutex_lock(&p->mu); pthread_cond_broadcast(&p->cv); pthread_mutex_unlock(&p->mu);
    if (p->th_demux_on) pthread_join(p->th_demux, NULL);
    if (p->th_video_on) pthread_join(p->th_video, NULL);
    if (p->th_audio_on) pthread_join(p->th_audio, NULL);
    p->th_demux_on = p->th_video_on = p->th_audio_on = false;
    if (p->adev) { SDL_CloseAudioDevice(p->adev); p->adev = 0; }
    pq_flush(&p->vq); pq_flush(&p->aq);
    for (int i = 0; i < p->fq_n; i++) av_frame_free(&p->fq[(p->fq_r + i) % MAX_FQ].f);
    p->fq_n = p->fq_r = 0;
    for (int i = 0; i < p->ncues; i++) free(p->cues[i].text);
    p->ncues = 0; p->ext_count = 0;
    free(p->ring); p->ring = NULL; p->ring_sz = p->ring_r = p->ring_w = p->ring_n = 0; p->w_total = p->r_total = 0;
    avcodec_free_context(&p->vctx); avcodec_free_context(&p->sctx);
    if (p->ic) avformat_close_input(&p->ic);
    p->vst = p->ast = NULL;
    p->info_ok = false; p->audio_active = false;
    pthread_mutex_lock(&p->mu);
    if (p->state != PL_ERROR) p->state = PL_IDLE;
    pthread_mutex_unlock(&p->mu);
}
void pl_destroy(Player *p) {
    if (!p) return;
    pl_close(p);
    free(p->cues);
    pthread_mutex_destroy(&p->mu); pthread_cond_destroy(&p->cv);
    free(p);
}
bool pl_open(Player *p, const char *url, const NetOptions *net, const ItemHdr *item, double start) {
    pl_close(p);
    atomic_store(&p->abort, false);
    pthread_mutex_lock(&p->mu);
    p->state = PL_OPENING; p->err[0] = 0;
    pthread_mutex_unlock(&p->mu);
    safe_strlcpy(p->url, url, sizeof p->url);
    p->net = *net;
    memset(&p->item, 0, sizeof p->item);
    if (item) p->item = *item;
    p->start_pos = start; p->serial = 0; p->paused = false; p->seek_req = p->reconfig_req = false;
    p->eof_demux = p->v_eof = p->a_eof = false; p->seek_target = -1; p->need_first = true; p->last_vpts = -1;
    p->dropped = p->decoded = 0; p->vc_base_media = 0; p->ring_pts_end = 0; p->step_req = 0;
    p->vi = p->ai = p->si = -1;
    if (pthread_create(&p->th_demux, NULL, demux_main, p) != 0) { set_error(p, "no se pudo crear el hilo de lectura"); return false; }
    p->th_demux_on = true;
    return true;
}
PlState pl_state(Player *p) {
    pthread_mutex_lock(&p->mu);
    PlState s = p->state;
    if (s == PL_PLAYING) {
        if (p->paused) s = PL_PAUSED;
        else {
            bool ended = p->eof_demux && (p->vi < 0 || (p->v_eof && p->fq_n == 0)) && (!p->audio_active || (p->a_eof && p->ring_n == 0));
            bool vstarve = p->vi >= 0 && p->fq_n == 0 && !p->eof_demux && !p->need_first;
            bool astarve = p->audio_active && !p->a_eof && SDL_GetTicks() - p->underrun_tick < 400 && p->ring_n == 0;
            if (ended) s = PL_ENDED; else if (vstarve || astarve) s = PL_BUFFERING;
        }
    }
    pthread_mutex_unlock(&p->mu);
    return s;
}
void pl_error(Player *p, char *out, size_t n) { pthread_mutex_lock(&p->mu); safe_strlcpy(out, p->err, n); pthread_mutex_unlock(&p->mu); }
void pl_pause(Player *p, int mode) {
    SDL_AudioDeviceID dev = 0;
    bool want = false, apply = false;
    pthread_mutex_lock(&p->mu);
    want = mode < 0 ? !p->paused : mode != 0;
    if (want != p->paused && p->state == PL_PLAYING) {
        if (want) { clock_rebase(p); p->paused = true; }
        else { p->paused = false; p->vc_base_wall = av_gettime_relative(); }
        dev = p->adev; apply = true;
    }
    pthread_mutex_unlock(&p->mu);
    /* SDL toma su propio candado de dispositivo y luego llama a audio_cb (que toma p->mu):
     * llamarlo con p->mu tomado invertiría el orden de bloqueos (verificado con ThreadSanitizer). */
    if (apply && dev) SDL_PauseAudioDevice(dev, want ? 1 : 0);
}
void pl_seek(Player *p, double pos, bool relative) {
    pthread_mutex_lock(&p->mu);
    if (p->state == PL_PLAYING && p->seekable) {
        double base = p->seek_req ? p->seek_pos : (p->paused && p->last_vpts >= 0 ? p->last_vpts : clock_now(p));
        p->seek_pos = relative ? base + pos : pos;
        if (p->seek_pos < 0) p->seek_pos = 0;
        p->seek_req = true;
        pthread_cond_broadcast(&p->cv);
    }
    pthread_mutex_unlock(&p->mu);
}
double pl_position(Player *p) {
    pthread_mutex_lock(&p->mu);
    double c = p->seek_req ? p->seek_pos : ((p->paused && p->last_vpts >= 0 && p->vi >= 0) ? p->last_vpts : clock_now(p));
    if (!p->info_ok) c = 0;
    double d = p->info.duration;
    pthread_mutex_unlock(&p->mu);
    if (c < 0) c = 0;
    if (d > 0 && c > d) c = d;
    return c;
}
double pl_duration(Player *p) { pthread_mutex_lock(&p->mu); double d = p->info_ok ? p->info.duration : 0; pthread_mutex_unlock(&p->mu); return d; }
void pl_set_volume(Player *p, int v) { atomic_store(&p->volume, v < 0 ? 0 : v > 200 ? 200 : v); }
int pl_volume(Player *p) { return atomic_load(&p->volume); }
void pl_set_mute(Player *p, bool m) { atomic_store(&p->mute, m); }
bool pl_muted(Player *p) { return atomic_load(&p->mute); }
void pl_set_speed(Player *p, double s) {
    if (s < 0.25) s = 0.25;
    if (s > 4) s = 4;
    pthread_mutex_lock(&p->mu);
    if (!p->audio_active) clock_rebase(p);
    atomic_store(&p->speed_milli, (int)(s * 1000 + 0.5));
    pthread_mutex_unlock(&p->mu);
}
double pl_speed(Player *p) { return speed_of(p); }
void pl_set_av_delay(Player *p, double s) { pthread_mutex_lock(&p->mu); p->av_delay = s; pthread_mutex_unlock(&p->mu); }
void pl_set_sub_delay(Player *p, double s) { pthread_mutex_lock(&p->mu); p->sub_delay = s; pthread_mutex_unlock(&p->mu); }
double pl_av_delay(Player *p) { return p->av_delay; }
double pl_sub_delay(Player *p) { return p->sub_delay; }
bool pl_info(Player *p, PlInfo *out) {
    pthread_mutex_lock(&p->mu);
    bool ok = p->info_ok;
    if (ok) *out = p->info;
    pthread_mutex_unlock(&p->mu);
    return ok;
}
int pl_tracks(Player *p, int kind, PlTrack *out, int max) {
    int n = 0;
    pthread_mutex_lock(&p->mu);
    if (p->info_ok) {
        for (int i = 0; i < p->ntracks && n < max; i++) {
            AVStream *s = p->ic->streams[p->tracks[i].id];
            bool aud = s->codecpar->codec_type == AVMEDIA_TYPE_AUDIO;
            if ((kind == PL_AUDIO) != aud) continue;
            if (!aud && !is_text_sub(s)) continue;                 /* subtítulos de imagen no soportados */
            out[n] = p->tracks[i];
            out[n].selected = aud ? p->ai == out[n].id : p->si == out[n].id;
            n++;
        }
        if (kind == PL_SUB) for (int k = 0; k < p->ext_count && n < max; k++) {
            PlTrack *t = &out[n++];
            memset(t, 0, sizeof *t);
            t->id = 1000 + k; t->external = true; t->selected = p->si == t->id;
            safe_strlcpy(t->title, p->ext_name[k], sizeof t->title); safe_strlcpy(t->codec, "externo", sizeof t->codec);
        }
    }
    pthread_mutex_unlock(&p->mu);
    return n;
}
void pl_select_track(Player *p, int kind, int id) {
    pthread_mutex_lock(&p->mu);
    if (kind == PL_AUDIO) p->ai_req = id; else p->si_req = id;
    if (kind == PL_SUB && id >= 1000) p->si = id;                         /* externo: basta con filtrar */
    else p->reconfig_req = true;
    if (kind == PL_SUB && p->si_req < 0 && p->si >= 1000) p->si = -1;
    if (kind == PL_SUB && id < 0) { p->si = id; }
    pthread_cond_broadcast(&p->cv);
    pthread_mutex_unlock(&p->mu);
}
bool pl_subtitle_text(Player *p, char *buf, size_t n) {
    buf[0] = 0;
    pthread_mutex_lock(&p->mu);
    double t = ((p->vi >= 0 && p->last_vpts >= 0) ? p->last_vpts : clock_now(p)) - p->sub_delay;
    SBuf b = {0};
    if (p->si >= 0)
        for (int i = 0; i < p->ncues; i++) {
            Cue *c = &p->cues[i];
            if (c->track == p->si && c->start <= t && t < c->end) { if (b.len) sb_push(&b, '\n'); sb_str(&b, c->text); }
        }
    if (p->ncues > 600) {                                                  /* acota la memoria: descarta embebidos antiguos */
        int k = 0;
        for (int i = 0; i < p->ncues; i++) { if (p->cues[i].track >= 1000 || p->cues[i].end > t - 30) p->cues[k++] = p->cues[i]; else free(p->cues[i].text); }
        p->ncues = k;
    }
    pthread_mutex_unlock(&p->mu);
    bool any = b.len > 0;
    if (any) safe_strlcpy(buf, b.d, n);
    sb_free(&b);
    return any;
}
void pl_step_frame(Player *p) { pthread_mutex_lock(&p->mu); if (p->paused) p->step_req = 1; pthread_mutex_unlock(&p->mu); }
void pl_stats(Player *p, PlStats *s) {
    memset(s, 0, sizeof *s);
    pthread_mutex_lock(&p->mu);
    s->clock = p->info_ok ? clock_now(p) : 0; s->duration = p->info.duration;
    s->dropped = p->dropped; s->decoded = p->decoded; s->vq_pkts = p->vq.n; s->aq_pkts = p->aq.n; s->fq_frames = p->fq_n;
    s->qbytes = p->vq.bytes + p->aq.bytes;
    s->av_diff = p->last_vpts >= 0 ? p->last_vpts - s->clock : 0;
    pthread_mutex_unlock(&p->mu);
    s->buffering = pl_state(p) == PL_BUFFERING;
}

bool pl_video_update(Player *p, SDL_Renderer *r, SDL_Texture **tex, int *tw, int *th) {
    VFrame vf = {0};
    bool got = false;
    pthread_mutex_lock(&p->mu);
    if (p->audio_active && p->a_eof && p->ring_n == 0) { clock_rebase(p); p->audio_active = false; p->vc_base_wall = av_gettime_relative(); }   /* el audio acabó antes: reloj de pared */
    double clk = clock_now(p) + p->av_delay;
    for (;;) {
        if (p->fq_n == 0) break;
        VFrame *h = &p->fq[p->fq_r];
        if (h->serial != p->serial) { av_frame_free(&h->f); p->fq_r = (p->fq_r + 1) % MAX_FQ; p->fq_n--; continue; }
        bool allowed = !p->paused || p->step_req || p->need_first;
        if (!allowed) break;
        bool due = h->pts <= clk + 0.002 || p->step_req || (p->need_first && p->paused);
        if (!due) break;
        if (!p->paused && p->fq_n > 1 && p->fq[(p->fq_r + 1) % MAX_FQ].pts <= clk) {        /* hay otro ya vencido: descarta éste */
            av_frame_free(&h->f); p->fq_r = (p->fq_r + 1) % MAX_FQ; p->fq_n--; p->dropped++; continue;
        }
        vf = *h; p->fq_r = (p->fq_r + 1) % MAX_FQ; p->fq_n--;
        p->last_vpts = vf.pts; p->step_req = 0; p->need_first = false;
        got = true;
        pthread_cond_broadcast(&p->cv);
        break;
    }
    pthread_mutex_unlock(&p->mu);
    if (got) {
        AVFrame *f = vf.f;
        if (!*tex || *tw != f->width || *th != f->height) {
            if (*tex) SDL_DestroyTexture(*tex);
            SDL_SetYUVConversionMode(SDL_YUV_CONVERSION_AUTOMATIC);
            *tex = SDL_CreateTexture(r, SDL_PIXELFORMAT_IYUV, SDL_TEXTUREACCESS_STREAMING, f->width, f->height);
            *tw = f->width; *th = f->height;
        }
        if (*tex) SDL_UpdateYUVTexture(*tex, NULL, f->data[0], f->linesize[0], f->data[1], f->linesize[1], f->data[2], f->linesize[2]);
        av_frame_free(&f);
    }
    return *tex != NULL;
}

/* ------------------------------------------------------------------ sonda */
typedef struct { int64_t deadline; volatile int *cancel; } ProbeCtl;
static int probe_intr(void *o) { ProbeCtl *c = (ProbeCtl *)o; return (c->cancel && *c->cancel) || av_gettime_relative() > c->deadline; }
bool pl_probe(const char *url, const NetOptions *net, const ItemHdr *item, char *report, size_t cap, volatile int *cancel) {
    SBuf b = {0};
    char tmp[512], eb[160];
    ProbeCtl ctl = {av_gettime_relative() + (int64_t)(net->timeout_s * 3 + 10) * 1000000, cancel};
    AVFormatContext *ic = avformat_alloc_context();
    ic->interrupt_callback.callback = probe_intr; ic->interrupt_callback.opaque = &ctl;
    AVDictionary *opts = NULL;
    build_opts(&opts, net, item, url);
    int64_t t0 = av_gettime_relative();
    int r = avformat_open_input(&ic, url, NULL, &opts);
    av_dict_free(&opts);
    if (r < 0) {
        errstr(r, eb, sizeof eb);
        snprintf(tmp, sizeof tmp, "✗ No se pudo abrir (%lld ms)\n   %s\n", (long long)((av_gettime_relative() - t0) / 1000), eb);
        sb_str(&b, tmp);
        if (r == AVERROR_HTTP_FORBIDDEN || r == AVERROR_HTTP_UNAUTHORIZED) sb_str(&b, "   Pista: el servidor rechaza la petición. Prueba otro User-Agent, un Referer o cabeceras/cookies.\n");
        if (r == AVERROR_HTTP_NOT_FOUND) sb_str(&b, "   Pista: el enlace ha caducado o no existe (los enlaces extraídos suelen caducar).\n");
        safe_strlcpy(report, b.d, cap); sb_free(&b);
        return false;
    }
    int64_t t1 = av_gettime_relative();
    avformat_find_stream_info(ic, NULL);
    int64_t t2 = av_gettime_relative();
    snprintf(tmp, sizeof tmp, "✓ Abierto en %lld ms (análisis: %lld ms)\n", (long long)((t1 - t0) / 1000), (long long)((t2 - t1) / 1000));
    sb_str(&b, tmp);
    snprintf(tmp, sizeof tmp, "Contenedor: %s (%s)\n", ic->iformat->name, ic->iformat->long_name ? ic->iformat->long_name : "");
    sb_str(&b, tmp);
    if (ic->duration != AV_NOPTS_VALUE) { int s = (int)(ic->duration / AV_TIME_BASE); snprintf(tmp, sizeof tmp, "Duración: %d:%02d:%02d\n", s / 3600, s / 60 % 60, s % 60); sb_str(&b, tmp); }
    else sb_str(&b, "Duración: desconocida (¿directo?)\n");
    if (ic->bit_rate > 1000) { snprintf(tmp, sizeof tmp, "Bitrate total: %ld kbps\n", (long)(ic->bit_rate / 1000)); sb_str(&b, tmp); }
    int64_t sz = ic->pb ? avio_size(ic->pb) : -1;
    if (sz > 1024) { snprintf(tmp, sizeof tmp, "Tamaño: %.1f MB\n", sz / 1048576.0); sb_str(&b, tmp); }
    snprintf(tmp, sizeof tmp, "Seek: %s\n", (ic->pb && (ic->pb->seekable & AVIO_SEEKABLE_NORMAL)) ? "sí" : "no");
    sb_str(&b, tmp);
    if (ic->pb) {
        int64_t code = 0;
        uint8_t *ct = NULL;
        if (av_opt_get_int(ic->pb, "http_code", AV_OPT_SEARCH_CHILDREN, &code) == 0 && code) { snprintf(tmp, sizeof tmp, "HTTP: %d\n", (int)code); sb_str(&b, tmp); }
        if (av_opt_get(ic->pb, "content_type", AV_OPT_SEARCH_CHILDREN, &ct) == 0 && ct && *ct) { snprintf(tmp, sizeof tmp, "Content-Type: %s\n", (char *)ct); sb_str(&b, tmp); av_free(ct); }
    }
    if (ic->nb_programs > 1) { snprintf(tmp, sizeof tmp, "Variantes (HLS): %u\n", ic->nb_programs); sb_str(&b, tmp); }
    AVDictionaryEntry *t = av_dict_get(ic->metadata, "title", NULL, 0);
    if (t) { snprintf(tmp, sizeof tmp, "Título: %s\n", t->value); sb_str(&b, tmp); }
    for (unsigned i = 0; i < ic->nb_streams; i++) {
        AVCodecParameters *c = ic->streams[i]->codecpar;
        AVDictionaryEntry *l = av_dict_get(ic->streams[i]->metadata, "language", NULL, 0);
        const char *ty = av_get_media_type_string(c->codec_type);
        if (c->codec_type == AVMEDIA_TYPE_VIDEO) {
            AVRational fr = av_guess_frame_rate(ic, ic->streams[i], NULL);
            snprintf(tmp, sizeof tmp, "  #%u vídeo  %s %dx%d %.2f fps %s %ld kbps\n", i, avcodec_get_name(c->codec_id), c->width, c->height, fr.den ? av_q2d(fr) : 0.0,
                     av_get_pix_fmt_name((enum AVPixelFormat)c->format) ? av_get_pix_fmt_name((enum AVPixelFormat)c->format) : "", (long)(c->bit_rate / 1000));
        } else if (c->codec_type == AVMEDIA_TYPE_AUDIO) {
            snprintf(tmp, sizeof tmp, "  #%u audio  %s %d Hz %s %ld kbps\n", i, avcodec_get_name(c->codec_id), c->sample_rate, l ? l->value : "", (long)(c->bit_rate / 1000));
        } else snprintf(tmp, sizeof tmp, "  #%u %s %s %s\n", i, ty ? ty : "?", avcodec_get_name(c->codec_id), l ? l->value : "");
        sb_str(&b, tmp);
    }
    avformat_close_input(&ic);
    safe_strlcpy(report, b.d, cap);
    sb_free(&b);
    return true;
}

/* gancho solo para las pruebas (tests/test_player.c): pts del último fotograma mostrado */
double g_last_pts_probe(Player *p) { pthread_mutex_lock(&p->mu); double v = p->last_vpts; pthread_mutex_unlock(&p->mu); return v; }
