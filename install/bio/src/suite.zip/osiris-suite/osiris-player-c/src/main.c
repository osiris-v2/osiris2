/* main.c - Osiris Player: interfaz sobre share-lib-sdl-c (osl) + motor player.c + yt-dlp (ytdl.c). */
#define _GNU_SOURCE
#include <pthread.h>
#include <strings.h>
#include <time.h>
#include "osl/osl.h"
#include "player.h"
#include "ytdl.h"
#include <libavutil/log.h>
#ifdef OSL_HAVE_IMAGE
#include <SDL_image.h>
#endif

#define VERSION "1.0.0"
enum { V_PLAYER, V_NET };
enum { J_NONE, J_RESOLVE, J_PROBE };
enum { P_PLAY, P_LIST, P_PROBE_UI };
enum { MN_NONE, MN_FILE, MN_PLAY, MN_VIDEO, MN_AUDIO, MN_SUB };

typedef struct { char *url, *title, *play_url; ItemHdr hdr, play_hdr; bool resolved; } Item;
typedef struct {
    int kind, purpose, idx;
    char url[2048];
    NetOptions net;
    ItemHdr hdr;
    YtResult *res;
    char err[400], report[4096];
    bool ok;
    volatile int cancel, done;
    pthread_t th;
    bool running;
} Job;

typedef struct {
    OslApp *app;
    Player *pl;
    NetOptions net;
    SAFE_VEC(Item) items;
    int cur, psel;
    int view;
    bool show_list, show_info, fb_tried, tracks_applied, ext_applied, shot_req;
    SDL_Texture *tex; int tw, th;
    int loop, aspect, rot, flip, zoom, sub_pct, theme, font_px;
    bool resume_on, auto_sub, auto_ext;
    char sub_lang[64], audio_lang[64];
    OslJson *cfg, *resume;
    char cfg_path[512];
    uint32_t last_move;
    int menu_open[6];
    int menu_x;
    char url_in[2048], ua_edit[512], ua_prev_preset_str[512];
    int ua_preset_seen;
    char subtext[1024], sub_key[1200];
    SDL_Texture *subtex; int subw, subh;
    TTF_Font *subfont; int subfont_px;
    Job job;
    YtResult *ytres;
    char report[4096], netmsg[800];
    int scroll_net, scroll_fmt, scroll_list, scroll_rep, fmt_sel;
    double seek_val; bool seeking;
    char menu_txt[40][260];
    bool opened_ok;
    uint32_t fps_tick; int fps_frames; double fps;
} G;
static G g;

/* ------------------------------------------------------------------- utilidades */
static void toast(const char *fmt, ...) __attribute__((format(printf, 1, 2)));
static void toast(const char *fmt, ...) {
    char b[300];
    va_list ap; va_start(ap, fmt); vsnprintf(b, sizeof b, fmt, ap); va_end(ap);
    osl_app_toast(g.app, "%s", b);
}
static void fmt_time(double t, char *o, size_t n) {
    if (t < 0) t = 0;
    int s = (int)t;
    if (s >= 3600) snprintf(o, n, "%d:%02d:%02d", s / 3600, s / 60 % 60, s % 60); else snprintf(o, n, "%d:%02d", s / 60, s % 60);
}
static bool is_url(const char *s) { return strstr(s, "://") != NULL; }
static bool is_http(const char *s) { return !strncmp(s, "http://", 7) || !strncmp(s, "https://", 8); }
static const char *base_name(const char *u) {
    const char *q = strrchr(u, '/');
    return q && q[1] ? q + 1 : u;
}

static void item_free(Item *it) { free(it->url); free(it->title); free(it->play_url); }
static int item_add(const char *url, const char *title) {
    Item it = {0};
    safe_ptr(char) exp = is_url(url) ? safe_strdup(url) : osl_fs_expand(url);
    it.url = safe_strdup(exp);
    it.title = safe_strdup(title && *title ? title : base_name(exp));
    safe_vec_push(g.items, it);
    return (int)g.items.n - 1;
}

/* ---------------------------------------------------------------- configuración */
static void cfg_save(void) {
    OslJson *c = osl_json_new(OSL_J_OBJ);
    osl_json_obj_set(c, "net", net_save(&g.net));
    OslJson *s = osl_json_new(OSL_J_OBJ);
    osl_json_obj_set(s, "volume", osl_json_num(pl_volume(g.pl))); osl_json_obj_set(s, "mute", osl_json_bool(pl_muted(g.pl)));
    osl_json_obj_set(s, "loop", osl_json_num(g.loop)); osl_json_obj_set(s, "aspect", osl_json_num(g.aspect));
    osl_json_obj_set(s, "sub_pct", osl_json_num(g.sub_pct)); osl_json_obj_set(s, "theme", osl_json_num(g.theme));
    osl_json_obj_set(s, "font_px", osl_json_num(g.font_px)); osl_json_obj_set(s, "show_list", osl_json_bool(g.show_list));
    osl_json_obj_set(s, "resume_on", osl_json_bool(g.resume_on)); osl_json_obj_set(s, "auto_sub", osl_json_bool(g.auto_sub));
    osl_json_obj_set(s, "auto_ext", osl_json_bool(g.auto_ext)); osl_json_obj_set(s, "sub_lang", osl_json_str(g.sub_lang));
    osl_json_obj_set(s, "audio_lang", osl_json_str(g.audio_lang));
    osl_json_obj_set(c, "settings", s);
    OslJson *pl = osl_json_new(OSL_J_ARR);
    for (size_t i = 0; i < g.items.n; i++) {
        Item *it = &g.items.d[i];
        OslJson *o = osl_json_new(OSL_J_OBJ);
        osl_json_obj_set(o, "url", osl_json_str(it->url)); osl_json_obj_set(o, "title", osl_json_str(it->title));
        if (it->hdr.ua[0]) osl_json_obj_set(o, "ua", osl_json_str(it->hdr.ua));
        if (it->hdr.referer[0]) osl_json_obj_set(o, "referer", osl_json_str(it->hdr.referer));
        if (it->hdr.headers[0]) osl_json_obj_set(o, "headers", osl_json_str(it->hdr.headers));
        osl_json_arr_push(pl, o);
    }
    osl_json_obj_set(c, "playlist", pl);
    osl_json_obj_set(c, "cur", osl_json_num(g.cur));
    if (g.resume) osl_json_obj_set(c, "resume", osl_json_clone(g.resume));
    safe_ptr(char) txt = osl_json_dump(c, 2);
    char err[200];
    osl_fs_write_atomic(g.cfg_path, txt, strlen(txt), false, err, sizeof err);
    osl_json_free(c);
}
static void cfg_load(void) {
    safe_ptr(char) dir = osl_fs_config_dir("osiris-player");
    snprintf(g.cfg_path, sizeof g.cfg_path, "%s/config.json", dir);
    net_defaults(&g.net);
    g.theme = 2; g.font_px = 15; g.sub_pct = 100; g.show_list = true; g.resume_on = true; g.auto_sub = true; g.auto_ext = true;
    safe_strlcpy(g.sub_lang, "spa,es,eng,en", sizeof g.sub_lang);
    g.resume = osl_json_new(OSL_J_OBJ);
    char err[200];
    char *txt = osl_fs_exists(g.cfg_path) ? osl_fs_read_all(g.cfg_path, 8u << 20, NULL, err, sizeof err) : NULL;
    OslJson *c = txt ? osl_json_parse(txt, err, sizeof err) : NULL;
    free(txt);
    if (!c) return;
    net_load(&g.net, osl_json_obj_get(c, "net"));
    OslJson *s = osl_json_obj_get(c, "settings");
    if (s) {
        pl_set_volume(g.pl, (int)osl_json_num_or(s, "volume", 100)); pl_set_mute(g.pl, osl_json_bool_or(s, "mute", false));
        g.loop = (int)osl_json_num_or(s, "loop", 0); g.aspect = (int)osl_json_num_or(s, "aspect", 0);
        g.sub_pct = (int)osl_json_num_or(s, "sub_pct", 100); g.theme = (int)osl_json_num_or(s, "theme", 2);
        g.font_px = (int)osl_json_num_or(s, "font_px", 15); g.show_list = osl_json_bool_or(s, "show_list", true);
        g.resume_on = osl_json_bool_or(s, "resume_on", true); g.auto_sub = osl_json_bool_or(s, "auto_sub", true);
        g.auto_ext = osl_json_bool_or(s, "auto_ext", true);
        safe_strlcpy(g.sub_lang, osl_json_str_or(s, "sub_lang", g.sub_lang), sizeof g.sub_lang);
        safe_strlcpy(g.audio_lang, osl_json_str_or(s, "audio_lang", ""), sizeof g.audio_lang);
        if (g.sub_pct < 40 || g.sub_pct > 250) g.sub_pct = 100;
        if (g.font_px < 11 || g.font_px > 24) g.font_px = 15;
    }
    OslJson *pl = osl_json_obj_get(c, "playlist");
    if (pl && pl->t == OSL_J_ARR)
        for (size_t i = 0; i < pl->n; i++) {
            OslJson *o = pl->v[i];
            if (!*osl_json_str_or(o, "url", "")) continue;
            int k = item_add(osl_json_str_or(o, "url", ""), osl_json_str_or(o, "title", ""));
            safe_strlcpy(g.items.d[k].hdr.ua, osl_json_str_or(o, "ua", ""), sizeof g.items.d[k].hdr.ua);
            safe_strlcpy(g.items.d[k].hdr.referer, osl_json_str_or(o, "referer", ""), sizeof g.items.d[k].hdr.referer);
            safe_strlcpy(g.items.d[k].hdr.headers, osl_json_str_or(o, "headers", ""), sizeof g.items.d[k].hdr.headers);
        }
    g.cur = -1;
    OslJson *rs = osl_json_obj_get(c, "resume");
    if (rs && rs->t == OSL_J_OBJ) { osl_json_free(g.resume); g.resume = osl_json_clone(rs); }
    osl_json_free(c);
}
static double resume_get(const char *url) { return g.resume_on ? osl_json_num_or(g.resume, url, 0) : 0; }
static void resume_save(void) {
    if (g.cur < 0 || (size_t)g.cur >= g.items.n || !g.opened_ok) return;
    const char *url = g.items.d[g.cur].url;
    double pos = pl_position(g.pl), dur = pl_duration(g.pl);
    if (pos > 10 && dur > 0 && pos < dur - 10) osl_json_obj_set(g.resume, url, osl_json_num((int)pos));
    else osl_json_obj_del(g.resume, url);
    while (g.resume->n > 60) osl_json_obj_del(g.resume, g.resume->k[0]);       /* acota el historial */
}

/* ---------------------------------------------------------------- trabajos asíncronos */
static void *job_main(void *a) {
    Job *j = (Job *)a;
    if (j->kind == J_RESOLVE) j->ok = ytdl_resolve(&j->net, j->url, &j->res, j->err, sizeof j->err);
    else j->ok = pl_probe(j->url, &j->net, &j->hdr, j->report, sizeof j->report, &j->cancel);
    j->done = 1;
    osl_app_wake(g.app);
    return NULL;
}
static bool job_start(int kind, int purpose, int idx, const char *url, const ItemHdr *hdr) {
    if (g.job.running) { toast("Ya hay una operación en curso (espera o cancélala)"); return false; }
    Job *j = &g.job;
    memset(j, 0, sizeof *j);
    j->kind = kind; j->purpose = purpose; j->idx = idx;
    safe_strlcpy(j->url, url, sizeof j->url);
    j->net = g.net;
    if (hdr) j->hdr = *hdr;
    if (pthread_create(&j->th, NULL, job_main, j) != 0) { toast("No se pudo crear el hilo"); return false; }
    j->running = true;
    return true;
}

/* ------------------------------------------------------------------- apertura */
static void start_open(const char *url, const ItemHdr *hdr, double start) {
    pl_open(g.pl, url, &g.net, hdr, start);
    g.tracks_applied = g.ext_applied = false; g.opened_ok = false;
    if (g.tex) { SDL_DestroyTexture(g.tex); g.tex = NULL; }
    g.last_move = SDL_GetTicks();
}
static void play_index(int i) {
    if (i < 0 || (size_t)i >= g.items.n) return;
    resume_save();
    g.cur = i; g.fb_tried = false; g.netmsg[0] = 0;
    Item *it = &g.items.d[i];
    free(it->play_url); it->play_url = NULL; it->resolved = false;
    char t[300];
    snprintf(t, sizeof t, "%s — Osiris Player", it->title);
    osl_app_set_title(g.app, t);
    if (g.net.ytdl_mode == YTDL_ALWAYS && is_http(it->url)) { pl_close(g.pl); job_start(J_RESOLVE, P_PLAY, i, it->url, &it->hdr); return; }
    start_open(it->url, &it->hdr, resume_get(it->url));
    if (resume_get(it->url) > 0) { char tb[32]; fmt_time(resume_get(it->url), tb, sizeof tb); toast("Reanudando desde %s", tb); }
}
static void stop_play(void) { resume_save(); pl_close(g.pl); if (g.tex) { SDL_DestroyTexture(g.tex); g.tex = NULL; } g.opened_ok = false; g.cur = g.cur; }
static void play_next(int dir) {
    if (!g.items.n) return;
    int n = (int)g.items.n, i = g.cur + dir;
    if (i >= n) i = 0;
    if (i < 0) i = n - 1;
    play_index(i);
}
static void open_now(const char *what) {                   /* abre una URL/fichero como elemento nuevo y lo reproduce */
    if (!what || !*what) return;
    int k = item_add(what, NULL);
    play_index(k);
}
static void load_m3u(const char *path) {
    char err[200];
    char *txt = osl_fs_read_all(path, 8u << 20, NULL, err, sizeof err);
    if (!txt) { osl_dlg_message(g.app, "No se pudo leer la lista", err); return; }
    safe_ptr(char) dir = osl_fs_dirname(path);
    char title[256] = "";
    int added = 0, first = -1;
    char *sv = NULL;
    for (char *l = strtok_r(txt, "\r\n", &sv); l; l = strtok_r(NULL, "\r\n", &sv)) {
        while (*l == ' ') l++;
        if (!*l) continue;
        if (!strncmp(l, "#EXTINF:", 8)) { char *c = strchr(l, ','); safe_strlcpy(title, c ? c + 1 : "", sizeof title); continue; }
        if (l[0] == '#') continue;
        safe_ptr(char) full = (is_url(l) || l[0] == '/') ? safe_strdup(l) : osl_fs_join(dir, l);
        int k = item_add(full, title);
        if (first < 0) first = k;
        added++; title[0] = 0;
    }
    free(txt);
    toast("%d elementos añadidos", added);
    if (first >= 0 && g.cur < 0) play_index(first);
}
static void save_m3u(const char *path) {
    SBuf b = {0};
    sb_str(&b, "#EXTM3U\n");
    for (size_t i = 0; i < g.items.n; i++) {
        safe_ptr(char) l = safe_asprintf("#EXTINF:-1,%s\n%s\n", g.items.d[i].title, g.items.d[i].url);
        sb_str(&b, l);
    }
    char err[200];
    if (osl_fs_write_atomic(path, b.d ? b.d : "", b.len, false, err, sizeof err)) toast("Lista guardada: %s", osl_fs_basename(path));
    else osl_dlg_message(g.app, "No se pudo guardar", err);
    sb_free(&b);
}
static void on_drop(const char *what, void *u) {
    (void)u;
    char *w = safe_strdup(what);
    if (!strncmp(w, "file://", 7)) memmove(w, w + 7, strlen(w + 6));          /* uri de fichero -> ruta */
    size_t l = strlen(w);
    if (l > 5 && (!strcasecmp(w + l - 5, ".m3u8") && !is_url(w))) load_m3u(w);
    else if (l > 4 && !strcasecmp(w + l - 4, ".m3u") && !is_url(w)) load_m3u(w);
    else if (l > 4 && (!strcasecmp(w + l - 4, ".srt") || !strcasecmp(w + l - 4, ".ass") || !strcasecmp(w + l - 4, ".vtt"))) {
        char err[200];
        if (pl_load_subtitle_file(g.pl, w, err, sizeof err)) toast("Subtítulos cargados"); else toast("%s", err);
    } else {
        if (is_url(w) || osl_fs_exists(w)) open_now(w);
    }
    free(w);
}

/* --------------------------------------------------------------------- pistas */
static void track_label(const PlTrack *t, char *o, size_t n) {
    char tmp[320] = "";
    if (t->lang[0]) snprintf(tmp, sizeof tmp, "%s", t->lang);
    if (t->title[0]) { size_t l = strlen(tmp); snprintf(tmp + l, sizeof tmp - l, "%s%s", l ? " · " : "", t->title); }
    if (!tmp[0]) snprintf(tmp, sizeof tmp, "Pista %d", t->id);
    if (t->channels > 0) { size_t l = strlen(tmp); snprintf(tmp + l, sizeof tmp - l, " (%dch %s)", t->channels, t->codec); }
    safe_strlcpy(o, tmp, n);
}
static void cycle_track(int kind) {
    PlTrack tr[32];
    int n = pl_tracks(g.pl, kind, tr, 32), cur = -1;
    if (!n) { toast(kind == PL_AUDIO ? "No hay pistas de audio" : "No hay subtítulos de texto (usa «Cargar subtítulos…»)"); return; }
    for (int i = 0; i < n; i++) if (tr[i].selected) cur = i;
    char l[200];
    if (kind == PL_SUB && cur + 1 >= n) { pl_select_track(g.pl, PL_SUB, -1); toast("Subtítulos: desactivados"); return; }
    int nx = (cur + 1) % n;
    track_label(&tr[nx], l, sizeof l);
    pl_select_track(g.pl, kind, tr[nx].id);
    toast("%s: %s", kind == PL_AUDIO ? "Audio" : "Subtítulos", l);
}
static bool lang_match(const char *lang, const char *prefs) {
    if (!lang[0] || !prefs[0]) return false;
    safe_ptr(char) cp = safe_strdup(prefs);
    char *sv = NULL;
    for (char *t = strtok_r(cp, ", ", &sv); t; t = strtok_r(NULL, ", ", &sv)) if (!strncasecmp(lang, t, strlen(t)) || !strncasecmp(t, lang, strlen(lang))) return true;
    return false;
}
static void apply_auto(void) {
    PlTrack tr[32];
    if (g.audio_lang[0]) {
        int n = pl_tracks(g.pl, PL_AUDIO, tr, 32);
        for (int i = 0; i < n; i++) if (lang_match(tr[i].lang, g.audio_lang)) { if (!tr[i].selected) pl_select_track(g.pl, PL_AUDIO, tr[i].id); break; }
    }
    if (!g.auto_sub) return;
    bool done = false;
    if (g.auto_ext && g.cur >= 0 && !is_url(g.items.d[g.cur].url)) {              /* subtítulos junto al fichero */
        static const char *EXT[] = {".srt", ".ass", ".vtt", NULL};
        safe_ptr(char) base = safe_strdup(g.items.d[g.cur].url);
        char *dot = strrchr(base, '.');
        if (dot) *dot = 0;
        for (int k = 0; EXT[k] && !done; k++) {
            safe_ptr(char) cand = safe_asprintf("%s%s", base, EXT[k]);
            char err[200];
            if (osl_fs_exists(cand) && pl_load_subtitle_file(g.pl, cand, err, sizeof err)) { done = true; toast("Subtítulos: %s", osl_fs_basename(cand)); }
        }
    }
    if (!done) {
        int n = pl_tracks(g.pl, PL_SUB, tr, 32);
        for (int i = 0; i < n; i++) if (!tr[i].external && lang_match(tr[i].lang, g.sub_lang)) { pl_select_track(g.pl, PL_SUB, tr[i].id); break; }
    }
}

/* --------------------------------------------------------------------- vídeo */
static SDL_Rect draw_video(OslUi *u, SDL_Rect area, const PlInfo *info, bool have) {
    osl_rect(u, area, (SDL_Color){0, 0, 0, 255});
    SDL_Rect disp = area;
    if (!g.tex) return disp;
    double vw = g.tw, vh = g.th;
    if (have && info->sar_num > 0 && info->sar_den > 0) vw *= (double)info->sar_num / info->sar_den;
    bool swap = (g.rot & 1) != 0;
    double ar = vw / vh;
    if (swap) ar = 1.0 / ar;
    double dw, dh;
    if (g.aspect == 3) { dw = area.w; dh = area.h; }
    else {
        if (g.aspect == 1) ar = swap ? 9.0 / 16.0 : 16.0 / 9.0;
        else if (g.aspect == 2) ar = swap ? 3.0 / 4.0 : 4.0 / 3.0;
        if (g.aspect == 4) { dw = swap ? g.th : g.tw; dh = swap ? g.tw : g.th; }
        else if ((double)area.w / area.h > ar) { dh = area.h; dw = dh * ar; } else { dw = area.w; dh = dw / ar; }
    }
    dw = dw * g.zoom / 100.0; dh = dh * g.zoom / 100.0;
    int cx = area.x + area.w / 2, cy = area.y + area.h / 2;
    SDL_Rect dst = swap ? (SDL_Rect){cx - (int)(dh / 2), cy - (int)(dw / 2), (int)dh, (int)dw} : (SDL_Rect){cx - (int)(dw / 2), cy - (int)(dh / 2), (int)dw, (int)dh};
    int flip = SDL_FLIP_NONE;
    if (g.flip & 1) flip |= SDL_FLIP_HORIZONTAL;
    if (g.flip & 2) flip |= SDL_FLIP_VERTICAL;
    osl_clip(u, &area);
    SDL_RenderCopyEx(u->r, g.tex, NULL, &dst, g.rot * 90.0, NULL, (SDL_RendererFlip)flip);
    osl_clip(u, NULL);
    disp = (SDL_Rect){cx - (int)(dw / 2), cy - (int)(dh / 2), (int)dw, (int)dh};
    SDL_Rect inter;
    if (SDL_IntersectRect(&disp, &area, &inter)) disp = inter;
    return disp;
}
static void draw_subtitle(OslUi *u, SDL_Rect vid) {
    char text[1024];
    if (!pl_subtitle_text(g.pl, text, sizeof text)) return;
    int px = (int)(vid.h * 0.045 * g.sub_pct / 100.0);
    if (px < 12) px = 12;
    if (px > 90) px = 90;
    if (!g.subfont || g.subfont_px != px) {
        if (g.subfont) TTF_CloseFont(g.subfont);
        safe_ptr(char) fp = osl_font_find(true);
        if (!fp) fp = osl_font_find(false);
        g.subfont = fp ? TTF_OpenFont(fp, px) : NULL;
        g.subfont_px = px; g.sub_key[0] = 0;
    }
    if (!g.subfont) return;
    char key[1200];
    snprintf(key, sizeof key, "%d|%d|%s", px, vid.w, text);
    if (strcmp(key, g.sub_key)) {
        if (g.subtex) { SDL_DestroyTexture(g.subtex); g.subtex = NULL; }
        int wrap = (int)(vid.w * 0.9);
#if SDL_TTF_VERSION_ATLEAST(2, 20, 0)
        TTF_SetFontWrappedAlign(g.subfont, TTF_WRAPPED_ALIGN_CENTER);
#endif
        TTF_SetFontOutline(g.subfont, 2);
        SDL_Surface *o = TTF_RenderUTF8_Blended_Wrapped(g.subfont, text, (SDL_Color){0, 0, 0, 255}, (Uint32)wrap);
        TTF_SetFontOutline(g.subfont, 0);
        SDL_Surface *w = TTF_RenderUTF8_Blended_Wrapped(g.subfont, text, (SDL_Color){255, 255, 255, 255}, (Uint32)wrap);
        if (o && w) {
            SDL_Surface *d = SDL_CreateRGBSurfaceWithFormat(0, o->w, o->h, 32, SDL_PIXELFORMAT_ARGB8888);
            SDL_FillRect(d, NULL, 0);
            SDL_SetSurfaceBlendMode(o, SDL_BLENDMODE_BLEND); SDL_SetSurfaceBlendMode(w, SDL_BLENDMODE_BLEND);
            SDL_BlitSurface(o, NULL, d, NULL);
            SDL_Rect at = {(o->w - w->w) / 2, (o->h - w->h) / 2, 0, 0};
            SDL_BlitSurface(w, NULL, d, &at);
            g.subtex = SDL_CreateTextureFromSurface(u->r, d);
            if (g.subtex) SDL_SetTextureBlendMode(g.subtex, SDL_BLENDMODE_BLEND);
            g.subw = d->w; g.subh = d->h;
            SDL_FreeSurface(d);
        }
        if (o) SDL_FreeSurface(o);
        if (w) SDL_FreeSurface(w);
        safe_strlcpy(g.sub_key, key, sizeof g.sub_key);
    }
    if (g.subtex) {
        SDL_Rect d = {vid.x + (vid.w - g.subw) / 2, vid.y + vid.h - g.subh - (int)(vid.h * 0.06), g.subw, g.subh};
        SDL_RenderCopy(u->r, g.subtex, NULL, &d);
    }
}
static void take_screenshot(OslUi *u, SDL_Rect vid) {
    if (vid.w < 2 || vid.h < 2) return;
    SDL_Surface *s = SDL_CreateRGBSurfaceWithFormat(0, vid.w, vid.h, 32, SDL_PIXELFORMAT_ARGB8888);
    if (!s) return;
    SDL_RenderReadPixels(u->r, &vid, SDL_PIXELFORMAT_ARGB8888, s->pixels, s->pitch);
    safe_ptr(char) dir = safe_asprintf("%s/Pictures", osl_fs_home());
    osl_fs_mkdir_p(dir);
    time_t t = time(NULL); struct tm tv; localtime_r(&t, &tv);
    char ts[32]; strftime(ts, sizeof ts, "%Y%m%d-%H%M%S", &tv);
#ifdef OSL_HAVE_IMAGE
    safe_ptr(char) path = safe_asprintf("%s/osiris-player-%s.png", dir, ts);
    bool ok = IMG_SavePNG(s, path) == 0;
#else
    safe_ptr(char) path = safe_asprintf("%s/osiris-player-%s.bmp", dir, ts);
    bool ok = SDL_SaveBMP(s, path) == 0;
#endif
    SDL_FreeSurface(s);
    if (ok) toast("Captura guardada: %s", path); else toast("No se pudo guardar la captura");
}

/* ------------------------------------------------------------------ acciones */
enum { AC_NONE, AC_OPEN_FILE, AC_ADD_FILE, AC_OPEN_URL, AC_OPEN_M3U, AC_SAVE_M3U, AC_NETVIEW, AC_QUIT, AC_PAUSE, AC_STOP, AC_NEXT, AC_PREV,
       AC_SLOWER, AC_FASTER, AC_SPEED1, AC_LOOP, AC_BACK5, AC_FWD5, AC_BACK60, AC_FWD60, AC_STEP, AC_ASPECT, AC_ROT, AC_FLIPH, AC_FLIPV,
       AC_ZOOMIN, AC_ZOOMOUT, AC_ZOOM1, AC_SHOT, AC_INFO, AC_AD_M, AC_AD_P, AC_MUTE, AC_SUB_OFF, AC_SUB_LOAD, AC_SD_M, AC_SD_P,
       AC_SUB_BIG, AC_SUB_SMALL, AC_LIST, AC_FULLSCREEN, AC_HELP, AC_ABOUT, AC_COPYERR, AC_RETRY, AC_RESOLVE_CUR,
       AC_AUDIO_BASE = 1000, AC_SUB_BASE = 4000 };
static const char *LOOP_NAMES[] = {"no", "uno", "lista"};
static const char *ASPECT_NAMES[] = {"auto", "16:9", "4:3", "rellenar", "original"};

static void cb_open(bool ok, const char *p, void *u) { (void)u; if (ok) open_now(p); }
static void cb_addf(bool ok, const char *p, void *u) { (void)u; if (ok) { int k = item_add(p, NULL); if (g.cur < 0) play_index(k); else toast("Añadido a la lista"); } }
static void cb_m3u(bool ok, const char *p, void *u) { (void)u; if (ok) load_m3u(p); }
static void cb_savem3u(bool ok, const char *p, void *u) { (void)u; if (ok) save_m3u(p); }
static void cb_sub(bool ok, const char *p, void *u) {
    (void)u;
    char err[200];
    if (ok) { if (pl_load_subtitle_file(g.pl, p, err, sizeof err)) toast("Subtítulos cargados: %s", osl_fs_basename(p)); else osl_dlg_message(g.app, "No se pudieron cargar", err); }
}
static void cb_url(bool ok, const char *t, void *u) {
    (void)u;
    if (!ok) return;
    safe_ptr(char) cp = safe_strdup(t);
    char *sv = NULL;
    int first = -1;
    for (char *w = strtok_r(cp, " \t\r\n", &sv); w; w = strtok_r(NULL, " \t\r\n", &sv)) { int k = item_add(w, NULL); if (first < 0) first = k; }
    if (first >= 0) play_index(first);
}
static void seek_rel(double d) { pl_seek(g.pl, d, true); }
static void set_speed(double s) { pl_set_speed(g.pl, s); toast("Velocidad: %.2fx", pl_speed(g.pl)); }
static const char *HELP =
    "Atajos de teclado\n\nEspacio / K   Pausa\n← / →   ±5 s (con Mayús ±30 s)     ↑ / ↓   Volumen ±5\nRe Pág / Av Pág   Anterior / siguiente de la lista\n"
    "0-9   Saltar al 0-90 %\nM   Silenciar     F / F11   Pantalla completa     Esc   Salir de pantalla completa\n[  ]   Velocidad −/+     Retroceso   Velocidad normal\n"
    ".   Fotograma siguiente (en pausa)     L   Bucle (no/uno/lista)\nA   Pista de audio     J   Subtítulos     Z / X   Retardo de subtítulos −/+ 100 ms\n"
    "-  =   Retardo de audio −/+ 50 ms     S   Captura de pantalla     I   Información\nCtrl+O   Abrir fichero     Ctrl+U   Abrir URL     Ctrl+L   Mostrar/ocultar lista\n\n"
    "Ratón: clic en el vídeo = pausa, doble clic = pantalla completa, rueda = volumen. Arrastra ficheros, listas M3U, subtítulos o URLs a la ventana.";

static void do_action(int a) {
    PlTrack tr[32];
    if (a >= AC_SUB_BASE) { pl_select_track(g.pl, PL_SUB, a - AC_SUB_BASE); return; }
    if (a >= AC_AUDIO_BASE) { pl_select_track(g.pl, PL_AUDIO, a - AC_AUDIO_BASE); return; }
    switch (a) {
        case AC_OPEN_FILE: osl_dlg_path(g.app, "Abrir fichero multimedia", OSL_PATH_OPEN_FILE, g.cur >= 0 && !is_url(g.items.d[g.cur].url) ? g.items.d[g.cur].url : osl_fs_home(), NULL, cb_open, NULL); break;
        case AC_ADD_FILE: osl_dlg_path(g.app, "Añadir a la lista", OSL_PATH_OPEN_FILE, osl_fs_home(), NULL, cb_addf, NULL); break;
        case AC_OPEN_URL: osl_dlg_prompt(g.app, "Abrir URL", "Pega una o varias URLs (fichero, m3u8, página de vídeo…):", "", cb_url, NULL); break;
        case AC_OPEN_M3U: osl_dlg_path(g.app, "Cargar lista M3U", OSL_PATH_OPEN_FILE, osl_fs_home(), "m3u;m3u8", cb_m3u, NULL); break;
        case AC_SAVE_M3U: osl_dlg_path(g.app, "Guardar lista M3U", OSL_PATH_SAVE_FILE, osl_fs_home(), "m3u", cb_savem3u, NULL); break;
        case AC_NETVIEW: g.view = g.view == V_NET ? V_PLAYER : V_NET; break;
        case AC_QUIT: osl_app_quit(g.app); break;
        case AC_PAUSE: if (pl_state(g.pl) == PL_ENDED && g.cur >= 0) play_index(g.cur); else pl_pause(g.pl, -1); break;
        case AC_STOP: stop_play(); break;
        case AC_NEXT: play_next(1); break;
        case AC_PREV: if (pl_position(g.pl) > 4) pl_seek(g.pl, 0, false); else play_next(-1); break;
        case AC_SLOWER: set_speed(pl_speed(g.pl) - 0.25); break;
        case AC_FASTER: set_speed(pl_speed(g.pl) + 0.25); break;
        case AC_SPEED1: set_speed(1.0); break;
        case AC_LOOP: g.loop = (g.loop + 1) % 3; toast("Bucle: %s", LOOP_NAMES[g.loop]); break;
        case AC_BACK5: seek_rel(-5); break;
        case AC_FWD5: seek_rel(5); break;
        case AC_BACK60: seek_rel(-60); break;
        case AC_FWD60: seek_rel(60); break;
        case AC_STEP: pl_pause(g.pl, 1); pl_step_frame(g.pl); break;
        case AC_ASPECT: g.aspect = (g.aspect + 1) % 5; toast("Aspecto: %s", ASPECT_NAMES[g.aspect]); break;
        case AC_ROT: g.rot = (g.rot + 1) % 4; toast("Rotación: %d°", g.rot * 90); break;
        case AC_FLIPH: g.flip ^= 1; break;
        case AC_FLIPV: g.flip ^= 2; break;
        case AC_ZOOMIN: g.zoom = g.zoom + 10 > 300 ? 300 : g.zoom + 10; toast("Zoom: %d%%", g.zoom); break;
        case AC_ZOOMOUT: g.zoom = g.zoom - 10 < 50 ? 50 : g.zoom - 10; toast("Zoom: %d%%", g.zoom); break;
        case AC_ZOOM1: g.zoom = 100; g.rot = 0; g.flip = 0; g.aspect = 0; toast("Vídeo restablecido"); break;
        case AC_SHOT: g.shot_req = true; break;
        case AC_INFO: g.show_info = !g.show_info; break;
        case AC_AD_M: pl_set_av_delay(g.pl, pl_av_delay(g.pl) - 0.05); toast("Retardo de audio: %+d ms", (int)lround(pl_av_delay(g.pl) * 1000)); break;
        case AC_AD_P: pl_set_av_delay(g.pl, pl_av_delay(g.pl) + 0.05); toast("Retardo de audio: %+d ms", (int)lround(pl_av_delay(g.pl) * 1000)); break;
        case AC_MUTE: pl_set_mute(g.pl, !pl_muted(g.pl)); toast(pl_muted(g.pl) ? "Silenciado" : "Sonido activado"); break;
        case AC_SUB_OFF: pl_select_track(g.pl, PL_SUB, -1); break;
        case AC_SUB_LOAD: osl_dlg_path(g.app, "Cargar subtítulos", OSL_PATH_OPEN_FILE, g.cur >= 0 && !is_url(g.items.d[g.cur].url) ? g.items.d[g.cur].url : osl_fs_home(), "srt;ass;ssa;vtt;sub", cb_sub, NULL); break;
        case AC_SD_M: pl_set_sub_delay(g.pl, pl_sub_delay(g.pl) - 0.1); toast("Retardo de subtítulos: %+d ms", (int)lround(pl_sub_delay(g.pl) * 1000)); break;
        case AC_SD_P: pl_set_sub_delay(g.pl, pl_sub_delay(g.pl) + 0.1); toast("Retardo de subtítulos: %+d ms", (int)lround(pl_sub_delay(g.pl) * 1000)); break;
        case AC_SUB_BIG: g.sub_pct = g.sub_pct + 10 > 250 ? 250 : g.sub_pct + 10; g.sub_key[0] = 0; toast("Tamaño de subtítulos: %d%%", g.sub_pct); break;
        case AC_SUB_SMALL: g.sub_pct = g.sub_pct - 10 < 40 ? 40 : g.sub_pct - 10; g.sub_key[0] = 0; toast("Tamaño de subtítulos: %d%%", g.sub_pct); break;
        case AC_LIST: g.show_list = !g.show_list; break;
        case AC_FULLSCREEN: osl_app_set_fullscreen(g.app, !osl_app_is_fullscreen(g.app)); break;
        case AC_HELP: osl_dlg_message(g.app, "Ayuda", HELP); break;
        case AC_ABOUT: osl_dlg_message(g.app, "Acerca de", "Osiris Player " VERSION "\n\nReproductor avanzado en C: FFmpeg (libav*) + SDL2 sobre share-lib-sdl-c.\nOpciones de red (User-Agent, cabeceras, proxy, reconexión), resolución de enlaces con yt-dlp y sonda de enlaces."); break;
        case AC_COPYERR: { char e[320]; pl_error(g.pl, e, sizeof e); SDL_SetClipboardText(e); toast("Error copiado"); break; }
        case AC_RETRY: if (g.cur >= 0) play_index(g.cur); break;
        case AC_RESOLVE_CUR: if (g.cur >= 0) { g.fb_tried = true; job_start(J_RESOLVE, P_PLAY, g.cur, g.items.d[g.cur].url, &g.items.d[g.cur].hdr); } break;
        default: (void)tr; break;
    }
}

static void handle_keys(OslUi *u) {
    OslInput *in = &u->in;
    bool ctl = (in->mod & (KMOD_CTRL | KMOD_GUI)) != 0, shift = (in->mod & KMOD_SHIFT) != 0;
    if (osl_key(u, SDLK_o) && ctl) { do_action(AC_OPEN_FILE); return; }
    if (osl_key(u, SDLK_u) && ctl) { do_action(AC_OPEN_URL); return; }
    if (osl_key(u, SDLK_l) && ctl) { do_action(AC_LIST); return; }
    if (ctl) return;
    if (osl_key(u, SDLK_SPACE) || osl_key(u, SDLK_k)) do_action(AC_PAUSE);
    if (in->k_left) seek_rel(shift ? -30 : -5);
    if (in->k_right) seek_rel(shift ? 30 : 5);
    if (in->k_up) { pl_set_volume(g.pl, pl_volume(g.pl) + 5); toast("Volumen: %d%%", pl_volume(g.pl)); }
    if (in->k_down) { pl_set_volume(g.pl, pl_volume(g.pl) - 5); toast("Volumen: %d%%", pl_volume(g.pl)); }
    if (in->k_pgdn) play_next(1);
    if (in->k_pgup) play_next(-1);
    if (osl_key(u, SDLK_m)) do_action(AC_MUTE);
    if (osl_key(u, SDLK_f) || osl_key(u, SDLK_F11)) do_action(AC_FULLSCREEN);
    if (in->k_esc && osl_app_is_fullscreen(g.app)) osl_app_set_fullscreen(g.app, false);
    if (osl_key(u, SDLK_LEFTBRACKET)) do_action(AC_SLOWER);
    if (osl_key(u, SDLK_RIGHTBRACKET)) do_action(AC_FASTER);
    if (osl_key(u, SDLK_BACKSPACE)) do_action(AC_SPEED1);
    if (osl_key(u, SDLK_PERIOD)) do_action(AC_STEP);
    if (osl_key(u, SDLK_l)) do_action(AC_LOOP);
    if (osl_key(u, SDLK_a)) cycle_track(PL_AUDIO);
    if (osl_key(u, SDLK_j)) cycle_track(PL_SUB);
    if (osl_key(u, SDLK_z)) do_action(AC_SD_M);
    if (osl_key(u, SDLK_x)) do_action(AC_SD_P);
    if (osl_key(u, SDLK_MINUS)) do_action(AC_AD_M);
    if (osl_key(u, SDLK_EQUALS)) do_action(AC_AD_P);
    if (osl_key(u, SDLK_s)) do_action(AC_SHOT);
    if (osl_key(u, SDLK_i)) do_action(AC_INFO);
    for (int d = 0; d <= 9; d++) if (osl_key(u, SDLK_0 + d)) { double dur = pl_duration(g.pl); if (dur > 0) pl_seek(g.pl, dur * d / 10.0, false); }
}

/* ------------------------------------------------------------------ lista / items */
static void remove_item(int i) {
    if (i < 0 || (size_t)i >= g.items.n) return;
    if (g.cur == i) { stop_play(); g.cur = -1; } else if (g.cur > i) g.cur--;
    item_free(&g.items.d[i]);
    safe_vec_remove(g.items, (size_t)i);
    if (g.psel >= (int)g.items.n) g.psel = (int)g.items.n - 1;
}
static void items_insert(int pos, Item it) {
    safe_vec_push(g.items, it);
    for (int i = (int)g.items.n - 1; i > pos; i--) g.items.d[i] = g.items.d[i - 1];
    g.items.d[pos] = it;
}
static void cycle_speed(void) {
    static const double S[] = {0.5, 0.75, 1.0, 1.25, 1.5, 2.0, 3.0};
    double c = pl_speed(g.pl);
    int k = 0;
    for (int i = 0; i < 7; i++) if (fabs(S[i] - c) < 0.01) k = i + 1;
    set_speed(S[k % 7]);
}

/* ----------------------------------------------------------------- controles */
static void draw_controls(OslUi *u, SDL_Rect bar, PlState st, bool overlay, bool have) {
    osl_rect(u, bar, overlay ? (SDL_Color){0, 0, 0, 175} : u->th.panel);
    int bh = u->lh + 10, y1 = bar.y + 6, y2 = bar.y + 32, x = bar.x + 10;
    double pos = pl_position(g.pl), dur = pl_duration(g.pl), shown = g.seeking ? g.seek_val : pos;
    char tl[24], tr_[24];
    fmt_time(shown, tl, sizeof tl);
    osl_text(u, x, y1 + (22 - u->lh) / 2, tl, u->th.text, false);
    SDL_Rect sl = {x + 66, y1, bar.w - 20 - 132, 22};
    if (dur > 0) {
        double v = shown;
        int r = osl_slider(u, sl, &v, 0, dur, -1);
        if (r == OSL_SLIDER_DRAG) { g.seeking = true; g.seek_val = v; }
        else if (r == OSL_SLIDER_COMMIT) { pl_seek(g.pl, v, false); g.seeking = false; }
        fmt_time(dur, tr_, sizeof tr_);
    } else { osl_rect(u, (SDL_Rect){sl.x, sl.y + 9, sl.w, 4}, u->th.border); snprintf(tr_, sizeof tr_, have ? "EN VIVO" : "--:--"); }
    osl_text(u, bar.x + bar.w - 10 - osl_text_w(u, tr_, false), y1 + (22 - u->lh) / 2, tr_, u->th.text, false);

    bool playing = st == PL_PLAYING || st == PL_BUFFERING;
    if (osl_button_icon(u, (SDL_Rect){x, y2, bh, bh}, OSL_ICON_PREV, 0)) do_action(AC_PREV);
    osl_tip(u, (SDL_Rect){x, y2, bh, bh}, "Anterior (Re Pág)");
    x += bh + 4;
    if (osl_button_icon(u, (SDL_Rect){x, y2, bh + 8, bh}, playing ? OSL_ICON_PAUSE : OSL_ICON_PLAY, OSL_PRIMARY)) do_action(AC_PAUSE);
    osl_tip(u, (SDL_Rect){x, y2, bh + 8, bh}, "Reproducir / pausa (Espacio)");
    x += bh + 12;
    if (osl_button_icon(u, (SDL_Rect){x, y2, bh, bh}, OSL_ICON_STOP, 0)) do_action(AC_STOP);
    x += bh + 4;
    if (osl_button_icon(u, (SDL_Rect){x, y2, bh, bh}, OSL_ICON_NEXT, 0)) do_action(AC_NEXT);
    osl_tip(u, (SDL_Rect){x, y2, bh, bh}, "Siguiente (Av Pág)");
    x += bh + 14;
    bool mut = pl_muted(g.pl) || pl_volume(g.pl) == 0;
    if (osl_button_icon(u, (SDL_Rect){x, y2, bh, bh}, mut ? OSL_ICON_MUTE : OSL_ICON_VOLUME, 0)) do_action(AC_MUTE);
    x += bh + 6;
    double vol = pl_volume(g.pl);
    if (osl_slider(u, (SDL_Rect){x, y2, 90, bh}, &vol, 0, 200, -1)) { pl_set_volume(g.pl, (int)vol); if (pl_muted(g.pl)) pl_set_mute(g.pl, false); }
    x += 98;
    char vs[16]; snprintf(vs, sizeof vs, "%d%%", pl_volume(g.pl));
    osl_text(u, x, y2 + (bh - u->lh) / 2, vs, u->th.dim, false);
    x += 50;
    int xr = bar.x + bar.w - 10 - bh;
    if (osl_button_icon(u, (SDL_Rect){xr, y2, bh, bh}, osl_app_is_fullscreen(g.app) ? OSL_ICON_WINDOWED : OSL_ICON_FULLSCREEN, 0)) do_action(AC_FULLSCREEN);
    osl_tip(u, (SDL_Rect){xr, y2, bh, bh}, "Pantalla completa (F)");
    xr -= bh + 4;
    if (osl_button_icon(u, (SDL_Rect){xr, y2, bh, bh}, OSL_ICON_LIST, g.show_list ? OSL_ACTIVE : 0)) do_action(AC_LIST);
    osl_tip(u, (SDL_Rect){xr, y2, bh, bh}, "Lista de reproducción (Ctrl+L)");
    int limit = xr - 8;
    PlTrack tr[32];
    char al[48] = "—", sl2[48] = "off", lb[64];
    int na = pl_tracks(g.pl, PL_AUDIO, tr, 32);
    for (int i = 0; i < na; i++) if (tr[i].selected) safe_strlcpy(al, tr[i].lang[0] ? tr[i].lang : "pista", sizeof al);
    int ns = pl_tracks(g.pl, PL_SUB, tr, 32);
    for (int i = 0; i < ns; i++) if (tr[i].selected) safe_strlcpy(sl2, tr[i].lang[0] ? tr[i].lang : (tr[i].external ? "ext" : "pista"), sizeof sl2);
    struct { char text[64]; int kind; } B[6];
    snprintf(B[0].text, 64, "%.2fx", pl_speed(g.pl)); B[0].kind = 0;
    snprintf(B[1].text, 64, "Audio: %s", al); B[1].kind = 1;
    snprintf(B[2].text, 64, "Sub: %s", sl2); B[2].kind = 2;
    snprintf(B[3].text, 64, "Bucle: %s", LOOP_NAMES[g.loop]); B[3].kind = 3;
    snprintf(B[4].text, 64, "Aspecto: %s", ASPECT_NAMES[g.aspect]); B[4].kind = 4;
    snprintf(B[5].text, 64, "Info"); B[5].kind = 5;
    (void)lb;
    for (int i = 0; i < 6; i++) {
        int w = osl_text_w(u, B[i].text, false) + 22;
        if (x + w > limit) break;
        bool act = (B[i].kind == 5 && g.show_info);
        if (osl_button(u, (SDL_Rect){x, y2, w, bh}, B[i].text, act ? OSL_ACTIVE : 0)) {
            switch (B[i].kind) { case 0: cycle_speed(); break; case 1: cycle_track(PL_AUDIO); break; case 2: cycle_track(PL_SUB); break; case 3: do_action(AC_LOOP); break; case 4: do_action(AC_ASPECT); break; default: do_action(AC_INFO); }
        }
        x += w + 6;
    }
}

static void msg_center(OslUi *u, SDL_Rect a, const char *text, SDL_Color c) {
    int w = osl_text_w(u, text, false) + 36, h = u->lh + 20;
    if (w > a.w - 20) w = a.w - 20;
    SDL_Rect r = {a.x + (a.w - w) / 2, a.y + (a.h - h) / 2, w, h};
    osl_rect(u, r, (SDL_Color){0, 0, 0, 190});
    osl_border(u, r, c);
    osl_text_fit(u, r, text, c, false);
}

static void draw_info(OslUi *u, SDL_Rect a, const PlInfo *in, bool have) {
    PlStats s;
    pl_stats(g.pl, &s);
    char lines[14][220];
    int n = 0;
    const char *url = g.cur >= 0 ? (g.items.d[g.cur].play_url ? g.items.d[g.cur].play_url : g.items.d[g.cur].url) : "";
    snprintf(lines[n++], 220, "%s", url);
    if (have) {
        snprintf(lines[n++], 220, "Contenedor: %s   duración: %.1f s   %s%s", in->format, in->duration, in->seekable ? "seek" : "sin seek", in->live ? "   EN VIVO" : "");
        if (in->has_video) snprintf(lines[n++], 220, "Vídeo: %s %dx%d %.2f fps %s  %ld kbps", in->vcodec, in->w, in->h, in->fps, in->pixfmt, in->vbitrate / 1000);
        if (in->has_audio) snprintf(lines[n++], 220, "Audio: %s %d Hz %d canales  %ld kbps", in->acodec, in->arate, in->achannels, in->abitrate / 1000);
        snprintf(lines[n++], 220, "Posición: %.2f s   velocidad: %.2fx   volumen: %d%%", s.clock, pl_speed(g.pl), pl_volume(g.pl));
        snprintf(lines[n++], 220, "Sincronía A/V: %+.0f ms   retardo audio: %+.0f ms   retardo sub: %+.0f ms", s.av_diff * 1000, pl_av_delay(g.pl) * 1000, pl_sub_delay(g.pl) * 1000);
        snprintf(lines[n++], 220, "Fotogramas: %d decodificados, %d descartados   cola: vídeo %d pkt, audio %d pkt, %d frames (%.1f MB)", s.decoded, s.dropped, s.vq_pkts, s.aq_pkts, s.fq_frames, s.qbytes / 1048576.0);
    }
    snprintf(lines[n++], 220, "Interfaz: %.0f fps   red: UA «%s»", g.fps, g.net.ua_preset == UA_CUSTOM ? "personalizado" : UA_NAMES[g.net.ua_preset]);
    int w = 0;
    for (int i = 0; i < n; i++) { int tw = osl_text_w(u, lines[i], false); if (tw > w) w = tw; }
    if (w > a.w - 40) w = a.w - 40;
    SDL_Rect r = {a.x + 10, a.y + 10, w + 20, n * u->lh + 14};
    osl_rect(u, r, (SDL_Color){0, 0, 0, 170});
    for (int i = 0; i < n; i++) osl_text_fit(u, (SDL_Rect){r.x + 6, r.y + 7 + i * u->lh, r.w - 12, u->lh}, lines[i], (SDL_Color){235, 235, 235, 255}, false);
}

static void draw_list(OslUi *u, SDL_Rect p) {
    osl_rect(u, p, u->th.panel);
    osl_border(u, p, u->th.border);
    int fh = u->lh + 8, x = p.x + 8, y = p.y + 8;
    safe_ptr(char) hd = safe_asprintf("Lista (%zu)", g.items.n);
    osl_text(u, x, y + 2, hd, u->th.accent, true);
    y += u->lh + 8;
    int bw = (p.w - 16 - 3 * 4) / 4;
    if (osl_button(u, (SDL_Rect){x, y, bw, fh}, "+Archivo", 0)) do_action(AC_ADD_FILE);
    if (osl_button(u, (SDL_Rect){x + (bw + 4), y, bw, fh}, "+URL", 0)) do_action(AC_OPEN_URL);
    if (osl_button(u, (SDL_Rect){x + 2 * (bw + 4), y, bw, fh}, "Quitar", g.psel >= 0 ? 0 : OSL_DISABLED)) remove_item(g.psel);
    if (osl_button(u, (SDL_Rect){x + 3 * (bw + 4), y, bw, fh}, "Vaciar", g.items.n ? 0 : OSL_DISABLED)) { stop_play(); for (size_t i = 0; i < g.items.n; i++) item_free(&g.items.d[i]); g.items.n = 0; g.cur = g.psel = -1; }
    y += fh + 8;
    SDL_Rect v = {p.x + 4, y, p.w - 8, p.y + p.h - y - 4};
    osl_rect(u, v, u->th.field);
    int rh = u->lh + 8, content = (int)g.items.n * rh;
    osl_scroll_update(u, v, content, &g.scroll_list);
    SDL_Rect sv; bool had;
    osl_clip_push(u, v, &sv, &had);
    int play = -1;
    if (!g.items.n) osl_text_wrap(u, (SDL_Rect){v.x + 4, v.y + 6, v.w - 8, 0}, "Vacía. Arrastra ficheros o URLs aquí, o usa Ctrl+O / Ctrl+U.", u->th.dim, 0, true);
    for (int i = 0; i < (int)g.items.n; i++) {
        SDL_Rect row = {v.x, v.y + i * rh - g.scroll_list, v.w - 10, rh};
        if (row.y + rh < v.y || row.y > v.y + v.h) continue;
        bool hov = osl_hover(u, row);
        if (i == g.cur) osl_rect(u, row, (SDL_Color){u->th.accent.r, u->th.accent.g, u->th.accent.b, 70});
        else if (i == g.psel) osl_rect(u, row, u->th.btnhov);
        else if (hov) osl_rect(u, row, u->th.card);
        safe_ptr(char) lbl = safe_asprintf("%s%d. %s", i == g.cur ? "\xE2\x96\xB6 " : "", i + 1, g.items.d[i].title);
        osl_text_fit(u, row, lbl, i == g.cur ? u->th.accent : u->th.text, i == g.cur);
        if (hov && u->in.pressed) { g.psel = i; if (u->in.clicks >= 2) play = i; }
        osl_tip(u, row, g.items.d[i].url);
    }
    osl_clip_pop(u, sv, had);
    osl_scroll_draw(u, v, content, g.scroll_list);
    if (play >= 0) play_index(play);
}

/* --------------------------------------------------------------------- menús */
static int menu_build(int w, const char **it, int *act) {
    int n = 0;
#define ADD(a, ...) do { snprintf(g.menu_txt[n], 260, __VA_ARGS__); it[n] = g.menu_txt[n]; act[n] = (a); n++; } while (0)
    PlTrack tr[32];
    char l[200];
    switch (w) {
        case MN_FILE:
            ADD(AC_OPEN_FILE, "Abrir fichero…  Ctrl+O"); ADD(AC_OPEN_URL, "Abrir URL…  Ctrl+U"); ADD(AC_ADD_FILE, "Añadir fichero a la lista…"); ADD(AC_NONE, "---");
            ADD(AC_OPEN_M3U, "Cargar lista M3U…"); ADD(AC_SAVE_M3U, "Guardar lista como M3U…"); ADD(AC_NONE, "---");
            ADD(AC_NETVIEW, "Red y probador de enlaces…"); ADD(AC_NONE, "---"); ADD(AC_HELP, "Ayuda y atajos"); ADD(AC_ABOUT, "Acerca de"); ADD(AC_QUIT, "Salir");
            break;
        case MN_PLAY:
            ADD(AC_PAUSE, "Reproducir / pausa  Espacio"); ADD(AC_STOP, "Detener"); ADD(AC_PREV, "Anterior  Re Pág"); ADD(AC_NEXT, "Siguiente  Av Pág"); ADD(AC_NONE, "---");
            ADD(AC_BACK5, "Retroceder 5 s  ←"); ADD(AC_FWD5, "Avanzar 5 s  →"); ADD(AC_BACK60, "Retroceder 1 min"); ADD(AC_FWD60, "Avanzar 1 min"); ADD(AC_STEP, "Fotograma siguiente  .");
            ADD(AC_NONE, "---"); ADD(AC_SLOWER, "Más lenta  [      (ahora %.2fx)", pl_speed(g.pl)); ADD(AC_FASTER, "Más rápida  ]"); ADD(AC_SPEED1, "Velocidad normal  Retroceso");
            ADD(AC_NONE, "---"); ADD(AC_LOOP, "Bucle: %s  L", LOOP_NAMES[g.loop]);
            break;
        case MN_VIDEO:
            ADD(AC_ASPECT, "Relación de aspecto: %s", ASPECT_NAMES[g.aspect]); ADD(AC_ROT, "Rotar 90° (ahora %d°)", g.rot * 90); ADD(AC_FLIPH, "Voltear horizontal%s", (g.flip & 1) ? "  ✓" : "");
            ADD(AC_FLIPV, "Voltear vertical%s", (g.flip & 2) ? "  ✓" : ""); ADD(AC_ZOOMIN, "Zoom +  (%d%%)", g.zoom); ADD(AC_ZOOMOUT, "Zoom −"); ADD(AC_ZOOM1, "Restablecer vídeo");
            ADD(AC_NONE, "---"); ADD(AC_SHOT, "Captura de pantalla  S"); ADD(AC_INFO, "Información de reproducción  I%s", g.show_info ? "  ✓" : ""); ADD(AC_FULLSCREEN, "Pantalla completa  F");
            break;
        case MN_AUDIO: {
            int na = pl_tracks(g.pl, PL_AUDIO, tr, 32);
            for (int i = 0; i < na && n < 20; i++) { track_label(&tr[i], l, sizeof l); ADD(AC_AUDIO_BASE + tr[i].id, "%s%s", tr[i].selected ? "● " : "    ", l); }
            if (!na) ADD(AC_NONE, "(sin pistas de audio)");
            ADD(AC_NONE, "---"); ADD(AC_MUTE, "Silenciar  M%s", pl_muted(g.pl) ? "  ✓" : ""); ADD(AC_AD_M, "Retardo de audio −50 ms  -"); ADD(AC_AD_P, "Retardo de audio +50 ms  =  (ahora %+d ms)", (int)lround(pl_av_delay(g.pl) * 1000));
            break;
        }
        case MN_SUB: {
            int ns = pl_tracks(g.pl, PL_SUB, tr, 32);
            bool any = false;
            for (int i = 0; i < ns; i++) if (tr[i].selected) any = true;
            ADD(AC_SUB_OFF, "%sDesactivados", any ? "    " : "● ");
            for (int i = 0; i < ns && n < 20; i++) { track_label(&tr[i], l, sizeof l); ADD(AC_SUB_BASE + tr[i].id, "%s%s", tr[i].selected ? "● " : "    ", l); }
            ADD(AC_SUB_LOAD, "Cargar subtítulos…"); ADD(AC_NONE, "---"); ADD(AC_SD_M, "Retardo −100 ms  Z"); ADD(AC_SD_P, "Retardo +100 ms  X  (ahora %+d ms)", (int)lround(pl_sub_delay(g.pl) * 1000));
            ADD(AC_SUB_BIG, "Tamaño +  (%d%%)", g.sub_pct); ADD(AC_SUB_SMALL, "Tamaño −");
            break;
        }
    }
#undef ADD
    return n;
}
static void draw_menus(OslUi *u, int mb) {
    for (int w = MN_FILE; w <= MN_SUB; w++) {
        if (!g.menu_open[w]) continue;
        const char *it[40]; int act[40];
        int n = menu_build(w, it, act);
        int r = osl_menu(u, g.menu_x, mb, it, n, &g.menu_open[w]);
        if (r >= 0 && act[r] != AC_NONE) do_action(act[r]);
    }
}

/* ------------------------------------------------------------- vista: reproductor */
static void draw_player(OslUi *u, int W, int H) {
    bool fs = osl_app_is_fullscreen(g.app);
    uint32_t now = SDL_GetTicks();
    PlInfo info;
    bool have = pl_info(g.pl, &info);
    PlState st = pl_state(g.pl);
    int bh = u->lh + 10, mb = fs ? 0 : u->lh + 8, ch = 32 + bh + 8, lw = (g.show_list && !fs) ? 300 : 0;
    if (u->in.moved) g.last_move = now;
    bool ctl_vis = !fs || st == PL_PAUSED || st == PL_ERROR || st == PL_IDLE || now - g.last_move < 3000;
    if (!u->focus) handle_keys(u);

    if (!fs) {
        static const char *NAMES[] = {"Archivo", "Reproducción", "Vídeo", "Audio", "Subtítulos"};
        int x = 4;
        osl_rect(u, (SDL_Rect){0, 0, W, mb}, u->th.panel);
        for (int i = 0; i < 5; i++) {
            int w = osl_text_w(u, NAMES[i], false) + 22;
            if (osl_button(u, (SDL_Rect){x, 1, w, mb - 2}, NAMES[i], g.menu_open[i + 1] ? OSL_ACTIVE : 0)) {
                for (int k = 0; k < 6; k++) g.menu_open[k] = 0;
                g.menu_open[i + 1] = 1; g.menu_x = x;
            }
            x += w + 2;
        }
        int w = osl_text_w(u, "Red", false) + 22;
        if (osl_button(u, (SDL_Rect){x + 8, 1, w, mb - 2}, "Red", 0)) g.view = V_NET;
        osl_tip(u, (SDL_Rect){x + 8, 1, w, mb - 2}, "Opciones de red, User-Agent y probador de enlaces");
        if (g.cur >= 0) osl_text_fit(u, (SDL_Rect){x + w + 24, 0, W - x - w - 36, mb}, g.items.d[g.cur].title, u->th.dim, false);
    }
    SDL_Rect area = {0, mb, W - lw, H - mb - (fs ? 0 : ch)};
    SDL_Rect bar = {0, H - ch, W - lw, ch};
    pl_video_update(g.pl, u->r, &g.tex, &g.tw, &g.th);
    SDL_Rect vid = draw_video(u, area, &info, have);
    if (g.shot_req) { take_screenshot(u, vid); g.shot_req = false; }
    if (g.tex && !(g.cur < 0)) draw_subtitle(u, vid);

    if (st == PL_OPENING) msg_center(u, area, "Abriendo…", u->th.text);
    else if (st == PL_BUFFERING) msg_center(u, area, "Almacenando en búfer…", u->th.warn);
    if (g.job.running && g.job.kind == J_RESOLVE) {
        msg_center(u, area, "Resolviendo el enlace con yt-dlp…", u->th.accent);
    }
    if ((st == PL_ERROR || (st == PL_IDLE && g.netmsg[0] && g.cur >= 0)) && !g.job.running) {
        char e[1200] = "";
        if (st == PL_ERROR) { pl_error(g.pl, e, sizeof e); if (g.netmsg[0] && !strstr(g.netmsg, e)) { size_t l = strlen(e); snprintf(e + l, sizeof e - l, "\n%s", g.netmsg); } }
        else safe_strlcpy(e, g.netmsg, sizeof e);
        SDL_Rect pr = {area.x + (area.w - 560) / 2, area.y + area.h / 2 - 70, 560, 140};
        if (pr.x < area.x) { pr.x = area.x; pr.w = area.w; }
        osl_rect(u, pr, (SDL_Color){0, 0, 0, 215});
        osl_border(u, pr, u->th.err);
        osl_text(u, pr.x + 10, pr.y + 8, "No se pudo reproducir", u->th.err, true);
        osl_text_wrap(u, (SDL_Rect){pr.x + 6, pr.y + 12 + u->lh, pr.w - 12, 0}, e, (SDL_Color){235, 235, 235, 255}, 3, true);
        int bw = (pr.w - 20 - 3 * 6) / 4, by = pr.y + pr.h - bh - 10;
        if (osl_button(u, (SDL_Rect){pr.x + 10, by, bw, bh}, "Reintentar", 0)) do_action(AC_RETRY);
        if (osl_button(u, (SDL_Rect){pr.x + 10 + (bw + 6), by, bw, bh}, "yt-dlp", g.cur >= 0 && is_http(g.items.d[g.cur].url) ? 0 : OSL_DISABLED)) do_action(AC_RESOLVE_CUR);
        if (osl_button(u, (SDL_Rect){pr.x + 10 + 2 * (bw + 6), by, bw, bh}, "Copiar error", 0)) { SDL_SetClipboardText(e); toast("Error copiado"); }
        if (osl_button(u, (SDL_Rect){pr.x + 10 + 3 * (bw + 6), by, bw, bh}, "Red…", 0)) g.view = V_NET;
    }
    if (g.cur < 0 && st == PL_IDLE && !g.job.running)
        osl_text_wrap(u, (SDL_Rect){area.x + (area.w - 520) / 2, area.y + area.h / 2 - 40, 520, 0},
                      "Osiris Player\n\nArrastra aquí un fichero, una lista M3U o una URL.\nCtrl+O abrir fichero · Ctrl+U abrir URL · Menú «Red» para el probador de enlaces y el User-Agent.", u->th.dim, 0, true);
    if (g.show_info) draw_info(u, area, &info, have);
    if (ctl_vis) draw_controls(u, bar, st, fs, have);
    if (lw) draw_list(u, (SDL_Rect){W - lw, mb, lw, H - mb});
    osl_app_show_cursor(g.app, ctl_vis);
    /* ratón sobre el vídeo */
    if (osl_hover(u, area) && !(ctl_vis && osl_hover(u, bar))) {
        if (u->in.wheel) { pl_set_volume(g.pl, pl_volume(g.pl) + u->in.wheel * 5); toast("Volumen: %d%%", pl_volume(g.pl)); }
        if (u->in.pressed && !u->active && (st == PL_PLAYING || st == PL_PAUSED || st == PL_BUFFERING)) {
            if (u->in.clicks >= 2) { do_action(AC_PAUSE); do_action(AC_FULLSCREEN); } else do_action(AC_PAUSE);
        }
    }
}

/* ------------------------------------------------------------------ vista: red */
static bool stepper(OslUi *u, int x, int y, int *v, int lo, int hi, int step, const char *suffix) {
    int fh = u->lh + 10;
    bool ch = false;
    if (osl_button(u, (SDL_Rect){x, y, 34, fh}, "-", 0) && *v > lo) { *v -= step; if (*v < lo) *v = lo; ch = true; }
    char b[48];
    snprintf(b, sizeof b, "%d%s", *v, suffix);
    osl_text(u, x + 44, y + (fh - u->lh) / 2, b, u->th.text, false);
    if (osl_button(u, (SDL_Rect){x + 150, y, 34, fh}, "+", 0) && *v < hi) { *v += step; if (*v > hi) *v = hi; ch = true; }
    return ch;
}
static void detect_ytdlp(void) {
    char p[512];
    safe_ptr(char) home = safe_asprintf("%s/.local/bin/yt-dlp", osl_fs_home());
    if (osl_fs_which("yt-dlp", p, sizeof p) || (osl_fs_is_exec(home) && (safe_strlcpy(p, home, sizeof p), true))) { safe_strlcpy(g.net.ytdlp, p, sizeof g.net.ytdlp); toast("yt-dlp: %s", p); }
    else toast("yt-dlp no encontrado (pip install -U yt-dlp)");
}
static void trim(char *s) {
    size_t l = strlen(s);
    while (l && (s[l - 1] == ' ' || s[l - 1] == '\n' || s[l - 1] == '\r' || s[l - 1] == '\t')) s[--l] = 0;
    char *p = s;
    while (*p == ' ' || *p == '\t') p++;
    if (p != s) memmove(s, p, strlen(p) + 1);
}
static const char *YTDL_MODES[] = {"Nunca", "Si falla la apertura directa", "Siempre (páginas de vídeo)"};
static int net_content_h = 900;

static void draw_net(OslUi *u, int W, int H) {
    int fh = u->lh + 10;
    if (osl_button(u, (SDL_Rect){12, 6, 220, fh}, "\xE2\x86\x90 Volver al reproductor", OSL_PRIMARY) || (u->in.k_esc && !u->focus)) { g.view = V_PLAYER; cfg_save(); return; }
    osl_text(u, 250, 6 + (fh - u->lh) / 2, "Red · User-Agent · Probador de enlaces", u->th.accent, true);
    int top = fh + 18, lw = W / 2 - 20;
    if (lw < 420) lw = 420;
    if (lw > 640) lw = 640;
    SDL_Rect view = {12, top, lw, H - top - 34};
    osl_rect(u, view, u->th.bg);
    osl_scroll_update(u, view, net_content_h, &g.scroll_net);
    SDL_Rect sv; bool had;
    osl_clip_push(u, view, &sv, &had);
    int y = view.y - g.scroll_net, y_start = y, lab = 200, wx = view.x + lab, ww = view.w - lab - 16, fw = view.w - 16;
    NetOptions *n = &g.net;
#define LBL(t) osl_text(u, view.x, y + 5, t, u->th.dim, false)
#define SEC(t) do { osl_text(u, view.x, y, t, u->th.accent, true); y += u->lh + 8; } while (0)
    SEC("User-Agent");
    if (g.ua_preset_seen != n->ua_preset) {
        if (n->ua_preset == UA_CUSTOM) safe_strlcpy(g.ua_edit, n->user_agent, sizeof g.ua_edit);
        else if (n->ua_preset == UA_FFMPEG) g.ua_edit[0] = 0;
        else safe_strlcpy(g.ua_edit, UA_STRINGS[n->ua_preset], sizeof g.ua_edit);
        g.ua_preset_seen = n->ua_preset;
    }
    LBL("Perfil");
    int pr = n->ua_preset;
    if (osl_cycle(u, (SDL_Rect){wx, y, ww, fh}, UA_NAMES, UA_COUNT, &pr)) n->ua_preset = pr;
    y += fh + 8;
    osl_input(u, (SDL_Rect){view.x, y, fw, fh}, g.ua_edit, sizeof g.ua_edit, "(FFmpeg usará su propio User-Agent: Lavf/…)");
    if (n->ua_preset != UA_CUSTOM) {
        const char *ref = n->ua_preset == UA_FFMPEG ? "" : UA_STRINGS[n->ua_preset];
        if (strcmp(g.ua_edit, ref)) { n->ua_preset = UA_CUSTOM; safe_strlcpy(n->user_agent, g.ua_edit, sizeof n->user_agent); g.ua_preset_seen = UA_CUSTOM; }
    } else safe_strlcpy(n->user_agent, g.ua_edit, sizeof n->user_agent);
    osl_tip(u, (SDL_Rect){view.x, y, fw, fh}, "Editar el texto crea un perfil «Personalizado». Muchos servidores rechazan el User-Agent de FFmpeg.");
    y += fh + 14;
    SEC("Cabeceras HTTP");
    LBL("Referer"); osl_input(u, (SDL_Rect){wx, y, ww, fh}, n->referer, sizeof n->referer, "https://sitio.com/"); y += fh + 8;
    LBL("Cabeceras extra"); osl_input(u, (SDL_Rect){wx, y, ww, fh}, n->headers, sizeof n->headers, "Nombre: valor | Otro: valor"); y += fh + 8;
    LBL("Cookies"); osl_input(u, (SDL_Rect){wx, y, ww, fh}, n->cookies, sizeof n->cookies, "a=1; b=2"); y += fh + 8;
    LBL("Proxy HTTP"); osl_input(u, (SDL_Rect){wx, y, ww, fh}, n->proxy, sizeof n->proxy, "http://host:puerto"); y += fh + 14;
    SEC("Conexión");
    LBL("Tiempo de espera (s)"); stepper(u, wx, y, &n->timeout_s, 1, 120, 1, " s"); y += fh + 8;
    osl_checkbox(u, wx, y + 3, "Reconectar si se corta", &n->reconnect); y += 28;
    if (n->reconnect) { LBL("Espera entre intentos"); stepper(u, wx, y, &n->reconnect_max_s, 1, 60, 1, " s"); y += fh + 8; }
    osl_checkbox(u, wx, y + 3, "Verificar certificados TLS", &n->tls_verify); y += 28;
    osl_checkbox(u, wx, y + 3, "Baja latencia (directos)", &n->low_latency); y += 34;
    LBL("Búfer de lectura"); stepper(u, wx, y, &n->buffer_mb, 1, 512, 8, " MB"); y += fh + 8;
    LBL("Análisis: tamaño"); stepper(u, wx, y, &n->probesize_kb, 500, 100000, 1000, " KB"); y += fh + 8;
    LBL("Análisis: duración"); stepper(u, wx, y, &n->analyze_ms, 500, 60000, 1000, " ms"); y += fh + 8;
    LBL("Opciones FFmpeg extra"); osl_input(u, (SDL_Rect){wx, y, ww, fh}, n->extra, sizeof n->extra, "clave=valor;clave=valor"); y += fh + 14;
    SEC("yt-dlp");
    LBL("Ruta"); osl_input(u, (SDL_Rect){wx, y, ww - 110, fh}, n->ytdlp, sizeof n->ytdlp, "yt-dlp (se busca en el PATH)");
    if (osl_button(u, (SDL_Rect){wx + ww - 102, y, 102, fh}, "Detectar", 0)) detect_ytdlp();
    y += fh + 8;
    LBL("Usarlo"); int ym = n->ytdl_mode; if (osl_cycle(u, (SDL_Rect){wx, y, ww, fh}, YTDL_MODES, 3, &ym)) n->ytdl_mode = ym; y += fh + 8;
    LBL("Argumentos extra"); osl_input(u, (SDL_Rect){wx, y, ww, fh}, n->ytdl_args, sizeof n->ytdl_args, "--cookies-from-browser firefox"); y += fh + 14;
    SEC("Reproducción");
    osl_checkbox(u, view.x, y + 3, "Reanudar donde lo dejé", &g.resume_on); y += 28;
    osl_checkbox(u, view.x, y + 3, "Activar subtítulos automáticamente", &g.auto_sub); y += 28;
    osl_checkbox(u, view.x, y + 3, "Cargar subtítulos .srt/.ass junto al fichero", &g.auto_ext); y += 34;
    LBL("Idiomas de subtítulos"); osl_input(u, (SDL_Rect){wx, y, ww, fh}, g.sub_lang, sizeof g.sub_lang, "spa,es,eng"); y += fh + 8;
    LBL("Idioma de audio"); osl_input(u, (SDL_Rect){wx, y, ww, fh}, g.audio_lang, sizeof g.audio_lang, "(pista por defecto)"); y += fh + 14;
    SEC("Apariencia");
    const char *th[8]; int nt = osl_ui_theme_count();
    for (int i = 0; i < nt && i < 8; i++) th[i] = osl_ui_theme_name(i);
    LBL("Tema"); int t = g.theme; if (osl_cycle(u, (SDL_Rect){wx, y, ww, fh}, th, nt, &t)) { g.theme = t; osl_ui_theme(u, t); } y += fh + 8;
    LBL("Tamaño de letra"); if (stepper(u, wx, y, &g.font_px, 11, 24, 1, " px")) osl_ui_set_font_px(u, g.font_px); y += fh + 20;
    net_content_h = y - y_start;
    osl_clip_pop(u, sv, had);
    osl_scroll_draw(u, view, net_content_h, g.scroll_net);
#undef LBL
#undef SEC

    /* ---- probador de enlaces ---- */
    int rx = view.x + lw + 22, rw = W - rx - 12, ry = top;
    if (rw < 300) return;
    osl_text(u, rx, ry, "Probador de enlaces y extractor", u->th.accent, true);
    ry += u->lh + 8;
    osl_input(u, (SDL_Rect){rx, ry, rw - 96, fh}, g.url_in, sizeof g.url_in, "https://… (fichero, m3u8, página de vídeo)");
    if (osl_button(u, (SDL_Rect){rx + rw - 90, ry, 90, fh}, "Pegar", 0)) { char *c = SDL_GetClipboardText(); if (c) { safe_strlcpy(g.url_in, c, sizeof g.url_in); trim(g.url_in); SDL_free(c); } }
    ry += fh + 8;
    bool has_url = g.url_in[0] != 0, busy = g.job.running;
    int bx = rx;
    if (osl_button(u, (SDL_Rect){bx, ry, 100, fh}, "Sondear", (has_url && !busy) ? 0 : OSL_DISABLED)) { snprintf(g.report, sizeof g.report, "Sondeando…"); job_start(J_PROBE, P_PROBE_UI, -1, g.url_in, NULL); }
    osl_tip(u, (SDL_Rect){bx, ry, 100, fh}, "Abre el enlace con tus opciones y muestra formato, pistas, HTTP y duración");
    bx += 106;
    if (osl_button(u, (SDL_Rect){bx, ry, 120, fh}, "Reproducir", has_url ? OSL_PRIMARY : OSL_DISABLED)) { open_now(g.url_in); g.view = V_PLAYER; }
    bx += 126;
    if (osl_button(u, (SDL_Rect){bx, ry, 180, fh}, "Extraer con yt-dlp", (has_url && !busy) ? 0 : OSL_DISABLED)) { snprintf(g.report, sizeof g.report, "Ejecutando yt-dlp…"); job_start(J_RESOLVE, P_LIST, -1, g.url_in, NULL); }
    bx += 186;
    if (busy && osl_button(u, (SDL_Rect){bx, ry, 100, fh}, "Cancelar", OSL_DANGER)) { g.job.cancel = 1; toast("Cancelando…"); }
    ry += fh + 8;
    osl_text(u, rx, ry + 5, "Copiar comando:", u->th.dim, false);
    int cx = rx + osl_text_w(u, "Copiar comando:", false) + 14;
    static const char *CN[] = {"ffplay", "mpv", "curl", "yt-dlp"};
    for (int i = 0; i < 4; i++) {
        int w = osl_text_w(u, CN[i], false) + 24;
        if (osl_button(u, (SDL_Rect){cx, ry, w, fh}, CN[i], has_url ? 0 : OSL_DISABLED)) {
            char cmd[4096];
            if (i == 0) net_cmd_ffplay(&g.net, NULL, g.url_in, cmd, sizeof cmd);
            else if (i == 1) net_cmd_mpv(&g.net, NULL, g.url_in, cmd, sizeof cmd);
            else if (i == 2) net_cmd_curl(&g.net, NULL, g.url_in, cmd, sizeof cmd);
            else net_cmd_ytdlp(&g.net, g.url_in, cmd, sizeof cmd);
            SDL_SetClipboardText(cmd); toast("Comando de %s copiado", CN[i]);
        }
        cx += w + 6;
    }
    ry += fh + 10;
    int rep_h = 190;
    SDL_Rect rv = {rx, ry, rw, rep_h};
    osl_rect(u, rv, u->th.field); osl_border(u, rv, u->th.border);
    const char *rt = busy ? (g.job.kind == J_PROBE ? "Sondeando… (pulsa Cancelar para abortar)" : "Ejecutando yt-dlp… (puede tardar unos segundos)") : (g.report[0] ? g.report : "Pega un enlace y pulsa «Sondear» o «Extraer con yt-dlp».");
    int th_ = osl_text_wrap(u, (SDL_Rect){0, 0, rw - 14, 0}, rt, u->th.text, 0, false);
    osl_scroll_update(u, rv, th_ + 8, &g.scroll_rep);
    osl_clip_push(u, rv, &sv, &had);
    osl_text_wrap(u, (SDL_Rect){rv.x + 2, rv.y + 4 - g.scroll_rep, rw - 14, 0}, rt, (!busy && g.report[0] == (char)0xE2 && g.report[1] == (char)0x9C && g.report[2] == (char)0x97) ? u->th.err : u->th.text, 0, true);
    osl_clip_pop(u, sv, had);
    osl_scroll_draw(u, rv, th_ + 8, g.scroll_rep);
    ry += rep_h + 10;
    /* formatos / entradas extraídas con yt-dlp */
    YtResult *r = g.ytres;
    if (r) {
        safe_ptr(char) hd = safe_asprintf("«%s» · %d formatos%s", r->title[0] ? r->title : "?", r->nf, r->best >= 0 ? "   (★ = recomendado)" : "");
        osl_text_fit(u, (SDL_Rect){rx, ry, rw - 150, fh}, hd, u->th.accent, true);
        if (r->is_playlist && osl_button(u, (SDL_Rect){rx + rw - 140, ry, 140, fh}, "Añadir todas", 0)) {
            int first = -1;
            for (int i = 0; i < r->ne; i++) { int k = item_add(r->entries[i].url, r->entries[i].title); if (first < 0) first = k; }
            toast("%d elementos añadidos a la lista", r->ne);
        }
        ry += fh + 4;
        SDL_Rect fv = {rx, ry, rw, H - 34 - ry};
        osl_rect(u, fv, u->th.field); osl_border(u, fv, u->th.border);
        int rh = fh + 4, cnt = r->is_playlist ? r->ne : r->nf, content = cnt * rh;
        osl_scroll_update(u, fv, content, &g.scroll_fmt);
        osl_clip_push(u, fv, &sv, &had);
        for (int i = 0; i < cnt; i++) {
            SDL_Rect row = {fv.x, fv.y + i * rh - g.scroll_fmt, fv.w - 10, rh};
            if (row.y + rh < fv.y || row.y > fv.y + fv.h) continue;
            if (r->is_playlist) {
                osl_text_fit(u, (SDL_Rect){row.x, row.y, row.w - 100, rh}, r->entries[i].title, u->th.text, false);
                if (osl_button(u, (SDL_Rect){row.x + row.w - 92, row.y + 2, 88, rh - 4}, "Reproducir", 0)) { int k = item_add(r->entries[i].url, r->entries[i].title); g.view = V_PLAYER; play_index(k); }
                continue;
            }
            const YtFormat *f = &r->f[i];
            char lbl[260];
            ytdl_format_label(f, lbl, sizeof lbl);
            if (i == r->best) osl_rect(u, row, (SDL_Color){u->th.accent.r, u->th.accent.g, u->th.accent.b, 50});
            safe_ptr(char) l2 = safe_asprintf("%s%s", i == r->best ? "\xE2\x98\x85 " : "   ", lbl);
            osl_text_fit(u, (SDL_Rect){row.x, row.y, row.w - 250, rh}, l2, u->th.text, false);
            int bx2 = row.x + row.w - 246;
            if (osl_button(u, (SDL_Rect){bx2, row.y + 2, 88, rh - 4}, "Reproducir", 0)) { int k = item_add(f->url, r->title[0] ? r->title : f->id); g.items.d[k].hdr = f->hdr; g.view = V_PLAYER; play_index(k); }
            if (osl_button(u, (SDL_Rect){bx2 + 92, row.y + 2, 80, rh - 4}, "Sondear", busy ? OSL_DISABLED : 0)) { snprintf(g.report, sizeof g.report, "Sondeando formato %s…", f->id); job_start(J_PROBE, P_PROBE_UI, -1, f->url, &f->hdr); }
            if (osl_button(u, (SDL_Rect){bx2 + 176, row.y + 2, 66, rh - 4}, "URL", 0)) { SDL_SetClipboardText(f->url); toast("URL del formato %s copiada", f->id); }
        }
        osl_clip_pop(u, sv, had);
        osl_scroll_draw(u, fv, content, g.scroll_fmt);
    }
}

/* -------------------------------------------------------------- tareas y estado */
static void job_poll(void) {
    Job *j = &g.job;
    if (!j->running || !j->done) return;
    pthread_join(j->th, NULL);
    j->running = false;
    if (j->kind == J_PROBE) { safe_strlcpy(g.report, j->report, sizeof g.report); return; }
    if (!j->ok) {
        char e[400] = "";
        if (j->purpose == P_PLAY) pl_error(g.pl, e, sizeof e);
        snprintf(g.netmsg, sizeof g.netmsg, "%s%syt-dlp: %s", e, e[0] ? "\n" : "", j->err);
        snprintf(g.report, sizeof g.report, "✗ yt-dlp: %s", j->err);
        if (j->purpose == P_LIST) toast("yt-dlp falló");
        return;
    }
    YtResult *r = j->res;
    j->res = NULL;
    if (j->purpose == P_LIST) {
        ytdl_free(g.ytres); g.ytres = r; g.scroll_fmt = 0;
        snprintf(g.report, sizeof g.report, "✓ yt-dlp devolvió %d formatos%s. Elige uno de la lista.", r->nf, r->is_playlist ? " (es una lista de reproducción)" : "");
        return;
    }
    int idx = j->idx;
    if (idx < 0 || (size_t)idx >= g.items.n || idx != g.cur) { ytdl_free(r); return; }
    Item *it = &g.items.d[idx];
    if (r->is_playlist && r->ne > 0) {                         /* la URL era una lista: se sustituye por sus entradas */
        free(it->url); free(it->title);
        it->url = safe_strdup(r->entries[0].url); it->title = safe_strdup(r->entries[0].title);
        for (int i = r->ne - 1; i >= 1; i--) { Item n2 = {0}; n2.url = safe_strdup(r->entries[i].url); n2.title = safe_strdup(r->entries[i].title); items_insert(idx + 1, n2); }
        toast("Lista con %d elementos", r->ne);
        ytdl_free(r);
        play_index(idx);
        return;
    }
    if (r->best >= 0) {
        YtFormat *f = &r->f[r->best];
        free(it->play_url); it->play_url = safe_strdup(f->url); it->play_hdr = f->hdr; it->resolved = true;
        if (r->title[0] && (!it->title[0] || !strcmp(it->title, base_name(it->url)))) { free(it->title); it->title = safe_strdup(r->title); }
        char t[300]; snprintf(t, sizeof t, "%s — Osiris Player", it->title); osl_app_set_title(g.app, t);
        start_open(f->url, &f->hdr, resume_get(it->url));
        toast("yt-dlp: formato %s (%s %dp)", f->id, f->ext, f->h);
        ytdl_free(r);
    } else {                                                    /* sin formato automático: que elija el usuario */
        ytdl_free(g.ytres); g.ytres = r; g.view = V_NET; toast("Elige un formato de la lista");
    }
}
static uint32_t end_tick;
static void player_tick(void) {
    PlState st = pl_state(g.pl);
    uint32_t now = SDL_GetTicks();
    if ((st == PL_PLAYING || st == PL_PAUSED || st == PL_BUFFERING) && !g.opened_ok) {
        PlInfo i;
        if (pl_info(g.pl, &i)) {
            g.opened_ok = true;
            apply_auto();
            if (i.title[0] && g.cur >= 0 && !strcmp(g.items.d[g.cur].title, base_name(g.items.d[g.cur].url))) {
                free(g.items.d[g.cur].title); g.items.d[g.cur].title = safe_strdup(i.title);
            }
        }
    }
    if (st == PL_ERROR && !g.fb_tried && g.cur >= 0 && g.net.ytdl_mode == YTDL_FALLBACK && is_http(g.items.d[g.cur].url) && !g.job.running) {
        g.fb_tried = true;
        if (job_start(J_RESOLVE, P_PLAY, g.cur, g.items.d[g.cur].url, &g.items.d[g.cur].hdr)) toast("No se pudo abrir directamente: probando con yt-dlp…");
    }
    if (st == PL_ENDED && g.opened_ok && now - end_tick > 1500) {
        end_tick = now;
        if (g.cur >= 0) osl_json_obj_del(g.resume, g.items.d[g.cur].url);
        PlInfo i;
        if (g.loop == 1) { if (pl_info(g.pl, &i) && i.seekable) pl_seek(g.pl, 0, false); else if (g.cur >= 0) play_index(g.cur); }
        else if (g.loop == 2 || g.cur + 1 < (int)g.items.n) play_next(1);
    }
}

static void frame(OslApp *app, void *user) {
    (void)user;
    OslUi *u = osl_app_ui(app);
    int W, H;
    osl_app_size(app, &W, &H);
    uint32_t now = SDL_GetTicks();
    job_poll();
    player_tick();
    g.fps_frames++;
    if (now - g.fps_tick >= 1000) { g.fps = g.fps_frames * 1000.0 / (now - g.fps_tick); g.fps_frames = 0; g.fps_tick = now; }
    bool menus = false;
    for (int k = 0; k < 6; k++) if (g.menu_open[k]) menus = true;
    bool activity = u->in.moved || u->in.pressed || u->in.released || u->in.nkeys || u->in.wheel;
    OslInput saved;
    if (menus) saved = osl_ui_block(u);
    if (g.view == V_PLAYER) draw_player(u, W, H); else draw_net(u, W, H);
    if (menus) osl_ui_unblock(u, saved);
    draw_menus(u, osl_app_is_fullscreen(app) ? 0 : u->lh + 8);
    static uint32_t boost;
    if (activity) boost = now + 800;
    PlState st = pl_state(g.pl);
    bool playing = st == PL_PLAYING || st == PL_BUFFERING || st == PL_OPENING || g.job.running;
    osl_app_set_continuous(app, g.view == V_PLAYER && (playing || now < boost));
}

static void usage(void) {
    puts("Uso: osiris-player [opciones] [fichero|URL ...]\n"
         "  --net          abrir la vista de red / probador de enlaces\n"
         "  -h, --help     esta ayuda\n  -v, --version  versión\n"
         "Variables: OSL_FONT, OSL_FONT_DIR (fuentes), OSL_SHOT=f.bmp, OSL_SCRIPT=f.txt (pruebas de interfaz)");
}

int main(int argc, char **argv) {
    av_log_set_level(AV_LOG_ERROR);
    bool net_view = false;
    SAFE_VEC(char *) args = {0};
    for (int i = 1; i < argc; i++) {
        if (!strcmp(argv[i], "-h") || !strcmp(argv[i], "--help")) { usage(); return 0; }
        else if (!strcmp(argv[i], "-v") || !strcmp(argv[i], "--version")) { puts("Osiris Player " VERSION); return 0; }
        else if (!strcmp(argv[i], "--net")) net_view = true;
        else if (argv[i][0] == '-' && argv[i][1]) { fprintf(stderr, "Opción desconocida: %s\n", argv[i]); usage(); return 2; }
        else safe_vec_push(args, argv[i]);
    }
    g.zoom = 100; g.cur = -1; g.psel = -1;
    g.pl = pl_create();
    cfg_load();
    g.cur = -1;
    g.app = osl_app_create(&(OslAppDesc){.title = "Osiris Player", .app_id = "osiris-player", .w = 1180, .h = 720, .min_w = 760, .min_h = 420, .font_px = g.font_px, .theme = g.theme});
    if (!g.app) { pl_destroy(g.pl); return 1; }
    osl_app_on_drop(g.app, on_drop, NULL);
    g.view = net_view ? V_NET : V_PLAYER;
    g.ua_preset_seen = -1;
    int first = -1;
    for (size_t i = 0; i < args.n; i++) { int k = item_add(args.d[i], NULL); if (first < 0) first = k; }
    safe_vec_free(args);
    if (first >= 0) play_index(first);
    osl_app_run(g.app, frame, NULL);
    resume_save();
    cfg_save();
    if (g.job.running) { g.job.cancel = 1; pthread_detach(g.job.th); }
    pl_destroy(g.pl);
    if (g.tex) SDL_DestroyTexture(g.tex);
    if (g.subtex) SDL_DestroyTexture(g.subtex);
    if (g.subfont) TTF_CloseFont(g.subfont);
    ytdl_free(g.ytres);
    for (size_t i = 0; i < g.items.n; i++) item_free(&g.items.d[i]);
    safe_vec_free(g.items);
    osl_json_free(g.resume);
    osl_app_destroy(g.app);
    return 0;
}
