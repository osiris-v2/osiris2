#include "netopts.h"
#include "osl/osl_safe.h"
#include <string.h>

const char *const UA_NAMES[UA_COUNT] = {"Chrome (Windows)", "Firefox (Linux)", "Safari (iPhone)", "Chrome (Android)", "Smart TV (Tizen)",
                                        "VLC", "Kodi", "FFmpeg (predeterminado)", "Personalizado"};
const char *const UA_STRINGS[UA_COUNT] = {
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Mozilla/5.0 (X11; Linux x86_64; rv:125.0) Gecko/20100101 Firefox/125.0",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 17_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Mobile/15E148 Safari/604.1",
    "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36",
    "Mozilla/5.0 (SMART-TV; Linux; Tizen 6.0) AppleWebKit/537.36 (KHTML, like Gecko) 76.0.3809.146/6.0 TV Safari/537.36",
    "VLC/3.0.20 LibVLC/3.0.20",
    "Kodi/20.2 (X11; Linux x86_64) App_Bitness/64 Version/20.2",
    "",
    ""};

void net_defaults(NetOptions *n) {
    memset(n, 0, sizeof *n);
    n->ua_preset = 0;                                   /* Chrome: la mayoría de servidores rechaza el UA de FFmpeg */
    safe_strlcpy(n->user_agent, UA_STRINGS[0], sizeof n->user_agent);
    n->timeout_s = 15; n->reconnect = true; n->reconnect_max_s = 5; n->tls_verify = true;
    n->probesize_kb = 5000; n->analyze_ms = 5000; n->buffer_mb = 24; n->ytdl_mode = YTDL_FALLBACK;
}

#define STRS(X) X(user_agent) X(referer) X(headers) X(cookies) X(proxy) X(extra) X(ytdlp) X(ytdl_args)
#define INTS(X) X(ua_preset) X(timeout_s) X(reconnect_max_s) X(probesize_kb) X(analyze_ms) X(buffer_mb) X(ytdl_mode)
#define BOOLS(X) X(reconnect) X(tls_verify) X(low_latency)

void net_load(NetOptions *n, const OslJson *o) {
    net_defaults(n);
    if (!o || o->t != OSL_J_OBJ) return;
#define S(f) safe_strlcpy(n->f, osl_json_str_or(o, #f, n->f), sizeof n->f);
#define I(f) n->f = (int)osl_json_num_or(o, #f, n->f);
#define B(f) n->f = osl_json_bool_or(o, #f, n->f);
    STRS(S) INTS(I) BOOLS(B)
#undef S
#undef I
#undef B
    if (n->ua_preset < 0 || n->ua_preset >= UA_COUNT) n->ua_preset = 0;
    if (n->timeout_s < 1) n->timeout_s = 1;
    if (n->buffer_mb < 1) n->buffer_mb = 1;
    if (n->ytdl_mode < 0 || n->ytdl_mode > 2) n->ytdl_mode = YTDL_FALLBACK;
}
OslJson *net_save(const NetOptions *n) {
    OslJson *o = osl_json_new(OSL_J_OBJ);
#define S(f) osl_json_obj_set(o, #f, osl_json_str(n->f));
#define I(f) osl_json_obj_set(o, #f, osl_json_num(n->f));
#define B(f) osl_json_obj_set(o, #f, osl_json_bool(n->f));
    STRS(S) INTS(I) BOOLS(B)
#undef S
#undef I
#undef B
    return o;
}

void net_effective(const NetOptions *n, const ItemHdr *it, char *ua, size_t uan, char *ref, size_t refn, char *hdr, size_t hdrn) {
    const char *u = "";
    if (it && it->ua[0]) u = it->ua;
    else if (n->ua_preset == UA_CUSTOM) u = n->user_agent;
    else if (n->ua_preset != UA_FFMPEG) u = UA_STRINGS[n->ua_preset];
    safe_strlcpy(ua, u, uan);
    safe_strlcpy(ref, (it && it->referer[0]) ? it->referer : n->referer, refn);
    SBuf h = {0};
    if (n->headers[0]) sb_str(&h, n->headers);
    if (it && it->headers[0]) { if (h.len) sb_str(&h, " | "); sb_str(&h, it->headers); }
    if (n->cookies[0]) { if (h.len) sb_str(&h, " | "); sb_str(&h, "Cookie: "); sb_str(&h, n->cookies); }
    safe_strlcpy(hdr, h.d ? h.d : "", hdrn);
    sb_free(&h);
}

static void shq(SBuf *b, const char *s) {                 /* 'texto' con comillas simples escapadas */
    sb_push(b, '\'');
    for (; *s; s++) { if (*s == '\'') sb_str(b, "'\\''"); else sb_push(b, *s); }
    sb_push(b, '\'');
}
/* recorre "A: b | C: d" */
static void each_header(const char *h, void (*fn)(SBuf *, const char *), SBuf *b) {
    safe_ptr(char) cp = safe_strdup(h);
    char *p = cp;
    while (p && *p) {
        char *e = strstr(p, " | ");
        if (e) *e = 0;
        while (*p == ' ') p++;
        if (*p) fn(b, p);
        p = e ? e + 3 : NULL;
    }
}
static void h_ffplay(SBuf *b, const char *h) { sb_str(b, h); sb_str(b, "\\r\\n"); }
static void h_mpv(SBuf *b, const char *h) { if (b->len) sb_push(b, ','); sb_str(b, h); }
static void h_curl(SBuf *b, const char *h) { sb_str(b, " -H "); shq(b, h); }
static void h_ytdl(SBuf *b, const char *h) { sb_str(b, " --add-header "); shq(b, h); }

void net_cmd_ffplay(const NetOptions *n, const ItemHdr *it, const char *url, char *out, size_t cap) {
    char ua[512], ref[512], hdr[2048];
    net_effective(n, it, ua, sizeof ua, ref, sizeof ref, hdr, sizeof hdr);
    SBuf b = {0}, hh = {0};
    sb_str(&b, "ffplay");
    if (ua[0]) { sb_str(&b, " -user_agent "); shq(&b, ua); }
    if (ref[0]) { sb_str(&b, " -referer "); shq(&b, ref); }
    if (hdr[0]) { each_header(hdr, h_ffplay, &hh); sb_str(&b, " -headers $'"); sb_str(&b, hh.d ? hh.d : ""); sb_str(&b, "'"); }
    if (n->proxy[0]) { sb_str(&b, " -http_proxy "); shq(&b, n->proxy); }
    if (n->reconnect) sb_str(&b, " -reconnect 1 -reconnect_streamed 1");
    if (!n->tls_verify) sb_str(&b, " -tls_verify 0");
    sb_str(&b, " -i "); shq(&b, url);
    safe_strlcpy(out, b.d, cap);
    sb_free(&b); sb_free(&hh);
}
void net_cmd_mpv(const NetOptions *n, const ItemHdr *it, const char *url, char *out, size_t cap) {
    char ua[512], ref[512], hdr[2048];
    net_effective(n, it, ua, sizeof ua, ref, sizeof ref, hdr, sizeof hdr);
    SBuf b = {0}, hh = {0};
    sb_str(&b, "mpv");
    if (ua[0]) { sb_str(&b, " --user-agent="); shq(&b, ua); }
    if (ref[0]) { sb_str(&b, " --referrer="); shq(&b, ref); }
    if (hdr[0]) { each_header(hdr, h_mpv, &hh); sb_str(&b, " --http-header-fields="); shq(&b, hh.d ? hh.d : ""); }
    if (n->proxy[0]) { sb_str(&b, " --http-proxy="); shq(&b, n->proxy); }
    if (!n->tls_verify) sb_str(&b, " --tls-verify=no");
    sb_push(&b, ' '); shq(&b, url);
    safe_strlcpy(out, b.d, cap);
    sb_free(&b); sb_free(&hh);
}
void net_cmd_curl(const NetOptions *n, const ItemHdr *it, const char *url, char *out, size_t cap) {
    char ua[512], ref[512], hdr[2048];
    net_effective(n, it, ua, sizeof ua, ref, sizeof ref, hdr, sizeof hdr);
    SBuf b = {0};
    sb_str(&b, "curl -L -I");
    if (ua[0]) { sb_str(&b, " -A "); shq(&b, ua); }
    if (ref[0]) { sb_str(&b, " -e "); shq(&b, ref); }
    if (hdr[0]) each_header(hdr, h_curl, &b);
    if (n->proxy[0]) { sb_str(&b, " -x "); shq(&b, n->proxy); }
    if (!n->tls_verify) sb_str(&b, " -k");
    sb_push(&b, ' '); shq(&b, url);
    safe_strlcpy(out, b.d, cap);
    sb_free(&b);
}
void net_cmd_ytdlp(const NetOptions *n, const char *url, char *out, size_t cap) {
    char ua[512], ref[512], hdr[2048];
    net_effective(n, NULL, ua, sizeof ua, ref, sizeof ref, hdr, sizeof hdr);
    SBuf b = {0};
    sb_str(&b, "yt-dlp -F");
    if (ua[0]) { sb_str(&b, " --user-agent "); shq(&b, ua); }
    if (ref[0]) { sb_str(&b, " --referer "); shq(&b, ref); }
    if (hdr[0]) each_header(hdr, h_ytdl, &b);
    if (n->proxy[0]) { sb_str(&b, " --proxy "); shq(&b, n->proxy); }
    if (n->ytdl_args[0]) { sb_push(&b, ' '); sb_str(&b, n->ytdl_args); }
    sb_str(&b, " -- "); shq(&b, url);
    safe_strlcpy(out, b.d, cap);
    sb_free(&b);
}
