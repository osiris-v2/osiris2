#define _GNU_SOURCE
#include "ytdl.h"
#include "osl/osl.h"
#include <string.h>

static void fmt_copy(char *d, size_t n, const OslJson *o, const char *k) { safe_strlcpy(d, osl_json_str_or(o, k, ""), n); }

static void headers_from(ItemHdr *h, const OslJson *hh) {
    if (!hh || hh->t != OSL_J_OBJ) return;
    SBuf b = {0};
    for (size_t i = 0; i < hh->n; i++) {
        const OslJson *v = hh->v[i];
        if (v->t != OSL_J_STR) continue;
        const char *k = hh->k[i];
        if (!strcasecmp(k, "User-Agent")) safe_strlcpy(h->ua, v->str, sizeof h->ua);
        else if (!strcasecmp(k, "Referer")) safe_strlcpy(h->referer, v->str, sizeof h->referer);
        else if (!strcasecmp(k, "Accept-Encoding") || !strcasecmp(k, "Accept")) continue;   /* ffmpeg no descomprime gzip */
        else { if (b.len) sb_str(&b, " | "); sb_str(&b, k); sb_str(&b, ": "); sb_str(&b, v->str); }
    }
    if (b.d) safe_strlcpy(h->headers, b.d, sizeof h->headers);
    sb_free(&b);
}

static void parse_format(YtFormat *f, const OslJson *o, const OslJson *top_headers) {
    memset(f, 0, sizeof *f);
    fmt_copy(f->id, sizeof f->id, o, "format_id"); fmt_copy(f->ext, sizeof f->ext, o, "ext"); fmt_copy(f->protocol, sizeof f->protocol, o, "protocol");
    fmt_copy(f->note, sizeof f->note, o, "format_note"); fmt_copy(f->vcodec, sizeof f->vcodec, o, "vcodec"); fmt_copy(f->acodec, sizeof f->acodec, o, "acodec");
    f->w = (int)osl_json_num_or(o, "width", 0); f->h = (int)osl_json_num_or(o, "height", 0);
    f->tbr = osl_json_num_or(o, "tbr", 0); f->fps = osl_json_num_or(o, "fps", 0);
    f->url = safe_strdup(osl_json_str_or(o, "url", ""));
    headers_from(&f->hdr, top_headers);                         /* base: cabeceras generales del vídeo... */
    headers_from(&f->hdr, osl_json_obj_get(o, "http_headers")); /* ...y las del formato mandan */
    f->has_v = f->vcodec[0] ? strcmp(f->vcodec, "none") != 0 : (f->w > 0 || f->h > 0);
    f->has_a = f->acodec[0] ? strcmp(f->acodec, "none") != 0 : !f->has_v;
    if (!f->vcodec[0] && f->h == 0 && f->has_a) f->has_v = false;
}
static bool direct_proto(const char *p) { return !p[0] || !strncmp(p, "http", 4) || !strncmp(p, "m3u8", 4); }

static int pick_best(const YtResult *r) {
    int best = -1;
    double bs = -1;
    for (int pass = 0; pass < 3 && best < 0; pass++)
        for (int i = 0; i < r->nf; i++) {
            const YtFormat *f = &r->f[i];
            if (!f->url || !f->url[0] || !direct_proto(f->protocol)) continue;
            bool ok = pass == 0 ? (f->has_v && f->has_a) : pass == 1 ? f->has_v : f->has_a;
            if (!ok) continue;
            double s = f->h * 1e6 + f->tbr;
            if (s > bs) { bs = s; best = i; }
        }
    return best;
}

bool ytdl_resolve(const NetOptions *net, const char *url, YtResult **out, char *err, size_t ec) {
    *out = NULL;
    char ua[512], ref[512], hdr[2048];
    net_effective(net, NULL, ua, sizeof ua, ref, sizeof ref, hdr, sizeof hdr);
    SAFE_VEC(char *) av = {0};
#define ARG(s) do { char *_a = safe_strdup(s); safe_vec_push(av, _a); } while (0)
    ARG(net->ytdlp[0] ? net->ytdlp : "yt-dlp"); ARG("-J"); ARG("--no-playlist"); ARG("--no-warnings");
    if (ua[0]) { ARG("--user-agent"); ARG(ua); }
    if (ref[0]) { ARG("--referer"); ARG(ref); }
    if (net->proxy[0]) { ARG("--proxy"); ARG(net->proxy); }
    if (hdr[0]) {
        safe_ptr(char) cp = safe_strdup(hdr);
        for (char *s = cp; s && *s;) {
            char *e = strstr(s, " | ");
            if (e) *e = 0;
            while (*s == ' ') s++;
            if (*s) { ARG("--add-header"); ARG(s); }
            s = e ? e + 3 : NULL;
        }
    }
    if (net->ytdl_args[0]) { char **ex = osl_proc_split(net->ytdl_args); for (size_t i = 0; ex[i]; i++) { char *a = ex[i]; safe_vec_push(av, a); } free(ex); }
    ARG("--"); ARG(url);
    safe_vec_push(av, (char *)NULL);
#undef ARG
    char *so = NULL, *se = NULL;
    size_t sl;
    int st = 0;
    bool ran = osl_proc_capture_ex(av.d, 90000, 48u << 20, &so, &sl, &se, &st, err, ec);
    osl_argv_free(av.d);
    if (!ran) return false;
    if (st != 0 || !so || !*so) {
        const char *m = (se && *se) ? se : "yt-dlp no devolvió datos";
        const char *e = strstr(m, "ERROR:");
        snprintf(err, ec, "%.*s", (int)(ec > 8 ? ec - 8 : ec), e ? e : m);
        err[strcspn(err, "\n")] = 0;
        free(so); free(se);
        return false;
    }
    free(se);
    OslJson *j = osl_json_parse(so, err, ec);
    free(so);
    if (!j) return false;
    YtResult *r = (YtResult *)safe_calloc(1, sizeof *r);
    r->best = -1;
    safe_strlcpy(r->title, osl_json_str_or(j, "title", ""), sizeof r->title);
    safe_strlcpy(r->webpage, osl_json_str_or(j, "webpage_url", url), sizeof r->webpage);
    OslJson *ent = osl_json_obj_get(j, "entries");
    if (ent && ent->t == OSL_J_ARR) {
        r->is_playlist = true;
        for (size_t i = 0; i < ent->n; i++) {
            OslJson *e = ent->v[i];
            const char *u = osl_json_str_or(e, "webpage_url", osl_json_str_or(e, "url", ""));
            if (!*u) continue;
            r->entries = (YtEntry *)safe_reallocarray(r->entries, (size_t)r->ne + 1, sizeof *r->entries);
            r->entries[r->ne].url = safe_strdup(u);
            r->entries[r->ne].title = safe_strdup(osl_json_str_or(e, "title", u));
            r->ne++;
        }
    }
    OslJson *fm = osl_json_obj_get(j, "formats"), *th = osl_json_obj_get(j, "http_headers");
    if (fm && fm->t == OSL_J_ARR) {
        for (size_t i = 0; i < fm->n; i++) {
            if (!*osl_json_str_or(fm->v[i], "url", "")) continue;
            r->f = (YtFormat *)safe_reallocarray(r->f, (size_t)r->nf + 1, sizeof *r->f);
            parse_format(&r->f[r->nf++], fm->v[i], th);
        }
    }
    if (!r->nf && *osl_json_str_or(j, "url", "")) {            /* un solo enlace sin lista de formatos */
        r->f = (YtFormat *)safe_calloc(1, sizeof *r->f);
        parse_format(&r->f[0], j, th);
        if (!r->f[0].id[0]) safe_strlcpy(r->f[0].id, "directo", sizeof r->f[0].id);
        r->f[0].has_v = r->f[0].has_a = true;
        r->nf = 1;
    }
    r->best = pick_best(r);
    osl_json_free(j);
    if (!r->nf && !r->ne) { ytdl_free(r); snprintf(err, ec, "yt-dlp no encontró ningún formato reproducible"); return false; }
    *out = r;
    return true;
}
void ytdl_free(YtResult *r) {
    if (!r) return;
    for (int i = 0; i < r->nf; i++) free(r->f[i].url);
    for (int i = 0; i < r->ne; i++) { free(r->entries[i].url); free(r->entries[i].title); }
    free(r->f); free(r->entries); free(r);
}
void ytdl_format_label(const YtFormat *f, char *out, size_t n) {
    char res[32] = "", tb[24] = "";
    if (f->h) snprintf(res, sizeof res, "%dp", f->h); else if (f->has_a && !f->has_v) snprintf(res, sizeof res, "audio");
    if (f->tbr > 0) snprintf(tb, sizeof tb, "%.0fk", f->tbr);
    snprintf(out, n, "%-8s %-6s %-5s %-5s %s%s%s", f->id, f->ext, res, tb, f->protocol, (f->has_v && !f->has_a) ? "  [solo vídeo]" : "", (!f->has_v && f->has_a) ? "  [solo audio]" : "");
}
