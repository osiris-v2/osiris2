#!/usr/bin/env bash
# Genera los medios de prueba en /tmp/pm (necesita ffmpeg). Idempotente.
set -e
D="${PM_DIR:-/tmp/pm}"; HERE="$(cd "$(dirname "$0")" && pwd)"
mkdir -p "$D/hls"; cp "$HERE"/fixtures/*.srt "$HERE/fixtures/server.py" "$HERE/fixtures/fake-ytdlp" "$D/"; chmod +x "$D/fake-ytdlp"
cd "$D"
[ -f test.mp4 ]  || ffmpeg -loglevel error -y -f lavfi -i testsrc2=size=640x360:rate=25:duration=12 -f lavfi -i sine=frequency=440:duration=12 -i en.srt -c:v libx264 -pix_fmt yuv420p -preset ultrafast -g 25 -c:a aac -c:s mov_text -metadata:s:s:0 language=eng test.mp4
[ -f multi.mkv ] || ffmpeg -loglevel error -y -f lavfi -i testsrc2=size=640x360:rate=25:duration=12 -f lavfi -i sine=frequency=440:duration=12 -f lavfi -i sine=frequency=880:duration=12 -i en.srt -i es.srt -map 0:v -map 1:a -map 2:a -map 3 -map 4 -c:v libx264 -pix_fmt yuv420p -preset ultrafast -g 25 -c:a aac -c:s srt -metadata:s:a:0 language=eng -metadata:s:a:1 language=spa -metadata:s:s:0 language=eng -metadata:s:s:1 language=spa multi.mkv
[ -f audio.mp3 ] || ffmpeg -loglevel error -y -f lavfi -i sine=frequency=330:duration=6 -c:a libmp3lame audio.mp3
[ -f hls/index.m3u8 ] || ffmpeg -loglevel error -y -i test.mp4 -map 0:v -map 0:a -c copy -f hls -hls_time 4 -hls_playlist_type vod -hls_segment_filename hls/seg%d.ts hls/index.m3u8
echo "medios listos en $D"
