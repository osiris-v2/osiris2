import http.server, os, re
LOG = open(os.environ.get('PM_DIR', '/tmp/pm') + '/server.log', 'a', buffering=1)
class H(http.server.BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def do_HEAD(self): self.do_GET(head=True)
    def do_GET(self, head=False):
        ua = self.headers.get('User-Agent', '')
        LOG.write('%s | UA=%s | X-Test=%s | Range=%s | Referer=%s\n' % (self.path, ua, self.headers.get('X-Test'), self.headers.get('Range'), self.headers.get('Referer')))
        if 'Mozilla' not in ua: self.send_error(403, 'bad user agent'); return
        path = self.path.split('?')[0]
        if path.startswith('/hdr/'):
            if self.headers.get('X-Test') != '1': self.send_error(401, 'missing header'); return
            path = path[4:]
        fn = os.path.join(os.environ.get('PM_DIR', '/tmp/pm'), path.lstrip('/'))
        if not os.path.isfile(fn): self.send_error(404); return
        size = os.path.getsize(fn); start, end, code = 0, size - 1, 200
        m = re.match(r'bytes=(\d*)-(\d*)', self.headers.get('Range', ''))
        if m:
            if m.group(1): start = int(m.group(1))
            if m.group(2): end = min(int(m.group(2)), size - 1)
            if not m.group(1) and m.group(2): start = max(0, size - int(m.group(2))); end = size - 1
            code = 206
        ctype = {'.mp4': 'video/mp4', '.m3u8': 'application/vnd.apple.mpegurl', '.ts': 'video/mp2t', '.mp3': 'audio/mpeg'}.get(os.path.splitext(fn)[1], 'application/octet-stream')
        self.send_response(code)
        self.send_header('Content-Type', ctype); self.send_header('Accept-Ranges', 'bytes'); self.send_header('Content-Length', str(end - start + 1))
        if code == 206: self.send_header('Content-Range', 'bytes %d-%d/%d' % (start, end, size))
        self.end_headers()
        if head: return
        with open(fn, 'rb') as f:
            f.seek(start); left = end - start + 1
            try:
                while left > 0:
                    b = f.read(min(65536, left))
                    if not b: break
                    self.wfile.write(b); left -= len(b)
            except (BrokenPipeError, ConnectionResetError): pass
http.server.ThreadingHTTPServer(('127.0.0.1', 8765), H).serve_forever()
