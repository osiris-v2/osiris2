/* Test del resolvedor yt-dlp (con /tmp/pm/fake-ytdlp) y reproducción con las cabeceras que devuelve. */
#include "../src/ytdl.h"
#include "../src/player.h"
#include <unistd.h>
#include <stdio.h>
#include <string.h>
static int fails;
#define CHECK(c) do { if (!(c)) { printf("  FALLO línea %d: %s\n", __LINE__, #c); fails++; } } while (0)
int main(void) {
    SDL_Init(SDL_INIT_AUDIO | SDL_INIT_VIDEO);
    NetOptions net; net_defaults(&net); snprintf(net.ytdlp, sizeof net.ytdlp, "/tmp/pm/fake-ytdlp");
    char err[400]; YtResult *r;
    CHECK(ytdl_resolve(&net, "https://ex.test/watch", &r, err, sizeof err));
    CHECK(r->nf == 4 && !r->is_playlist && !strcmp(r->title, "Vídeo de prueba"));
    printf("   mejor formato: %s\n", r->best >= 0 ? r->f[r->best].id : "(ninguno)");
    CHECK(r->best >= 0 && !strcmp(r->f[r->best].id, "hls-360"));                 /* mayor altura con audio+vídeo */
    CHECK(!r->f[0].has_v && r->f[0].has_a && r->f[1].has_v && !r->f[1].has_a);
    CHECK(!strcmp(r->f[2].hdr.ua, "Mozilla/5.0 (from-ytdlp)") && !strstr(r->f[2].hdr.headers, "Accept-Encoding") && !strcmp(r->f[2].hdr.referer, "https://ex.test/"));
    CHECK(!strcmp(r->f[3].hdr.ua, "Mozilla/5.0 (fmt18)") && !strcmp(r->f[3].hdr.headers, "X-Test: 1"));
    char lbl[200]; ytdl_format_label(&r->f[1], lbl, sizeof lbl); printf("   %s\n", lbl); CHECK(strstr(lbl, "solo vídeo"));
    /* lo que se le pasó a yt-dlp: UA del preset, referer, etc. */
    FILE *f = fopen("/tmp/pm/ytdlp.args", "r"); char args[1024] = ""; if (f) { fgets(args, sizeof args, f); fclose(f); }
    printf("   args: %.160s\n", args); CHECK(strstr(args, "--user-agent Mozilla/5.0 (Windows") && strstr(args, "-J --no-playlist"));
    /* reproducir el formato 18: necesita la cabecera X-Test que sólo da yt-dlp */
    net.ua_preset = UA_FFMPEG;
    Player *p = pl_create();
    pl_open(p, r->f[3].url, &net, &r->f[3].hdr, 0);
    for (int i = 0; i < 200 && pl_state(p) == PL_OPENING; i++) usleep(20000);
    { char e2[300]; pl_error(p, e2, sizeof e2); printf("   estado=%d err=%s\n", pl_state(p), e2); }
    CHECK(pl_state(p) == PL_PLAYING || pl_state(p) == PL_BUFFERING); usleep(600000); CHECK(pl_position(p) > 0.3);
    pl_open(p, r->f[3].url, &net, NULL, 0);                                        /* sin las cabeceras de yt-dlp falla */
    for (int i = 0; i < 200 && pl_state(p) == PL_OPENING; i++) usleep(20000);
    CHECK(pl_state(p) == PL_ERROR);
    pl_destroy(p); ytdl_free(r);
    CHECK(ytdl_resolve(&net, "https://ex.test/playlist", &r, err, sizeof err) && r->is_playlist && r->ne == 2 && !strcmp(r->entries[1].url, "https://ex.test/v/2")); ytdl_free(r);
    CHECK(!ytdl_resolve(&net, "https://badsite.test/x", &r, err, sizeof err) && strstr(err, "Unsupported URL")); printf("   error: %s\n", err);
    snprintf(net.ytdlp, sizeof net.ytdlp, "/no/existe/yt-dlp"); CHECK(!ytdl_resolve(&net, "https://ex.test/watch", &r, err, sizeof err)); printf("   sin binario: %s\n", err);
    printf(fails ? "\n%d FALLOS\n" : "\nOK: resolvedor yt-dlp\n", fails);
    return fails != 0;
}
