/* Test del motor contra medios reales (ver tests/README en la documentación). SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy */
#include "../src/player.h"
#include <unistd.h>
#include <math.h>
#include <stdio.h>
#include <string.h>

static int fails;
#define CHECK(c) do { if (!(c)) { printf("  FALLO línea %d: %s\n", __LINE__, #c); fails++; } } while (0)
static SDL_Renderer *R; static SDL_Texture *TEX; static int TW, TH;
static NetOptions NET;

/* reproduce durante ms llamando a pl_video_update a ~60 Hz; devuelve fotogramas mostrados */
static int run_ms(Player *p, int ms) {
    int shown = 0; double last = -1;
    for (int t = 0; t < ms; t += 16) {
        SDL_Texture *before = TEX; (void)before;
        PlStats s0; pl_stats(p, &s0);
        pl_video_update(p, R, &TEX, &TW, &TH);
        PlStats s1; pl_stats(p, &s1);
        (void)s0; (void)s1;
        extern double g_last_pts_probe(Player *);
        double lp = g_last_pts_probe(p);
        if (lp != last) { shown++; last = lp; }
        usleep(16000);
    }
    return shown;
}
static bool wait_state(Player *p, PlState want, int ms) {
    for (int t = 0; t < ms; t += 20) { PlState s = pl_state(p); if (s == want) return true; if (s == PL_ERROR && want != PL_ERROR) return false; usleep(20000); }
    return false;
}
static bool wait_open(Player *p, int ms) { for (int t = 0; t < ms; t += 20) { PlState s = pl_state(p); if (s != PL_OPENING) return s != PL_ERROR; usleep(20000); } return false; }
#define OPEN(p, url) pl_open(p, url, &NET, NULL, 0)

int main(void) {
    SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO);
    SDL_Window *w = SDL_CreateWindow("t", 0, 0, 640, 360, SDL_WINDOW_HIDDEN);
    R = SDL_CreateRenderer(w, -1, SDL_RENDERER_SOFTWARE);
    net_defaults(&NET);
    Player *p = pl_create();
    PlInfo in; char err[400];

    puts("1. MP4 local: reproducción y sincronía");
    OPEN(p, "/tmp/pm/test.mp4"); CHECK(wait_open(p, 5000));
    CHECK(pl_info(p, &in) && in.w == 640 && in.h == 360 && in.has_audio && in.has_video && in.duration > 11 && in.duration < 13 && !strcmp(in.vcodec, "h264") && in.fps > 24 && in.fps < 26);
    double p0 = pl_position(p); int shown = run_ms(p, 3000); double p1 = pl_position(p);
    printf("   pos %.2f -> %.2f, fotogramas mostrados=%d\n", p0, p1, shown);
    CHECK(p1 - p0 > 2.5 && p1 - p0 < 3.6); CHECK(shown > 60 && shown < 90);
    PlStats st; pl_stats(p, &st); printf("   dropped=%d decoded=%d av_diff=%.3f\n", st.dropped, st.decoded, st.av_diff);
    CHECK(fabs(st.av_diff) < 0.15);

    puts("2. Pausa / reanudar");
    pl_pause(p, 1); usleep(100000); double pa = pl_position(p); run_ms(p, 600); double pb = pl_position(p);
    CHECK(pl_state(p) == PL_PAUSED); CHECK(fabs(pb - pa) < 0.1);
    pl_step_frame(p); run_ms(p, 200); CHECK(pl_position(p) - pb > 0.02 && pl_position(p) - pb < 0.1);
    pl_pause(p, 0); run_ms(p, 800); CHECK(pl_position(p) - pb > 0.6);

    puts("3. Seek (preciso)");
    pl_seek(p, 8.0, false); run_ms(p, 700);
    double ps = pl_position(p); printf("   tras seek(8): %.2f\n", ps);
    CHECK(ps > 8.2 && ps < 9.4);
    pl_seek(p, -5.0, true); run_ms(p, 600); ps = pl_position(p); printf("   tras seek(-5): %.2f\n", ps); CHECK(ps > 3.2 && ps < 4.6);
    for (int i = 0; i < 10; i++) { pl_seek(p, i * 1.1, false); run_ms(p, 40); }   /* tormenta de seeks */
    run_ms(p, 500); CHECK(pl_state(p) == PL_PLAYING);

    puts("4. Velocidad 2x");
    pl_seek(p, 1.0, false); run_ms(p, 600); pl_set_speed(p, 2.0); run_ms(p, 400); double s0 = pl_position(p); run_ms(p, 2000); double s1 = pl_position(p);
    printf("   en 2 s reales avanzó %.2f s\n", s1 - s0); CHECK(s1 - s0 > 3.4 && s1 - s0 < 4.6);
    pl_set_speed(p, 1.0);

    puts("5. Subtítulos embebidos del MP4 (mov_text) + externo");
    pl_seek(p, 1.2, false); run_ms(p, 400);
    PlTrack tr[16]; int ns = pl_tracks(p, PL_SUB, tr, 16); printf("   pistas de subtítulos: %d (%s)\n", ns, ns ? tr[0].lang : "-"); CHECK(ns == 1);
    pl_select_track(p, PL_SUB, tr[0].id); pl_seek(p, 1.5, false); run_ms(p, 800);
    char sub[256]; bool has = pl_subtitle_text(p, sub, sizeof sub); printf("   texto: '%s'\n", sub);
    CHECK(has && strstr(sub, "Hello world"));
    CHECK(pl_load_subtitle_file(p, "/tmp/pm/es.srt", err, sizeof err)); pl_seek(p, 1.5, false); run_ms(p, 400);
    has = pl_subtitle_text(p, sub, sizeof sub); printf("   externo: '%s'\n", sub); CHECK(has && strstr(sub, "Hola mundo") && strstr(sub, "áéíóú"));
    pl_set_sub_delay(p, 5.0); pl_seek(p, 6.5, false); run_ms(p, 400);   /* con +5 s, a 6.5 s se ve lo que estaba en 1.5 s */
    has = pl_subtitle_text(p, sub, sizeof sub); CHECK(has && strstr(sub, "Hola mundo")); pl_set_sub_delay(p, 0);
    pl_select_track(p, PL_SUB, -1); run_ms(p, 100); CHECK(!pl_subtitle_text(p, sub, sizeof sub));

    puts("6. MKV: 2 pistas de audio + 2 de subtítulos, cambio de pista");
    OPEN(p, "/tmp/pm/multi.mkv"); CHECK(wait_open(p, 5000)); run_ms(p, 500);
    int na = pl_tracks(p, PL_AUDIO, tr, 16); CHECK(na == 2 && !strcmp(tr[0].lang, "eng") && !strcmp(tr[1].lang, "spa") && tr[0].selected);
    int aid = tr[1].id; pl_select_track(p, PL_AUDIO, aid); run_ms(p, 1000);
    na = pl_tracks(p, PL_AUDIO, tr, 16); CHECK(tr[1].selected && !tr[0].selected); printf("   estado tras cambiar audio=%d pos=%.2f\n", pl_state(p), pl_position(p)); CHECK(pl_state(p) == PL_PLAYING);
    ns = pl_tracks(p, PL_SUB, tr, 16); CHECK(ns == 2); pl_select_track(p, PL_SUB, tr[1].id); pl_seek(p, 1.5, false); run_ms(p, 900);
    has = pl_subtitle_text(p, sub, sizeof sub); printf("   sub spa: '%s'\n", sub); CHECK(has && strstr(sub, "Hola mundo"));
    double pp = pl_position(p); run_ms(p, 1000); CHECK(pl_position(p) - pp > 0.8);

    puts("7. Fin de fichero (MP3 a 4x)");
    OPEN(p, "/tmp/pm/audio.mp3"); CHECK(wait_open(p, 5000)); CHECK(pl_info(p, &in) && !in.has_video && in.has_audio); pl_set_speed(p, 4.0);
    CHECK(wait_state(p, PL_ENDED, 6000)); printf("   estado final: %d\n", pl_state(p));

    puts("8. Red: User-Agent, cabeceras, HLS, errores");
    NET.ua_preset = UA_FFMPEG;                                   /* UA de ffmpeg: el servidor de prueba responde 403 */
    OPEN(p, "http://127.0.0.1:8765/test.mp4"); wait_open(p, 8000); pl_error(p, err, sizeof err); printf("   UA ffmpeg -> %s / '%s'\n", pl_state(p) == PL_ERROR ? "ERROR" : "?", err);
    CHECK(pl_state(p) == PL_ERROR && (strstr(err, "403") || strstr(err, "orbidden")));
    NET.ua_preset = 0;                                           /* Chrome */
    OPEN(p, "http://127.0.0.1:8765/test.mp4"); CHECK(wait_open(p, 8000)); CHECK(pl_info(p, &in) && in.seekable); run_ms(p, 1500); CHECK(pl_position(p) > 1.0);
    pl_seek(p, 9.0, false); run_ms(p, 900); CHECK(pl_position(p) > 8.8);                     /* seek por HTTP Range */
    OPEN(p, "http://127.0.0.1:8765/hdr/test.mp4"); wait_open(p, 8000); pl_error(p, err, sizeof err); printf("   sin cabecera -> '%s'\n", err); CHECK(pl_state(p) == PL_ERROR);
    snprintf(NET.headers, sizeof NET.headers, "X-Test: 1");
    OPEN(p, "http://127.0.0.1:8765/hdr/test.mp4"); CHECK(wait_open(p, 8000)); run_ms(p, 800); CHECK(pl_position(p) > 0.5);
    NET.headers[0] = 0;
    OPEN(p, "http://127.0.0.1:8765/hls/index.m3u8"); CHECK(wait_open(p, 8000)); CHECK(pl_info(p, &in)); printf("   HLS: formato=%s dur=%.1f\n", in.format, in.duration);
    run_ms(p, 2500); CHECK(pl_position(p) > 1.8); pl_seek(p, 9.0, false); run_ms(p, 1500); CHECK(pl_position(p) > 8.9);
    CHECK(OPEN(p, "http://127.0.0.1:9/nada")); wait_open(p, 15000); CHECK(pl_state(p) == PL_ERROR);

    puts("9. Sonda");
    static char rep[4096];
    CHECK(pl_probe("http://127.0.0.1:8765/hls/index.m3u8", &NET, NULL, rep, sizeof rep, NULL)); printf("%s", rep); CHECK(strstr(rep, "hls"));
    NET.ua_preset = UA_FFMPEG; CHECK(!pl_probe("http://127.0.0.1:8765/test.mp4", &NET, NULL, rep, sizeof rep, NULL)); CHECK(strstr(rep, "rechaza")); NET.ua_preset = 0;
    ItemHdr ih = {0}; snprintf(ih.ua, sizeof ih.ua, "Mozilla/5.0 (item)"); NET.ua_preset = UA_FFMPEG;
    CHECK(pl_probe("http://127.0.0.1:8765/test.mp4", &NET, &ih, rep, sizeof rep, NULL));    /* el UA de la entrada manda */
    NET.ua_preset = 0;

    puts("10. Estrés: abrir/cerrar rápido, cerrar durante apertura");
    for (int i = 0; i < 25; i++) { OPEN(p, i % 2 ? "/tmp/pm/test.mp4" : "http://127.0.0.1:8765/hls/index.m3u8"); usleep((i % 5) * 20000); if (i % 3 == 0) run_ms(p, 100); pl_close(p); }
    OPEN(p, "/tmp/pm/test.mp4"); CHECK(wait_open(p, 5000)); run_ms(p, 500); CHECK(pl_position(p) > 0.3);

    pl_destroy(p);
    if (TEX) SDL_DestroyTexture(TEX);
    printf(fails ? "\n%d FALLOS\n" : "\nOK: motor de reproducción\n", fails);
    return fails != 0;
}
