#!/usr/bin/env bash
# Ejecuta TODAS las pruebas del reproductor: motor (ASan/UBSan), resolvedor yt-dlp e interfaz por script.
# Requisitos: ffmpeg, python3, SDL2, libav*-dev. No necesita pantalla ni sonido (drivers "dummy").
set -u
HERE="$(cd "$(dirname "$0")" && pwd)"; ROOT="$HERE/.."; PM="${PM_DIR:-/tmp/pm}"; PT=/tmp/pt
export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy SDL_RENDER_DRIVER=software ASAN_OPTIONS=detect_leaks=0
fail=0; ok() { echo "  ✓ $1"; }; bad() { echo "  ✗ $1"; fail=$((fail+1)); }
"$HERE/make-media.sh" >/dev/null || { echo "No se pudieron generar los medios (¿ffmpeg?)"; exit 1; }
( cd "$ROOT" && make -s test asan >/dev/null 2>&1 ) || { echo "Fallo de compilación"; exit 1; }
mkdir -p "$PT/home"
( cd "$PM" && exec python3 server.py ) >/dev/null 2>&1 & SRV=$!
trap 'kill $SRV 2>/dev/null' EXIT; sleep 1.2
echo "== Motor =="; : > "$PM/server.log"
if "$ROOT/build/test_player" 2>&1 | grep -q "OK: motor de reproducción"; then ok "motor (10 bloques)"; else bad "motor"; fi
echo "== Resolvedor yt-dlp =="
if "$ROOT/build/test_ytdl" 2>&1 | grep -q "OK: resolvedor yt-dlp"; then ok "resolvedor y cabeceras"; else bad "resolvedor"; fi
run_gui() {  # nombre script cfg-json args...
  local name="$1" script="$2" cfg="$3"; shift 3
  rm -rf "$PT/cfg-$name"; mkdir -p "$PT/cfg-$name/osiris-player"; echo "$cfg" > "$PT/cfg-$name/osiris-player/config.json"
  HOME="$PT/home" XDG_CONFIG_HOME="$PT/cfg-$name" OSL_SCRIPT="$HERE/gui/$script" timeout 90 "$ROOT/build/osiris-player-asan" "$@" >/dev/null 2>"$PT/$name.err"; return $?
}
echo "== Interfaz (scripts) =="
run_gui play play.txt '{"net":{"ytdlp":"'$PM'/fake-ytdlp"}}' "$PM/test.mp4" && [ -s "$PT/play3.bmp" ] && ok "reproducir, información y menús" || bad "play"
: > "$PM/server.log"
run_gui net net-probe.txt '{"net":{"ytdlp":"'$PM'/fake-ytdlp"}}' --net && [ -s "$PT/net2.bmp" ] && ok "vista de red: sonda y extracción" || bad "net"
grep -q "hls/index.m3u8" "$PM/server.log" && ok "la sonda llegó al servidor" || bad "sonda sin tráfico"
: > "$PM/server.log"
run_gui fallback fallback.txt '{"net":{"ua_preset":7,"ytdlp":"'$PM'/fake-ytdlp","ytdl_mode":1,"timeout_s":5}}' http://127.0.0.1:8765/test.mp4
grep -q "UA=Lavf" "$PM/server.log" && grep -q "hls/seg0.ts | UA=Mozilla/5.0 (from-ytdlp)" "$PM/server.log" && ok "403 -> yt-dlp -> HLS con UA/Referer de yt-dlp" || bad "fallback a yt-dlp"
echo; [ $fail -eq 0 ] && echo "TODAS LAS PRUEBAS OK" || echo "$fail FALLOS"; exit $fail
