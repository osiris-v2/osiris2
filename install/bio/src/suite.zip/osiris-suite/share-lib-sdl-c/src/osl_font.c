#define _GNU_SOURCE
#include "osl/osl_font.h"
#include "osl/osl_fs.h"
#include "osl/osl_safe.h"
#include <dirent.h>
#include <strings.h>
#include <sys/stat.h>

size_t osl_font_dirs(char out[][512], size_t max) {
    size_t n = 0;
#define ADD(...) do { if (n < max) { snprintf(out[n], 512, __VA_ARGS__); n++; } } while (0)
    const char *env = getenv("OSL_FONT_DIR"), *home = osl_fs_home(), *xd = getenv("XDG_DATA_HOME");
    if (env && *env) ADD("%s", env);
    safe_ptr(char) exe = osl_fs_exe_dir();
    ADD("%s/share-fonts", exe);
    ADD("%s/../share-fonts", exe);
    ADD("%s/../../share-fonts", exe);
    ADD("./share-fonts");
    ADD("../share-fonts");
    ADD("%s/osiris/share-fonts", (xd && *xd) ? xd : "~");
    if (!(xd && *xd)) ADD("%s/.local/share/osiris/share-fonts", home);
    ADD("/usr/local/share/osiris/share-fonts");
    ADD("/usr/share/fonts");
    ADD("/usr/local/share/fonts");
    ADD("%s/.fonts", home);
    ADD("%s/.local/share/fonts", home);
    ADD("/Library/Fonts");
    ADD("/System/Library/Fonts");
    ADD("/System/Library/Fonts/Supplemental");
#undef ADD
    return n;
}

static bool find_in(const char *root, const char *name, int depth, char *out, size_t on) {
    DIR *d = opendir(root);
    if (!d) return false;
    struct dirent *e;
    bool found = false;
    while (!found && (e = readdir(d))) {
        if (e->d_name[0] == '.') continue;
        char full[1024];
        snprintf(full, sizeof full, "%s/%s", root, e->d_name);
        if (!strcasecmp(e->d_name, name)) { struct stat st; if (stat(full, &st) == 0 && S_ISREG(st.st_mode)) { safe_strlcpy(out, full, on); found = true; } }
        else if (depth > 0 && osl_fs_is_dir(full)) found = find_in(full, name, depth - 1, out, on);
    }
    closedir(d);
    return found;
}

char *osl_font_find(bool bold) {
    const char *env = getenv(bold ? "OSL_FONT_BOLD" : "OSL_FONT");
    if (env && osl_fs_exists(env)) return safe_strdup(env);
    static const char *const REG[] = {"DejaVuSans.ttf", "LiberationSans-Regular.ttf", "NotoSans-Regular.ttf", "Ubuntu-R.ttf",
                                      "Roboto-Regular.ttf", "FiraSans-Regular.ttf", "Arial.ttf", "font.ttf", NULL};
    static const char *const BLD[] = {"DejaVuSans-Bold.ttf", "LiberationSans-Bold.ttf", "NotoSans-Bold.ttf", "Ubuntu-B.ttf",
                                      "Roboto-Bold.ttf", "FiraSans-Bold.ttf", "Arial Bold.ttf", NULL};
    const char *const *names = bold ? BLD : REG;
    static char dirs[24][512];
    size_t nd = osl_font_dirs(dirs, 24);
    char out[1024];
    for (size_t i = 0; i < nd; i++) {
        bool user_dir = strstr(dirs[i], "share-fonts") != NULL;      /* carpetas propias: cualquier nombre en orden */
        for (int k = 0; names[k]; k++)
            if (find_in(dirs[i], names[k], user_dir ? 1 : 4, out, sizeof out)) return safe_strdup(out);
    }
    return NULL;
}
