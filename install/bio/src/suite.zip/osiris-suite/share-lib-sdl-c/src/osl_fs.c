#define _GNU_SOURCE
#include "osl/osl_fs.h"
#include <ctype.h>
#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <strings.h>
#include <sys/stat.h>
#include <unistd.h>
#ifdef __APPLE__
#include <mach-o/dyld.h>
#endif

static void seterr(char *e, size_t n, const char *fmt, const char *a, int en) {
    if (e && n) snprintf(e, n, fmt, a, strerror(en));
}
bool osl_fs_exists(const char *p) { struct stat st; return p && *p && stat(p, &st) == 0; }
bool osl_fs_is_dir(const char *p) { struct stat st; return p && *p && stat(p, &st) == 0 && S_ISDIR(st.st_mode); }
bool osl_fs_is_exec(const char *p) { struct stat st; return p && *p && stat(p, &st) == 0 && S_ISREG(st.st_mode) && access(p, X_OK) == 0; }
const char *osl_fs_home(void) { const char *h = getenv("HOME"); return (h && *h) ? h : "/"; }

char *osl_fs_expand(const char *p) {
    SBuf b = {0};
    if (p[0] == '~' && (p[1] == '/' || !p[1])) { sb_str(&b, osl_fs_home()); p++; }
    while (*p) {
        if (*p == '$' && (isalpha((unsigned char)p[1]) || p[1] == '_' || p[1] == '{')) {
            const char *s = p + 1;
            bool br = (*s == '{');
            if (br) s++;
            char name[64];
            size_t n = 0;
            while ((isalnum((unsigned char)*s) || *s == '_') && n < sizeof name - 1) name[n++] = *s++;
            name[n] = 0;
            if (br && *s != '}') { sb_push(&b, *p++); continue; }   /* ${ sin cerrar: literal */
            if (br) s++;
            const char *v = getenv(name);
            if (v) sb_str(&b, v);
            p = s;
        } else sb_push(&b, *p++);
    }
    return sb_take(&b);
}
char *osl_fs_join(const char *a, const char *b) {
    if (!a || !*a) return safe_strdup(b ? b : "");
    if (!b || !*b) return safe_strdup(a);
    if (b[0] == '/') return safe_strdup(b);
    size_t la = strlen(a);
    return safe_asprintf("%s%s%s", a, a[la - 1] == '/' ? "" : "/", b);
}
const char *osl_fs_basename(const char *p) { const char *s = strrchr(p, '/'); return s ? s + 1 : p; }
char *osl_fs_dirname(const char *p) {
    const char *s = strrchr(p, '/');
    if (!s) return safe_strdup(".");
    if (s == p) return safe_strdup("/");
    return safe_strndup(p, (size_t)(s - p));
}
char *osl_fs_exe_dir(void) {
    char buf[1024];
#ifdef __APPLE__
    uint32_t n = sizeof buf;
    if (_NSGetExecutablePath(buf, &n) != 0) return safe_strdup(".");
#else
    ssize_t n = readlink("/proc/self/exe", buf, sizeof buf - 1);
    if (n <= 0) return safe_strdup(".");
    buf[n] = 0;
#endif
    return osl_fs_dirname(buf);
}
char *osl_fs_config_dir(const char *app) {
    const char *x = getenv("XDG_CONFIG_HOME");
    if (x && *x) return safe_asprintf("%s/%s", x, app);
    return safe_asprintf("%s/.config/%s", osl_fs_home(), app);
}
bool osl_fs_mkdir_p(const char *path) {
    safe_ptr(char) t = safe_strdup(path);
    for (char *p = t + 1; *p; p++)
        if (*p == '/') { *p = 0; if (mkdir(t, 0755) != 0 && errno != EEXIST) return false; *p = '/'; }
    return mkdir(t, 0755) == 0 || errno == EEXIST;
}
bool osl_fs_which(const char *name, char *out, size_t n) {
    const char *path = getenv("PATH");
    if (!path || !*name) return false;
    safe_ptr(char) cp = safe_strdup(path);
    char *sv = NULL;
    for (char *d = strtok_r(cp, ":", &sv); d; d = strtok_r(NULL, ":", &sv)) {
        char c[1024];
        snprintf(c, sizeof c, "%s/%s", d, name);
        if (osl_fs_is_exec(c)) { if (out) safe_strlcpy(out, c, n); return true; }
    }
    return false;
}
char *osl_fs_read_all(const char *path, size_t max, size_t *len, char *err, size_t ec) {
    FILE *f = fopen(path, "rb");
    if (!f) { seterr(err, ec, "No se pudo abrir '%s': %s", path, errno); return NULL; }
    struct stat st;
    if (fstat(fileno(f), &st) != 0 || !S_ISREG(st.st_mode)) { fclose(f); seterr(err, ec, "'%s' no es un fichero regular%s", path, 0); return NULL; }
    if ((uintmax_t)st.st_size > max) { fclose(f); seterr(err, ec, "'%s' es demasiado grande%s", path, 0); return NULL; }
    size_t sz = (size_t)st.st_size;
    char *buf = (char *)safe_malloc(sz + 1);
    size_t rd = fread(buf, 1, sz, f);
    fclose(f);
    buf[rd] = 0;
    if (len) *len = rd;
    return buf;
}
bool osl_fs_write_atomic(const char *path, const char *data, size_t len, bool backup, char *err, size_t ec) {
    safe_ptr(char) dir = osl_fs_dirname(path);
    osl_fs_mkdir_p(dir);
    if (backup && osl_fs_exists(path)) {
        size_t ol; char *old = osl_fs_read_all(path, 64u << 20, &ol, NULL, 0);
        if (old) {
            safe_ptr(char) bak = safe_asprintf("%s.bak", path);
            FILE *b = fopen(bak, "wb");
            if (b) { fwrite(old, 1, ol, b); fclose(b); }
            free(old);
        }
    }
    safe_ptr(char) tmp = safe_asprintf("%s.tmp.%d", path, (int)getpid());
    FILE *f = fopen(tmp, "wb");
    if (!f) { seterr(err, ec, "No se pudo escribir '%s': %s", tmp, errno); return false; }
    bool ok = fwrite(data, 1, len, f) == len && fflush(f) == 0 && fsync(fileno(f)) == 0;
    int en = errno;
    ok = (fclose(f) == 0) && ok;
    if (!ok) { unlink(tmp); seterr(err, ec, "Error al escribir '%s': %s", path, en); return false; }
    if (rename(tmp, path) != 0) { en = errno; unlink(tmp); seterr(err, ec, "No se pudo reemplazar '%s': %s", path, en); return false; }
    return true;
}
static int cmp_ent(const void *a, const void *b) {
    const OslDirEnt *x = (const OslDirEnt *)a, *y = (const OslDirEnt *)b;
    if (x->is_dir != y->is_dir) return x->is_dir ? -1 : 1;
    return strcasecmp(x->name, y->name);
}
bool osl_fs_list(const char *dir, OslDirList *out, bool show_hidden) {
    DIR *d = opendir(dir);
    if (!d) return false;
    struct dirent *e;
    while ((e = readdir(d))) {
        if (!strcmp(e->d_name, ".") || !strcmp(e->d_name, "..")) continue;
        if (!show_hidden && e->d_name[0] == '.') continue;
        safe_ptr(char) full = osl_fs_join(dir, e->d_name);
        OslDirEnt ent = {safe_strdup(e->d_name), osl_fs_is_dir(full)};
        safe_vec_push(*out, ent);
    }
    closedir(d);
    if (out->n) qsort(out->d, out->n, sizeof *out->d, cmp_ent);
    return true;
}
void osl_fs_list_free(OslDirList *l) {
    for (size_t i = 0; i < l->n; i++) free(l->d[i].name);
    safe_vec_free(*l);
}
