#include "osl/osl_json.h"
#include "osl/osl_safe.h"
#include <ctype.h>
#include <math.h>

/* ------------------------------------------------------------ construcción */
OslJson *osl_json_new(OslJType t) { OslJson *j = (OslJson *)safe_calloc(1, sizeof *j); j->t = t; return j; }
OslJson *osl_json_str(const char *s) { OslJson *j = osl_json_new(OSL_J_STR); j->str = safe_strdup(s ? s : ""); return j; }
OslJson *osl_json_bool(bool b) { OslJson *j = osl_json_new(OSL_J_BOOL); j->b = b; return j; }
OslJson *osl_json_num(double d) { OslJson *j = osl_json_new(OSL_J_NUM); j->num = d; return j; }

void osl_json_free(OslJson *j) {
    if (!j) return;
    for (size_t i = 0; i < j->n; i++) { osl_json_free(j->v[i]); if (j->k) free(j->k[i]); }
    free(j->v); free(j->k); free(j->str); free(j);
}
static void cgrow(OslJson *c) {
    if (c->n < c->cap) return;
    size_t nc = c->cap ? c->cap * 2 : 4;
    c->v = (OslJson **)safe_reallocarray(c->v, nc, sizeof *c->v);
    if (c->t == OSL_J_OBJ) c->k = (char **)safe_reallocarray(c->k, nc, sizeof *c->k);
    c->cap = nc;
}
void osl_json_arr_insert(OslJson *a, size_t i, OslJson *item) {
    if (!a || a->t != OSL_J_ARR) { osl_json_free(item); return; }
    cgrow(a);
    if (i > a->n) i = a->n;
    memmove(&a->v[i + 1], &a->v[i], (a->n - i) * sizeof *a->v);
    a->v[i] = item; a->n++;
}
void osl_json_arr_push(OslJson *a, OslJson *item) { osl_json_arr_insert(a, a ? a->n : 0, item); }
OslJson *osl_json_arr_take(OslJson *a, size_t i) {
    if (!a || a->t != OSL_J_ARR || i >= a->n) return NULL;
    OslJson *r = a->v[i];
    memmove(&a->v[i], &a->v[i + 1], (a->n - i - 1) * sizeof *a->v);
    a->n--;
    return r;
}
OslJson *osl_json_obj_get(const OslJson *o, const char *key) {
    if (!o || o->t != OSL_J_OBJ) return NULL;
    for (size_t i = 0; i < o->n; i++) if (!strcmp(o->k[i], key)) return o->v[i];
    return NULL;
}
void osl_json_obj_set(OslJson *o, const char *key, OslJson *val) {
    if (!o || o->t != OSL_J_OBJ) { osl_json_free(val); return; }
    for (size_t i = 0; i < o->n; i++)
        if (!strcmp(o->k[i], key)) { osl_json_free(o->v[i]); o->v[i] = val; return; }
    cgrow(o);
    o->k[o->n] = safe_strdup(key); o->v[o->n] = val; o->n++;
}
bool osl_json_obj_del(OslJson *o, const char *key) {
    if (!o || o->t != OSL_J_OBJ) return false;
    for (size_t i = 0; i < o->n; i++) if (!strcmp(o->k[i], key)) {
        osl_json_free(o->v[i]); free(o->k[i]);
        memmove(&o->v[i], &o->v[i + 1], (o->n - i - 1) * sizeof *o->v);
        memmove(&o->k[i], &o->k[i + 1], (o->n - i - 1) * sizeof *o->k);
        o->n--; return true;
    }
    return false;
}
const char *osl_json_str_or(const OslJson *o, const char *key, const char *def) {
    OslJson *v = osl_json_obj_get(o, key);
    return (v && v->t == OSL_J_STR) ? v->str : def;
}
bool osl_json_bool_or(const OslJson *o, const char *key, bool def) {
    OslJson *v = osl_json_obj_get(o, key);
    return (v && v->t == OSL_J_BOOL) ? v->b : def;
}
double osl_json_num_or(const OslJson *o, const char *key, double def) {
    OslJson *v = osl_json_obj_get(o, key);
    return (v && v->t == OSL_J_NUM) ? v->num : def;
}
OslJson *osl_json_clone(const OslJson *j) {
    if (!j) return NULL;
    OslJson *c = osl_json_new(j->t);
    c->b = j->b; c->num = j->num;
    if (j->str) c->str = safe_strdup(j->str);
    for (size_t i = 0; i < j->n; i++) {
        if (j->t == OSL_J_OBJ) osl_json_obj_set(c, j->k[i], osl_json_clone(j->v[i]));
        else osl_json_arr_push(c, osl_json_clone(j->v[i]));
    }
    return c;
}

/* ------------------------------------------------------------------ parser */
typedef struct { const char *s, *p; char *err; size_t ec; int depth; bool fail; } P;
static void pfail(P *p, const char *msg) {
    if (p->fail) return;
    p->fail = true;
    int line = 1, col = 1;
    for (const char *q = p->s; q < p->p && *q; q++) { if (*q == '\n') { line++; col = 1; } else col++; }
    if (p->err && p->ec) snprintf(p->err, p->ec, "JSON inválido (línea %d, columna %d): %s", line, col, msg);
}
static void ws(P *p) { while (*p->p == ' ' || *p->p == '\t' || *p->p == '\n' || *p->p == '\r') p->p++; }
static bool hex4(P *p, unsigned *out) {
    unsigned v = 0;
    for (int i = 0; i < 4; i++) {
        char c = p->p[i];
        if (!isxdigit((unsigned char)c)) return false;
        v = v * 16 + (unsigned)(isdigit((unsigned char)c) ? c - '0' : (tolower(c) - 'a' + 10));
    }
    p->p += 4; *out = v;
    return true;
}
static void put_utf8(SBuf *b, unsigned cp) {
    if (cp == 0) return;                        /* U+0000 no cabe en cadenas C */
    if (cp < 0x80) sb_push(b, (char)cp);
    else if (cp < 0x800) { sb_push(b, (char)(0xC0 | (cp >> 6))); sb_push(b, (char)(0x80 | (cp & 0x3F))); }
    else if (cp < 0x10000) { sb_push(b, (char)(0xE0 | (cp >> 12))); sb_push(b, (char)(0x80 | ((cp >> 6) & 0x3F))); sb_push(b, (char)(0x80 | (cp & 0x3F))); }
    else { sb_push(b, (char)(0xF0 | (cp >> 18))); sb_push(b, (char)(0x80 | ((cp >> 12) & 0x3F))); sb_push(b, (char)(0x80 | ((cp >> 6) & 0x3F))); sb_push(b, (char)(0x80 | (cp & 0x3F))); }
}
static char *pstr(P *p) {
    SBuf b = {0};
    p->p++;                                     /* comilla inicial */
    for (;;) {
        unsigned char c = (unsigned char)*p->p;
        if (!c) { pfail(p, "cadena sin cerrar"); goto bad; }
        if (c == '"') { p->p++; break; }
        if (c < 0x20) { pfail(p, "carácter de control en una cadena"); goto bad; }
        if (c != '\\') { sb_push(&b, (char)c); p->p++; continue; }
        p->p++;
        char e = *p->p++;
        switch (e) {
            case '"': case '\\': case '/': sb_push(&b, e); break;
            case 'b': sb_push(&b, '\b'); break;
            case 'f': sb_push(&b, '\f'); break;
            case 'n': sb_push(&b, '\n'); break;
            case 'r': sb_push(&b, '\r'); break;
            case 't': sb_push(&b, '\t'); break;
            case 'u': {
                unsigned cp, lo;
                if (!hex4(p, &cp)) { pfail(p, "secuencia \\u inválida"); goto bad; }
                if (cp >= 0xD800 && cp < 0xDC00) {
                    if (p->p[0] == '\\' && p->p[1] == 'u') {
                        p->p += 2;
                        if (!hex4(p, &lo) || lo < 0xDC00 || lo > 0xDFFF) { pfail(p, "par sustituto inválido"); goto bad; }
                        cp = 0x10000 + ((cp - 0xD800) << 10) + (lo - 0xDC00);
                    } else { pfail(p, "par sustituto incompleto"); goto bad; }
                } else if (cp >= 0xDC00 && cp < 0xE000) { pfail(p, "par sustituto inválido"); goto bad; }
                put_utf8(&b, cp);
                break;
            }
            default: pfail(p, "escape desconocido"); goto bad;
        }
    }
    return sb_take(&b);
bad:
    sb_free(&b);
    return NULL;
}
static OslJson *pval(P *p) {
    ws(p);
    char c = *p->p;
    if (p->depth > 64) { pfail(p, "anidamiento excesivo"); return NULL; }
    if (c == '{' || c == '[') {
        bool obj = (c == '{');
        char close = obj ? '}' : ']';
        OslJson *o = osl_json_new(obj ? OSL_J_OBJ : OSL_J_ARR);
        p->p++; p->depth++;
        ws(p);
        if (*p->p == close) { p->p++; p->depth--; return o; }
        for (;;) {
            char *key = NULL;
            ws(p);
            if (obj) {
                if (*p->p != '"') { pfail(p, "se esperaba una clave entre comillas"); goto bad; }
                key = pstr(p);
                if (!key) goto bad;
                ws(p);
                if (*p->p != ':') { free(key); pfail(p, "se esperaba ':'"); goto bad; }
                p->p++;
            }
            OslJson *v = pval(p);
            if (!v) { free(key); goto bad; }
            if (obj) { osl_json_obj_set(o, key, v); free(key); } else osl_json_arr_push(o, v);
            ws(p);
            if (*p->p == ',') { p->p++; continue; }
            if (*p->p == close) { p->p++; break; }
            pfail(p, obj ? "se esperaba ',' o '}'" : "se esperaba ',' o ']'");
            goto bad;
        }
        p->depth--;
        return o;
    bad:
        p->depth--;
        osl_json_free(o);
        return NULL;
    }
    if (c == '"') { char *s = pstr(p); if (!s) return NULL; OslJson *j = osl_json_new(OSL_J_STR); j->str = s; return j; }
    if (!strncmp(p->p, "true", 4)) { p->p += 4; return osl_json_bool(true); }
    if (!strncmp(p->p, "false", 5)) { p->p += 5; return osl_json_bool(false); }
    if (!strncmp(p->p, "null", 4)) { p->p += 4; return osl_json_new(OSL_J_NULL); }
    if (c == '-' || isdigit((unsigned char)c)) {
        char tok[64];
        size_t n = 0;
        while ((isdigit((unsigned char)*p->p) || strchr("+-.eE", *p->p)) && *p->p && n < sizeof tok - 1) tok[n++] = *p->p++;
        tok[n] = 0;
        char *end;
        double d = strtod(tok, &end);
        if (*end || n == 0) { pfail(p, "número inválido"); return NULL; }
        return osl_json_num(d);
    }
    pfail(p, *p->p ? "valor inesperado" : "fin de texto inesperado");
    return NULL;
}
OslJson *osl_json_parse(const char *text, char *err, size_t errcap) {
    if (err && errcap) err[0] = 0;
    if (!text) return NULL;
    if ((unsigned char)text[0] == 0xEF && (unsigned char)text[1] == 0xBB && (unsigned char)text[2] == 0xBF) text += 3;
    P p = {text, text, err, errcap, 0, false};
    OslJson *j = pval(&p);
    if (j) {
        ws(&p);
        if (*p.p) { pfail(&p, "texto sobrante tras el valor"); osl_json_free(j); return NULL; }
    }
    return j;
}

/* -------------------------------------------------------------- serializar */
static void nl(SBuf *b, int ind, int lvl) {
    if (ind <= 0) return;
    sb_push(b, '\n');
    for (int i = 0; i < ind * lvl; i++) sb_push(b, ' ');
}
static void dstr(SBuf *b, const char *s) {
    sb_push(b, '"');
    for (; *s; s++) {
        unsigned char c = (unsigned char)*s;
        switch (c) {
            case '"': sb_str(b, "\\\""); break;
            case '\\': sb_str(b, "\\\\"); break;
            case '\n': sb_str(b, "\\n"); break;
            case '\r': sb_str(b, "\\r"); break;
            case '\t': sb_str(b, "\\t"); break;
            case '\b': sb_str(b, "\\b"); break;
            case '\f': sb_str(b, "\\f"); break;
            default:
                if (c < 0x20) { char t[8]; snprintf(t, sizeof t, "\\u%04x", c); sb_str(b, t); }
                else sb_push(b, (char)c);
        }
    }
    sb_push(b, '"');
}
static void dump(const OslJson *j, SBuf *b, int ind, int lvl) {
    char t[40];
    switch (j->t) {
        case OSL_J_NULL: sb_str(b, "null"); break;
        case OSL_J_BOOL: sb_str(b, j->b ? "true" : "false"); break;
        case OSL_J_NUM:
            if (!isfinite(j->num)) sb_str(b, "null");
            else if (j->num == floor(j->num) && fabs(j->num) < 1e15) snprintf(t, sizeof t, "%.0f", j->num), sb_str(b, t);
            else snprintf(t, sizeof t, "%.17g", j->num), sb_str(b, t);
            break;
        case OSL_J_STR: dstr(b, j->str ? j->str : ""); break;
        case OSL_J_ARR: case OSL_J_OBJ: {
            bool obj = j->t == OSL_J_OBJ;
            sb_push(b, obj ? '{' : '[');
            for (size_t i = 0; i < j->n; i++) {
                if (i) sb_push(b, ',');
                nl(b, ind, lvl + 1);
                if (obj) { dstr(b, j->k[i]); sb_push(b, ':'); if (ind > 0) sb_push(b, ' '); }
                dump(j->v[i], b, ind, lvl + 1);
            }
            if (j->n) nl(b, ind, lvl);
            sb_push(b, obj ? '}' : ']');
            break;
        }
    }
}
char *osl_json_dump(const OslJson *j, int indent) {
    SBuf b = {0};
    if (j) dump(j, &b, indent, 0);
    return sb_take(&b);
}
