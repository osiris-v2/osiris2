#define _GNU_SOURCE
#include "osl/osl_app.h"
#include "osl/osl_fs.h"
#include "osl/osl_safe.h"
#include <strings.h>
#ifdef OSL_HAVE_IMAGE
#include <SDL_image.h>
#endif

typedef enum { D_MSG, D_CONFIRM, D_PROMPT, D_PATH } DKind;
typedef struct {
    DKind kind;
    char *title, *text, *yes, *no;
    char buf[1024];
    OslConfirmFn cf; OslPromptFn pf; OslPathFn pathf; void *user;
    int scroll; uint32_t born; bool first;
    OslPathMode pmode; char cwd[1024], name[256], err[160]; char *ext;
    OslDirList list; int sel; bool hidden, dirty;
} Dlg;

struct OslApp {
    SDL_Window *win; SDL_Renderer *ren; OslUi ui;
    bool run, need;
    SAFE_VEC(Dlg *) dl;
    char toast[256]; uint32_t toast_until;
    uint32_t wake_type;
    char *shot; int shot_frames, shot_done;
    SAFE_VEC(char *) script; size_t sc_i; int sc_wait; char *pend_shot;
    bool continuous, fullscreen; OslDropFn drop_fn; void *drop_user; uint32_t sleep_until;
    int w, h;
};

OslUi *osl_app_ui(OslApp *a) { return &a->ui; }
SDL_Window *osl_app_window(OslApp *a) { return a->win; }
void osl_app_size(OslApp *a, int *w, int *h) { if (w) *w = a->w; if (h) *h = a->h; }
void osl_app_quit(OslApp *a) { a->run = false; }
bool osl_dlg_active(OslApp *a) { return a->dl.n > 0; }
void osl_app_set_continuous(OslApp *a, bool on) { a->continuous = on; a->need = true; }
void osl_app_set_fullscreen(OslApp *a, bool on) { a->fullscreen = on; SDL_SetWindowFullscreen(a->win, on ? SDL_WINDOW_FULLSCREEN_DESKTOP : 0); a->need = true; }
bool osl_app_is_fullscreen(OslApp *a) { return a->fullscreen; }
void osl_app_set_title(OslApp *a, const char *t) { SDL_SetWindowTitle(a->win, t); }
void osl_app_show_cursor(OslApp *a, bool show) { (void)a; SDL_ShowCursor(show ? SDL_ENABLE : SDL_DISABLE); }
void osl_app_on_drop(OslApp *a, OslDropFn fn, void *user) { a->drop_fn = fn; a->drop_user = user; }
void osl_app_wake(OslApp *a) { SDL_Event e; SDL_zero(e); e.type = a->wake_type; SDL_PushEvent(&e); }
void osl_app_toast(OslApp *a, const char *fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(a->toast, sizeof a->toast, fmt, ap);
    va_end(ap);
    a->toast_until = SDL_GetTicks() + 3500;
    a->need = true;
}

/* ----------------------------------------------------------------- creación */
OslApp *osl_app_create(const OslAppDesc *d) {
    if (SDL_Init(SDL_INIT_VIDEO) != 0) { fprintf(stderr, "osl: SDL_Init: %s\n", SDL_GetError()); return NULL; }
    if (TTF_Init() != 0) { fprintf(stderr, "osl: TTF_Init: %s\n", TTF_GetError()); SDL_Quit(); return NULL; }
#ifdef OSL_HAVE_IMAGE
    IMG_Init(IMG_INIT_PNG | IMG_INIT_JPG | IMG_INIT_WEBP);
#endif
    OslApp *a = (OslApp *)safe_calloc(1, sizeof *a);
    a->win = SDL_CreateWindow(d->title ? d->title : "osl", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
                              d->w > 0 ? d->w : 1000, d->h > 0 ? d->h : 700, SDL_WINDOW_RESIZABLE);
    if (!a->win) { fprintf(stderr, "osl: SDL_CreateWindow: %s\n", SDL_GetError()); goto fail; }
    SDL_SetWindowMinimumSize(a->win, d->min_w > 0 ? d->min_w : 520, d->min_h > 0 ? d->min_h : 380);
    a->ren = SDL_CreateRenderer(a->win, -1, SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC);
    if (!a->ren) a->ren = SDL_CreateRenderer(a->win, -1, SDL_RENDERER_SOFTWARE);
    if (!a->ren) { fprintf(stderr, "osl: SDL_CreateRenderer: %s\n", SDL_GetError()); goto fail; }
    if (!osl_ui_init(&a->ui, a->ren, d->font_px > 0 ? d->font_px : 15)) goto fail;
    osl_ui_theme(&a->ui, d->theme);
    a->wake_type = SDL_RegisterEvents(1);
    const char *sh = getenv("OSL_SHOT");
    if (sh && *sh) { a->shot = safe_strdup(sh); const char *n = getenv("OSL_SHOT_FRAMES"); a->shot_frames = n ? atoi(n) : 4; if (a->shot_frames < 2) a->shot_frames = 2; }
    const char *sc = getenv("OSL_SCRIPT");
    if (sc && *sc) {
        char *txt = osl_fs_read_all(sc, 1u << 20, NULL, NULL, 0);
        if (txt) {
            char *sv = NULL;
            for (char *l = strtok_r(txt, "\n", &sv); l; l = strtok_r(NULL, "\n", &sv)) {
                while (*l == ' ') l++;
                if (*l && *l != '#') { char *c = safe_strdup(l); safe_vec_push(a->script, c); }
            }
            free(txt);
        } else fprintf(stderr, "osl: no se pudo leer OSL_SCRIPT=%s\n", sc);
    }
    SDL_StartTextInput();
    return a;
fail:
    osl_app_destroy(a);
    return NULL;
}

static void dlg_free(Dlg *d) {
    free(d->title); free(d->text); free(d->yes); free(d->no); free(d->ext);
    osl_fs_list_free(&d->list);
    free(d);
}
void osl_app_destroy(OslApp *a) {
    if (!a) return;
    for (size_t i = 0; i < a->dl.n; i++) dlg_free(a->dl.d[i]);
    safe_vec_free(a->dl);
    for (size_t i = 0; i < a->script.n; i++) free(a->script.d[i]);
    safe_vec_free(a->script);
    free(a->pend_shot);
    osl_ui_shutdown(&a->ui);
    if (a->ren) SDL_DestroyRenderer(a->ren);
    if (a->win) SDL_DestroyWindow(a->win);
#ifdef OSL_HAVE_IMAGE
    IMG_Quit();
#endif
    TTF_Quit();
    SDL_Quit();
    free(a->shot);
    free(a);
}

/* ------------------------------------------------------------------ diálogos */
static Dlg *dlg_new(OslApp *a, DKind k, const char *title, const char *text) {
    Dlg *d = (Dlg *)safe_calloc(1, sizeof *d);
    d->kind = k; d->title = safe_strdup(title ? title : ""); d->text = safe_strdup(text ? text : "");
    d->born = a->ui.frame; d->first = true;
    safe_vec_push(a->dl, d);
    a->need = true;
    return d;
}
void osl_dlg_message(OslApp *a, const char *t, const char *x) { dlg_new(a, D_MSG, t, x); }
void osl_dlg_confirm(OslApp *a, const char *t, const char *x, const char *y, const char *n, OslConfirmFn cb, void *user) {
    Dlg *d = dlg_new(a, D_CONFIRM, t, x);
    d->yes = safe_strdup(y ? y : "Sí"); d->no = safe_strdup(n ? n : "No"); d->cf = cb; d->user = user;
}
void osl_dlg_prompt(OslApp *a, const char *t, const char *label, const char *init, OslPromptFn cb, void *user) {
    Dlg *d = dlg_new(a, D_PROMPT, t, label);
    safe_strlcpy(d->buf, init ? init : "", sizeof d->buf); d->pf = cb; d->user = user;
}
void osl_dlg_path(OslApp *a, const char *t, OslPathMode m, const char *start, const char *ext, OslPathFn cb, void *user) {
    Dlg *d = dlg_new(a, D_PATH, t, "");
    d->pmode = m; d->pathf = cb; d->user = user; d->sel = -1; d->dirty = true;
    d->ext = ext ? safe_strdup(ext) : NULL;
    safe_ptr(char) s = osl_fs_expand(start && *start ? start : ".");
    char *real = realpath(s, NULL);
    if (real && osl_fs_is_dir(real)) safe_strlcpy(d->cwd, real, sizeof d->cwd);
    else if (real) { safe_ptr(char) dn = osl_fs_dirname(real); safe_strlcpy(d->cwd, dn, sizeof d->cwd); safe_strlcpy(d->name, osl_fs_basename(real), sizeof d->name); }
    else { safe_ptr(char) dn = osl_fs_dirname(s); safe_strlcpy(d->cwd, osl_fs_is_dir(dn) ? dn : osl_fs_home(), sizeof d->cwd); }
    free(real);
    safe_strlcpy(d->buf, d->cwd, sizeof d->buf);
}

static bool ext_ok(const char *ext, const char *name) {
    if (!ext || !*ext) return true;
    const char *dot = strrchr(name, '.');
    if (!dot) return false;
    dot++;
    safe_ptr(char) cp = safe_strdup(ext);
    char *sv = NULL;
    for (char *t = strtok_r(cp, ";", &sv); t; t = strtok_r(NULL, ";", &sv)) if (!strcasecmp(t, dot)) return true;
    return false;
}
static void path_cd(Dlg *d, const char *dir) {
    char *real = realpath(dir, NULL);
    if (!real) { snprintf(d->err, sizeof d->err, "No existe: %s", dir); return; }
    if (!osl_fs_is_dir(real)) { free(real); return; }
    safe_strlcpy(d->cwd, real, sizeof d->cwd); safe_strlcpy(d->buf, real, sizeof d->buf);
    free(real);
    d->sel = -1; d->scroll = 0; d->dirty = true; d->err[0] = 0;
}

typedef enum { R_NONE, R_OK, R_CANCEL } DRes;

static SDL_Rect panel_rect(OslApp *a, int w, int h) { return (SDL_Rect){(a->w - w) / 2, (a->h - h) / 2, w, h}; }

static void dlg_frame(OslApp *a, SDL_Rect p, const char *title) {
    OslUi *u = &a->ui;
    osl_rect(u, (SDL_Rect){0, 0, a->w, a->h}, (SDL_Color){0, 0, 0, 140});
    osl_rect(u, (SDL_Rect){p.x + 4, p.y + 5, p.w, p.h}, (SDL_Color){0, 0, 0, 90});
    osl_rect(u, p, u->th.panel);
    osl_border(u, p, u->th.accent);
    osl_rect(u, (SDL_Rect){p.x, p.y, p.w, u->lh + 14}, u->th.card);
    osl_text_fit(u, (SDL_Rect){p.x + 6, p.y + 7, p.w - 12, u->lh}, title, u->th.accent, true);
}

static DRes draw_dialog(OslApp *a, Dlg *d) {
    OslUi *u = &a->ui;
    DRes res = R_NONE;
    int bh = u->lh + 10, pad = 14, W = a->w, H = a->h;
    bool esc = u->in.k_esc, enter = u->in.k_enter;
    if (d->kind != D_PATH) {
        int pw = W - 40 < 580 ? W - 40 : 580, tw = pw - 2 * pad;
        int lines_h = osl_text_wrap(u, (SDL_Rect){0, 0, tw, 0}, d->text, u->th.text, 0, false);
        int extra = d->kind == D_PROMPT ? bh + 10 : 0;
        int maxbody = H - 40 - (u->lh + 14) - bh - 3 * pad - extra;
        int body = lines_h < maxbody ? lines_h : maxbody;
        if (body < u->lh) body = u->lh;
        int ph = (u->lh + 14) + pad + body + (extra ? extra : 0) + pad + bh + pad;
        SDL_Rect p = panel_rect(a, pw, ph);
        dlg_frame(a, p, d->title);
        SDL_Rect view = {p.x + pad, p.y + u->lh + 14 + pad, tw, body};
        osl_scroll_update(u, view, lines_h, &d->scroll);
        SDL_Rect sv; bool had;
        osl_clip_push(u, view, &sv, &had);
        osl_text_wrap(u, (SDL_Rect){view.x, view.y - d->scroll, tw, lines_h}, d->text, u->th.text, 0, true);
        osl_clip_pop(u, sv, had);
        osl_scroll_draw(u, view, lines_h, d->scroll);
        int y = view.y + body + 10;
        if (d->kind == D_PROMPT) {
            if (d->first) osl_focus(u, d->buf);
            if (osl_input(u, (SDL_Rect){p.x + pad, y, tw, bh}, d->buf, sizeof d->buf, NULL)) res = R_OK;
            y += bh + 10;
        }
        int by = p.y + p.h - pad - bh, bw = 110;
        const char *ok = d->kind == D_CONFIRM ? d->yes : "Aceptar";
        const char *no = d->kind == D_CONFIRM ? d->no : "Cancelar";
        if (d->kind == D_MSG) {
            if (osl_button(u, (SDL_Rect){p.x + p.w - pad - bw, by, bw, bh}, "Aceptar", OSL_PRIMARY)) res = R_OK;
            if (esc || enter) res = R_OK;
        } else {
            int w2 = osl_text_w(u, ok, false) + 30; if (w2 > bw) bw = w2;
            if (osl_button(u, (SDL_Rect){p.x + p.w - pad - bw, by, bw, bh}, ok, OSL_PRIMARY)) res = R_OK;
            int nw = osl_text_w(u, no, false) + 30; if (nw < 110) nw = 110;
            if (osl_button(u, (SDL_Rect){p.x + p.w - 2 * pad - bw - nw, by, nw, bh}, no, 0)) res = R_CANCEL;
            if (esc) res = R_CANCEL;
            if (enter && d->kind == D_CONFIRM) res = R_OK;
        }
        d->first = false;
        return res;
    }

    /* ---- selector de ficheros ---- */
    int pw = W - 40 < 700 ? W - 40 : 700, ph = H - 40 < 520 ? H - 40 : 520;
    SDL_Rect p = panel_rect(a, pw, ph);
    dlg_frame(a, p, d->title);
    if (d->dirty) {
        osl_fs_list_free(&d->list);
        d->list = (OslDirList){0};
        if (!osl_fs_list(d->cwd, &d->list, d->hidden)) snprintf(d->err, sizeof d->err, "No se puede leer la carpeta");
        d->dirty = false;
    }
    int y = p.y + u->lh + 14 + 10, x = p.x + pad, iw = pw - 2 * pad;
    bool dirmode = d->pmode == OSL_PATH_OPEN_DIR;
    int up_w = 80, home_w = 80;
    if (osl_button(u, (SDL_Rect){x, y, up_w, bh}, "Subir", 0)) { safe_ptr(char) pr = osl_fs_dirname(d->cwd); path_cd(d, pr); }
    if (osl_button(u, (SDL_Rect){x + up_w + 6, y, home_w, bh}, "Inicio", 0)) path_cd(d, osl_fs_home());
    if (osl_checkbox(u, x + up_w + home_w + 24, y + (bh - 18) / 2, "Mostrar ocultos", &d->hidden)) d->dirty = true;
    y += bh + 8;
    if (d->first) osl_focus(u, d->name[0] || d->pmode == OSL_PATH_SAVE_FILE ? (void *)d->name : (void *)d->buf);
    if (osl_input(u, (SDL_Rect){x, y, iw, bh}, d->buf, sizeof d->buf, "Ruta…")) {
        safe_ptr(char) e = osl_fs_expand(d->buf);
        if (osl_fs_is_dir(e)) path_cd(d, e);
        else if (d->pmode == OSL_PATH_OPEN_FILE && osl_fs_exists(e)) { safe_strlcpy(d->name, osl_fs_basename(e), sizeof d->name); safe_ptr(char) dn = osl_fs_dirname(e); safe_strlcpy(d->cwd, dn, sizeof d->cwd); res = R_OK; }
        else snprintf(d->err, sizeof d->err, "No existe: %s", e);
    }
    y += bh + 8;
    int foot = bh + pad + (d->pmode == OSL_PATH_SAVE_FILE ? bh + 8 : 0) + (u->lh + 6);
    SDL_Rect view = {x, y, iw, p.y + ph - y - foot};
    int rh = u->lh + 8, content = (int)d->list.n * rh;
    osl_rect(u, view, u->th.field);
    osl_scroll_update(u, view, content, &d->scroll);
    SDL_Rect sv; bool had;
    osl_clip_push(u, view, &sv, &had);
    int shown = 0;
    for (size_t i = 0; i < d->list.n; i++) {
        OslDirEnt *e = &d->list.d[i];
        bool match = e->is_dir || ext_ok(d->ext, e->name);
        if (!match) continue;
        SDL_Rect row = {view.x, view.y + shown * rh - d->scroll, view.w - 10, rh};
        shown++;
        if (row.y + rh < view.y || row.y > view.y + view.h) continue;
        bool hov = osl_hover(u, row), selr = d->sel == (int)i;
        if (selr) osl_rect(u, row, u->th.accent);
        else if (hov) osl_rect(u, row, u->th.btnhov);
        SDL_Color c = selr ? u->th.accent_text : ((dirmode && !e->is_dir) ? u->th.dim : u->th.text);
        safe_ptr(char) label = e->is_dir ? safe_asprintf("\xE2\x96\xB8 %s/", e->name) : safe_strdup(e->name);
        osl_text_fit(u, (SDL_Rect){row.x + 4, row.y, row.w - 8, rh}, label, c, e->is_dir);
        if (hov && u->in.pressed) {
            d->sel = (int)i;
            if (!e->is_dir && d->pmode != OSL_PATH_OPEN_DIR) safe_strlcpy(d->name, e->name, sizeof d->name);
            if (u->in.clicks >= 2) {
                if (e->is_dir) { safe_ptr(char) np = osl_fs_join(d->cwd, e->name); path_cd(d, np); break; }
                if (d->pmode != OSL_PATH_OPEN_DIR) res = R_OK;
            }
        }
    }
    osl_clip_pop(u, sv, had);
    content = shown * rh;
    osl_scroll_draw(u, view, content, d->scroll);
    y = view.y + view.h + 6;
    if (d->err[0]) osl_text_fit(u, (SDL_Rect){x, y, iw, u->lh}, d->err, u->th.err, false);
    else if (!shown) osl_text_fit(u, (SDL_Rect){x, y, iw, u->lh}, "(carpeta vacía o sin ficheros que coincidan)", u->th.dim, false);
    y += u->lh + 6;
    if (d->pmode == OSL_PATH_SAVE_FILE) {
        osl_text(u, x, y + (bh - u->lh) / 2, "Nombre:", u->th.dim, false);
        int lw = osl_text_w(u, "Nombre:", false) + 10;
        if (osl_input(u, (SDL_Rect){x + lw, y, iw - lw, bh}, d->name, sizeof d->name, "fichero.ext")) res = R_OK;
        y += bh + 8;
    }
    int by = p.y + ph - pad - bh, bw = 130;
    const char *okl = dirmode ? "Elegir esta carpeta" : (d->pmode == OSL_PATH_SAVE_FILE ? "Guardar" : "Abrir");
    int ow = osl_text_w(u, okl, false) + 30; if (ow > bw) bw = ow;
    bool can = dirmode || (d->name[0] != 0);
    if (osl_button(u, (SDL_Rect){p.x + pw - pad - bw, by, bw, bh}, okl, OSL_PRIMARY | (can ? 0 : OSL_DISABLED))) res = R_OK;
    if (osl_button(u, (SDL_Rect){p.x + pw - 2 * pad - bw - 110, by, 110, bh}, "Cancelar", 0)) res = R_CANCEL;
    if (esc) res = R_CANCEL;
    if (res == R_OK && !can) res = R_NONE;
    d->first = false;
    return res;
}

static void dlg_finish(OslApp *a, size_t idx, DRes r) {
    Dlg *d = a->dl.d[idx];
    safe_vec_remove(a->dl, idx);                    /* se retira antes del callback: este puede abrir otro diálogo */
    bool ok = r == R_OK;
    switch (d->kind) {
        case D_CONFIRM: if (d->cf) d->cf(ok, d->user); break;
        case D_PROMPT: if (d->pf) d->pf(ok, d->buf, d->user); break;
        case D_PATH:
            if (d->pathf) {
                safe_ptr(char) full = NULL;
                if (ok) {
                    if (d->pmode == OSL_PATH_OPEN_DIR) full = safe_strdup(d->cwd);
                    else full = osl_fs_join(d->cwd, d->name);
                }
                d->pathf(ok, ok ? full : "", d->user);
            }
            break;
        default: break;
    }
    dlg_free(d);
    a->need = true;
}

/* ------------------------------------------------------------------- eventos */
static bool handle_event(OslApp *a, SDL_Event *e) {
    static const void *const T[] = {&&ev_other, &&ev_quit, &&ev_motion, &&ev_down, &&ev_up, &&ev_wheel, &&ev_text, &&ev_key, &&ev_win, &&ev_drop};
    OslInput *in = &a->ui.in;
    int k = 0;
    if (e->type == a->wake_type) { a->need = true; return true; }
    switch (e->type) {
        case SDL_QUIT: k = 1; break;
        case SDL_MOUSEMOTION: k = 2; break;
        case SDL_MOUSEBUTTONDOWN: k = 3; break;
        case SDL_MOUSEBUTTONUP: k = 4; break;
        case SDL_MOUSEWHEEL: k = 5; break;
        case SDL_TEXTINPUT: k = 6; break;
        case SDL_KEYDOWN: k = 7; break;
        case SDL_WINDOWEVENT: k = 8; break;
        case SDL_DROPFILE: case SDL_DROPTEXT: k = 9; break;
        default: break;
    }
    goto *T[k];
ev_quit:   return false;
ev_motion: in->moved = true; in->mx = e->motion.x; in->my = e->motion.y; a->ui.hover_since = SDL_GetTicks(); return true;
ev_down:
    in->moved = true;
    in->mx = e->button.x; in->my = e->button.y; a->ui.hover_since = SDL_GetTicks();
    if (e->button.button == SDL_BUTTON_LEFT) { in->pressed = in->mdown = true; in->clicks = e->button.clicks; }
    else if (e->button.button == SDL_BUTTON_RIGHT) in->rpressed = true;
    return true;
ev_up:
    in->mx = e->button.x; in->my = e->button.y;
    if (e->button.button == SDL_BUTTON_LEFT) { in->released = true; in->mdown = false; }
    return true;
ev_wheel:  in->wheel += e->wheel.y; return true;
ev_text:   strncat(in->textin, e->text.text, sizeof in->textin - strlen(in->textin) - 1); return true;
ev_key: {
    SDL_Keycode s = e->key.keysym.sym;
    in->mod = e->key.keysym.mod;
    bool ctl = (in->mod & (KMOD_CTRL | KMOD_GUI)) != 0;
    if (in->nkeys < 8) in->keys[in->nkeys++] = s;
    if (ctl && s == SDLK_v) in->k_paste = 1;
    else if (ctl && s == SDLK_c) in->k_copy = 1;
    else if (ctl && s == SDLK_x) in->k_cut = 1;
    else if (ctl && s == SDLK_a) in->k_selall = 1;
    else if (s == SDLK_BACKSPACE) in->k_bs++;
    else if (s == SDLK_DELETE) in->k_del++;
    else if (s == SDLK_LEFT) in->k_left++;
    else if (s == SDLK_RIGHT) in->k_right++;
    else if (s == SDLK_HOME) in->k_home++;
    else if (s == SDLK_END) in->k_end++;
    else if (s == SDLK_RETURN || s == SDLK_KP_ENTER) in->k_enter++;
    else if (s == SDLK_UP) in->k_up++;
    else if (s == SDLK_DOWN) in->k_down++;
    else if (s == SDLK_ESCAPE) in->k_esc++;
    else if (s == SDLK_TAB) in->k_tab++;
    else if (s == SDLK_PAGEUP) in->k_pgup++;
    else if (s == SDLK_PAGEDOWN) in->k_pgdn++;
    return true;
}
ev_win:    a->need = true; return true;
ev_drop:
    if (a->drop_fn && e->drop.file) a->drop_fn(e->drop.file, a->drop_user);
    SDL_free(e->drop.file);
    a->need = true;
    return true;
ev_other:  return true;
}

static void save_shot(OslApp *a) {
    SDL_Surface *sf = SDL_CreateRGBSurfaceWithFormat(0, a->w, a->h, 32, SDL_PIXELFORMAT_ARGB8888);
    if (!sf) return;
    SDL_RenderReadPixels(a->ren, NULL, SDL_PIXELFORMAT_ARGB8888, sf->pixels, sf->pitch);
    SDL_SaveBMP(sf, a->shot);
    SDL_FreeSurface(sf);
}

/* Modo de pruebas por script (OSL_SCRIPT=fichero): un paso por fotograma.
 *   click X Y [N] | rclick X Y | move X Y | wheel N | text CADENA | key NOMBRE | wait N | sleep MS | shot FICHERO.bmp | quit
 * Teclas: enter esc bs del left right up down home end tab pgup pgdn f5 ctrl+f ctrl+v */
static void script_step(OslApp *a) {
    OslInput *in = &a->ui.in;
    if (a->sc_wait > 0) { a->sc_wait--; return; }
    if (SDL_GetTicks() < a->sleep_until) return;
    if (a->sc_i >= a->script.n) { if (!a->shot) a->run = false; return; }
    const char *l = a->script.d[a->sc_i++];
    int x, y, n;
    char arg[512];
    if (sscanf(l, "click %d %d %d", &x, &y, &n) >= 2) {
        if (sscanf(l, "click %d %d %d", &x, &y, &n) < 3) n = 1;
        in->mx = x; in->my = y; in->pressed = in->released = true; in->clicks = n; a->ui.hover_since = SDL_GetTicks();
    } else if (sscanf(l, "rclick %d %d", &x, &y) == 2) { in->mx = x; in->my = y; in->rpressed = true; }
    else if (sscanf(l, "move %d %d", &x, &y) == 2) { in->mx = x; in->my = y; }
    else if (sscanf(l, "wheel %d", &n) == 1) in->wheel += n;
    else if (sscanf(l, "wait %d", &n) == 1) a->sc_wait = n;
    else if (!strncmp(l, "text ", 5)) strncat(in->textin, l + 5, sizeof in->textin - strlen(in->textin) - 1);
    else if (sscanf(l, "shot %511s", arg) == 1) { free(a->pend_shot); a->pend_shot = safe_strdup(arg); }
    else if (sscanf(l, "sleep %d", &n) == 1) a->sleep_until = SDL_GetTicks() + (uint32_t)n;
    else if (!strcmp(l, "quit")) a->run = false;
    else if (sscanf(l, "key %511s", arg) == 1) {
        SDL_Keycode k = 0;
        if (!strcmp(arg, "enter")) { in->k_enter++; k = SDLK_RETURN; }
        else if (!strcmp(arg, "esc")) { in->k_esc++; k = SDLK_ESCAPE; }
        else if (!strcmp(arg, "bs")) in->k_bs++;
        else if (!strcmp(arg, "del")) in->k_del++;
        else if (!strcmp(arg, "left")) in->k_left++;
        else if (!strcmp(arg, "right")) in->k_right++;
        else if (!strcmp(arg, "up")) in->k_up++;
        else if (!strcmp(arg, "down")) in->k_down++;
        else if (!strcmp(arg, "home")) in->k_home++;
        else if (!strcmp(arg, "end")) in->k_end++;
        else if (!strcmp(arg, "tab")) in->k_tab++;
        else if (!strcmp(arg, "pgup")) in->k_pgup++;
        else if (!strcmp(arg, "pgdn")) in->k_pgdn++;
        else if (!strcmp(arg, "f5")) k = SDLK_F5;
        else if (!strcmp(arg, "ctrl+f")) { k = SDLK_f; in->mod |= KMOD_CTRL; }
        else if (!strcmp(arg, "ctrl+v")) in->k_paste = 1;
        else if (!strcmp(arg, "ctrl+c")) in->k_copy = 1;
        else if (!strcmp(arg, "ctrl+x")) in->k_cut = 1;
        else if (!strcmp(arg, "ctrl+a")) in->k_selall = 1;
        else if (!strcmp(arg, "shift+left")) { in->k_left++; in->mod |= KMOD_SHIFT; }
        else if (!strcmp(arg, "shift+right")) { in->k_right++; in->mod |= KMOD_SHIFT; }
        else if (!strcmp(arg, "shift+home")) { in->k_home++; in->mod |= KMOD_SHIFT; }
        else if (!strcmp(arg, "space")) k = SDLK_SPACE;
        else if (strlen(arg) == 1) k = (SDL_Keycode)arg[0];
        else if (!strcmp(arg, "f11")) k = SDLK_F11;
        else fprintf(stderr, "osl: tecla de script desconocida: %s\n", arg);
        if (k && in->nkeys < 8) in->keys[in->nkeys++] = k;
    } else fprintf(stderr, "osl: paso de script desconocido: %s\n", l);
    a->need = true;
}

void osl_app_run(OslApp *a, OslFrameFn frame, void *user) {
    a->run = true;
    uint32_t last = 0;
    OslUi *u = &a->ui;
    while (a->run) {
        SDL_Event e;
        bool ev = false;
        if (SDL_WaitEventTimeout(&e, a->script.n ? 1 : (a->continuous ? 2 : 100))) { do { ev = true; if (!handle_event(a, &e)) a->run = false; } while (SDL_PollEvent(&e)); }
        uint32_t now = SDL_GetTicks();
        if (!ev && !a->need && !a->continuous && now - last < 250 && !a->shot && !a->script.n) continue;
        a->need = false; last = now;
        u->ticks = now;
        SDL_GetRendererOutputSize(a->ren, &a->w, &a->h);
        SDL_SetRenderDrawColor(a->ren, u->th.bg.r, u->th.bg.g, u->th.bg.b, 255);
        SDL_RenderClear(a->ren);
        osl_clip(u, NULL);

        if (a->script.n) script_step(a);
        if (!a->run) break;
        bool modal = a->dl.n > 0;
        OslInput saved;
        if (modal) saved = osl_ui_block(u);
        frame(a, user);
        osl_clip(u, NULL);
        if (modal) osl_ui_unblock(u, saved);
        if (a->dl.n > 0) {
            size_t top = a->dl.n - 1;
            Dlg *d = a->dl.d[top];
            OslInput s2;
            bool fresh = d->born == u->frame;            /* el clic que abrió el diálogo no debe pulsar sus botones */
            if (fresh) s2 = osl_ui_block(u);
            DRes r = draw_dialog(a, d);
            if (fresh) osl_ui_unblock(u, s2);
            osl_clip(u, NULL);
            if (r != R_NONE && !fresh) dlg_finish(a, top, r);
            a->need = a->need || fresh;
        }
        if (now < a->toast_until) {
            int tw = osl_text_w(u, a->toast, false), x = (a->w - tw) / 2, y = a->h - u->lh - 34;
            osl_rect(u, (SDL_Rect){x - 14, y - 6, tw + 28, u->lh + 12}, u->th.panel);
            osl_border(u, (SDL_Rect){x - 14, y - 6, tw + 28, u->lh + 12}, u->th.accent);
            osl_text(u, x, y, a->toast, u->th.text, false);
            a->need = true;
        }
        if (a->pend_shot) { char *sp = a->shot; a->shot = a->pend_shot; save_shot(a); a->shot = sp; free(a->pend_shot); a->pend_shot = NULL; }
        osl_ui_end(u);
        if (a->shot && ++a->shot_done >= a->shot_frames) { save_shot(a); a->run = false; }
        SDL_RenderPresent(a->ren);
    }
}
