#define _GNU_SOURCE
#include "osl/osl_proc.h"
#include "osl/osl_fs.h"
#include "osl/osl_safe.h"
#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <poll.h>
#include <signal.h>
#include <time.h>
#include <pthread.h>
#include <spawn.h>
#include <sys/wait.h>
#include <unistd.h>

extern char **environ;

size_t osl_argv_len(char *const *a) { size_t n = 0; while (a && a[n]) n++; return n; }
void osl_argv_free(char **a) { if (!a) return; for (size_t i = 0; a[i]; i++) free(a[i]); free(a); }

char **osl_proc_split(const char *s) {
    SAFE_VEC(char *) v = {0};
    SBuf b = {0};
    char q = 0;
    bool has = false;
    for (;; s++) {
        char c = *s;
        if (q) { if (!c) break; if (c == q) q = 0; else sb_push(&b, c); continue; }
        if (c == '"' || c == '\'') { q = c; has = true; continue; }
        if (!c || isspace((unsigned char)c)) {
            if (has) { char *w = sb_take(&b); safe_vec_push(v, w); has = false; }
            if (!c) break;
            continue;
        }
        sb_push(&b, c); has = true;
    }
    sb_free(&b);
    safe_vec_push(v, (char *)NULL);
    return v.d;
}

static void *reap(void *a) { waitpid((pid_t)(intptr_t)a, NULL, 0); return NULL; }

bool osl_proc_launch(char *const argv[], char *err, size_t ec) {
    if (!argv || !argv[0] || !argv[0][0]) { if (err) snprintf(err, ec, "comando vacío"); return false; }
    const char *cmd = argv[0];
    if (strchr(cmd, '/')) {
        if (osl_fs_is_dir(cmd)) { if (err) snprintf(err, ec, "'%s' es un directorio", cmd); return false; }
        if (!osl_fs_exists(cmd)) { if (err) snprintf(err, ec, "no existe '%s'", cmd); return false; }
        if (!osl_fs_is_exec(cmd)) { if (err) snprintf(err, ec, "'%s' no tiene permiso de ejecución", cmd); return false; }
    } else if (!osl_fs_which(cmd, NULL, 0)) {
        if (err) snprintf(err, ec, "'%s' no se encuentra en el PATH", cmd);
        return false;
    }
    posix_spawn_file_actions_t fa;
    posix_spawnattr_t at;
    posix_spawn_file_actions_init(&fa);
    posix_spawnattr_init(&at);
    posix_spawn_file_actions_addopen(&fa, 0, "/dev/null", O_RDONLY, 0);
    posix_spawn_file_actions_addopen(&fa, 1, "/dev/null", O_WRONLY, 0);
    posix_spawn_file_actions_addopen(&fa, 2, "/dev/null", O_WRONLY, 0);
#ifdef POSIX_SPAWN_SETSID
    posix_spawnattr_setflags(&at, POSIX_SPAWN_SETSID);
#else
    posix_spawnattr_setpgroup(&at, 0);
    posix_spawnattr_setflags(&at, POSIX_SPAWN_SETPGROUP);
#endif
    pid_t pid;
    int rc = posix_spawnp(&pid, cmd, &fa, &at, argv, environ);
    posix_spawn_file_actions_destroy(&fa);
    posix_spawnattr_destroy(&at);
    if (rc != 0) { if (err) snprintf(err, ec, "no se pudo ejecutar '%s': %s", cmd, strerror(rc)); return false; }
    pthread_t t;                                   /* recoge el estado de salida: sin zombis */
    if (pthread_create(&t, NULL, reap, (void *)(intptr_t)pid) == 0) pthread_detach(t);
    return true;
}

char **osl_proc_terminal_wrap(char *const argv[]) {
    static const char *const T[][2] = {{"x-terminal-emulator", "-e"}, {"gnome-terminal", "--"}, {"konsole", "-e"},
                                       {"xfce4-terminal", "-x"}, {"kitty", NULL}, {"alacritty", "-e"}, {"xterm", "-e"}};
    for (size_t i = 0; i < sizeof T / sizeof T[0]; i++) {
        if (!osl_fs_which(T[i][0], NULL, 0)) continue;
        SAFE_VEC(char *) v = {0};
        safe_vec_push(v, safe_strdup(T[i][0]));
        if (T[i][1]) safe_vec_push(v, safe_strdup(T[i][1]));
        for (size_t k = 0; argv[k]; k++) safe_vec_push(v, safe_strdup(argv[k]));
        safe_vec_push(v, (char *)NULL);
        return v.d;
    }
    return NULL;
}

bool osl_proc_open(const char *target, char *err, size_t ec) {
#ifdef __APPLE__
    char *argv[] = {"open", (char *)target, NULL};
#else
    char *argv[] = {"xdg-open", (char *)target, NULL};
#endif
    return osl_proc_launch(argv, err, ec);
}

bool osl_proc_capture_ex(char *const argv[], int timeout_ms, size_t max_bytes, char **out, size_t *len, char **errout, int *status, char *err, size_t ec) {
    *out = NULL;
    if (len) *len = 0;
    if (errout) *errout = NULL;
    if (!argv || !argv[0]) { if (err) snprintf(err, ec, "comando vacío"); return false; }
    if (!strchr(argv[0], '/') && !osl_fs_which(argv[0], NULL, 0)) { if (err) snprintf(err, ec, "'%s' no se encuentra en el PATH", argv[0]); return false; }
    int fo[2], fe[2] = {-1, -1};
    if (pipe(fo) != 0) { if (err) snprintf(err, ec, "pipe: %s", strerror(errno)); return false; }
    if (errout && pipe(fe) != 0) { close(fo[0]); close(fo[1]); if (err) snprintf(err, ec, "pipe: %s", strerror(errno)); return false; }
    posix_spawn_file_actions_t fa;
    posix_spawnattr_t at;
    posix_spawn_file_actions_init(&fa);
    posix_spawnattr_init(&at);
    posix_spawn_file_actions_addopen(&fa, 0, "/dev/null", O_RDONLY, 0);
    posix_spawn_file_actions_adddup2(&fa, fo[1], 1);
    if (errout) posix_spawn_file_actions_adddup2(&fa, fe[1], 2); else posix_spawn_file_actions_addopen(&fa, 2, "/dev/null", O_WRONLY, 0);
    posix_spawn_file_actions_addclose(&fa, fo[0]); posix_spawn_file_actions_addclose(&fa, fo[1]);
    if (errout) { posix_spawn_file_actions_addclose(&fa, fe[0]); posix_spawn_file_actions_addclose(&fa, fe[1]); }
    posix_spawnattr_setpgroup(&at, 0);
    posix_spawnattr_setflags(&at, POSIX_SPAWN_SETPGROUP);
    pid_t pid;
    int rc = posix_spawnp(&pid, argv[0], &fa, &at, argv, environ);
    posix_spawn_file_actions_destroy(&fa);
    posix_spawnattr_destroy(&at);
    close(fo[1]);
    if (errout) close(fe[1]);
    if (rc != 0) { close(fo[0]); if (errout) close(fe[0]); if (err) snprintf(err, ec, "no se pudo ejecutar '%s': %s", argv[0], strerror(rc)); return false; }
    SBuf bo = {0}, be = {0};
    bool timed_out = false;
    struct timespec t0;
    clock_gettime(CLOCK_MONOTONIC, &t0);
    int open_fds = errout ? 2 : 1;
    struct pollfd pf[2] = {{fo[0], POLLIN, 0}, {errout ? fe[0] : -1, POLLIN, 0}};
    while (open_fds > 0) {
        struct timespec t1;
        clock_gettime(CLOCK_MONOTONIC, &t1);
        long el = (t1.tv_sec - t0.tv_sec) * 1000 + (t1.tv_nsec - t0.tv_nsec) / 1000000;
        if (timeout_ms > 0 && el >= timeout_ms) { timed_out = true; break; }
        int pr = poll(pf, 2, 200);
        if (pr < 0 && errno != EINTR) break;
        for (int i = 0; i < 2; i++) {
            if (pf[i].fd < 0 || !(pf[i].revents & (POLLIN | POLLHUP | POLLERR))) continue;
            char buf[8192];
            ssize_t n = read(pf[i].fd, buf, sizeof buf);
            if (n < 0 && errno == EINTR) continue;
            if (n <= 0) { pf[i].fd = -1; open_fds--; continue; }
            SBuf *b = i == 0 ? &bo : &be;
            for (ssize_t k = 0; k < n && b->len < max_bytes; k++) sb_push(b, buf[k]);
        }
    }
    close(fo[0]);
    if (errout) close(fe[0]);
    if (timed_out) kill(-pid, SIGKILL);
    int st = 0;
    while (waitpid(pid, &st, 0) < 0 && errno == EINTR) {}
    if (timed_out) { sb_free(&bo); sb_free(&be); if (err) snprintf(err, ec, "tiempo agotado (%d ms)", timeout_ms); return false; }
    if (status) *status = WIFEXITED(st) ? WEXITSTATUS(st) : -1;
    if (len) *len = bo.len;
    *out = sb_take(&bo);
    if (errout) *errout = sb_take(&be); else sb_free(&be);
    return true;
}
bool osl_proc_capture(char *const argv[], int timeout_ms, size_t max_bytes, char **out, size_t *len, int *status, char *err, size_t ec) {
    return osl_proc_capture_ex(argv, timeout_ms, max_bytes, out, len, NULL, status, err, ec);
}
