#include "osl/osl_ui.h"
#include "osl/osl_font.h"
#include "osl/osl_fs.h"
#include "osl/osl_safe.h"
#include <sys/stat.h>
#ifdef OSL_HAVE_IMAGE
#include <SDL_image.h>
#endif

/* ---------------------------------------------------------- caché de texto */
typedef struct { char *s; SDL_Texture *t; int w, h; uint32_t col, stamp; TTF_Font *f; } TC;
#define TC_N 512
struct OslTextCache { TC e[TC_N]; };

static uint32_t hash_str(const char *s) { uint32_t h = 2166136261u; while (*s) h = (h ^ (uint8_t)*s++) * 16777619u; return h; }
static uint32_t colkey(SDL_Color c) { return c.r | (uint32_t)c.g << 8 | (uint32_t)c.b << 16 | (uint32_t)c.a << 24; }
static void tc_drop(TC *e) { if (e->t) SDL_DestroyTexture(e->t); free(e->s); memset(e, 0, sizeof *e); }
static void tc_flush(OslUi *u) { if (u->tc) for (int i = 0; i < TC_N; i++) tc_drop(&u->tc->e[i]); }

static TC *tc_get(OslUi *u, const char *s, SDL_Color c, TTF_Font *f) {
    uint32_t ck = colkey(c), h = (hash_str(s) ^ (ck * 2654435761u) ^ (uint32_t)((uintptr_t)f >> 4)) % TC_N;
    TC *a = &u->tc->e[h], *b = &u->tc->e[h ^ 1];
    TC *hit[2] = {a, b};
    for (int i = 0; i < 2; i++)
        if (hit[i]->t && hit[i]->f == f && hit[i]->col == ck && !strcmp(hit[i]->s, s)) { hit[i]->stamp = u->frame; return hit[i]; }
    TC *v = (!a->t || a->stamp <= b->stamp) ? a : b;       /* 2 vías: reemplaza el menos reciente */
    tc_drop(v);
    SDL_Surface *sf = TTF_RenderUTF8_Blended(f, s, c);
    if (!sf) return NULL;
    if (sf->w > 8000) { SDL_FreeSurface(sf); return NULL; }
    v->t = SDL_CreateTextureFromSurface(u->r, sf);
    v->w = sf->w; v->h = sf->h;
    SDL_FreeSurface(sf);
    if (!v->t) return NULL;
    v->s = safe_strdup(s); v->f = f; v->col = ck; v->stamp = u->frame;
    return v;
}

/* ------------------------------------------------------------------- tema */
static const OslTheme THEMES[] = {
    /* oscuro */ {{24, 26, 32, 255}, {34, 37, 46, 255}, {17, 19, 25, 255}, {230, 232, 238, 255}, {150, 155, 168, 255}, {86, 156, 255, 255},
                  {10, 14, 24, 255}, {90, 200, 120, 255}, {235, 95, 95, 255}, {235, 190, 80, 255}, {70, 75, 90, 255}, {52, 57, 72, 255},
                  {70, 78, 100, 255}, {40, 44, 56, 255}, {50, 56, 74, 255}},
    /* claro */  {{238, 240, 245, 255}, {225, 229, 238, 255}, {255, 255, 255, 255}, {28, 32, 42, 255}, {100, 108, 124, 255}, {31, 111, 235, 255},
                  {255, 255, 255, 255}, {30, 150, 80, 255}, {200, 50, 50, 255}, {190, 130, 0, 255}, {190, 196, 210, 255}, {214, 219, 230, 255},
                  {198, 206, 224, 255}, {250, 251, 254, 255}, {232, 238, 250, 255}},
    /* osiris */ {{30, 27, 38, 255}, {42, 37, 56, 255}, {22, 19, 30, 255}, {236, 232, 245, 255}, {160, 150, 180, 255}, {124, 185, 232, 255},
                  {16, 14, 24, 255}, {88, 207, 130, 255}, {240, 98, 110, 255}, {240, 190, 90, 255}, {78, 70, 100, 255}, {60, 52, 82, 255},
                  {111, 66, 193, 255}, {50, 44, 66, 255}, {64, 56, 86, 255}}};
int osl_ui_theme_count(void) { return (int)(sizeof THEMES / sizeof THEMES[0]); }
const char *osl_ui_theme_name(int i) { static const char *n[] = {"Oscuro", "Claro", "Osiris"}; return n[(i < 0 || i >= 3) ? 0 : i]; }
void osl_ui_theme(OslUi *u, int p) { if (p < 0 || p >= osl_ui_theme_count()) p = 0; u->th = THEMES[p]; }

/* ------------------------------------------------------------ inicio / fin */
bool osl_ui_set_font_px(OslUi *u, int px) {
    if (px < 10) px = 10;
    if (px > 28) px = 28;
    safe_ptr(char) fr = osl_font_find(false);
    if (!fr) {
        fputs("osl: no se encontró ninguna fuente TTF. Ejecuta share-fonts/fonts-sync.sh, "
              "o define OSL_FONT=/ruta/fuente.ttf\n", stderr);
        return false;
    }
    TTF_Font *f = TTF_OpenFont(fr, px);
    if (!f) { fprintf(stderr, "osl: TTF_OpenFont(%s): %s\n", fr, TTF_GetError()); return false; }
    safe_ptr(char) fb = osl_font_find(true);
    TTF_Font *b = fb ? TTF_OpenFont(fb, px) : NULL;
    if (!b) { b = TTF_OpenFont(fr, px); if (b) TTF_SetFontStyle(b, TTF_STYLE_BOLD); }   /* negrita sintética */
    tc_flush(u);
    if (u->font) TTF_CloseFont(u->font);
    if (u->fbold) TTF_CloseFont(u->fbold);
    u->font = f; u->fbold = b ? b : f; u->px = px;
    u->lh = TTF_FontHeight(f);
    return true;
}
bool osl_ui_init(OslUi *u, SDL_Renderer *r, int px) {
    memset(u, 0, sizeof *u);
    u->r = r;
    u->tc = (struct OslTextCache *)safe_calloc(1, sizeof *u->tc);
    SDL_SetHint(SDL_HINT_RENDER_SCALE_QUALITY, "linear");
    SDL_SetRenderDrawBlendMode(r, SDL_BLENDMODE_BLEND);
    osl_ui_theme(u, 0);
    return osl_ui_set_font_px(u, px);
}
void osl_ui_shutdown(OslUi *u) {
    tc_flush(u);
    free(u->tc); u->tc = NULL;
    if (u->fbold && u->fbold != u->font) TTF_CloseFont(u->fbold);
    if (u->font) TTF_CloseFont(u->font);
    u->font = u->fbold = NULL;
}
OslInput osl_ui_block(OslUi *u) {
    OslInput s = u->in;
    memset(&u->in, 0, sizeof u->in);
    u->in.mx = u->in.my = -10000;
    return s;
}
void osl_ui_unblock(OslUi *u, OslInput s) { u->in = s; }

void osl_ui_end(OslUi *u) {
    if (u->tip_set && u->ticks - u->hover_since > 600 && u->tip[0]) {
        osl_clip(u, NULL);
        int W, H;
        SDL_GetRendererOutputSize(u->r, &W, &H);
        int tw = osl_text_w(u, u->tip, false) + 14, th = u->lh + 8;
        int x = u->tipx + 14, y = u->tipy + 18;
        if (x + tw > W - 4) x = W - tw - 4;
        if (y + th > H - 4) y = u->tipy - th - 6;
        osl_rect(u, (SDL_Rect){x, y, tw, th}, u->th.panel);
        osl_border(u, (SDL_Rect){x, y, tw, th}, u->th.accent);
        osl_text(u, x + 7, y + 4, u->tip, u->th.text, false);
    }
    u->tip_set = false;
    u->frame++;
    if (u->in.released) u->active = 0;
    u->in.pressed = u->in.released = u->in.rpressed = false;
    u->in.wheel = 0; u->in.clicks = 0; u->in.textin[0] = 0; u->in.nkeys = 0;
    u->in.k_bs = u->in.k_del = u->in.k_left = u->in.k_right = u->in.k_home = u->in.k_end = 0;
    u->in.k_enter = u->in.k_paste = u->in.k_up = u->in.k_down = u->in.k_esc = u->in.k_tab = u->in.k_pgup = u->in.k_pgdn = 0;
    u->in.k_copy = u->in.k_cut = u->in.k_selall = 0;
    u->in.moved = false;
}

/* --------------------------------------------------------------- primitivas */
void osl_clip(OslUi *u, const SDL_Rect *r) {
    if (r) { u->clip = *r; u->hasclip = true; SDL_RenderSetClipRect(u->r, r); }
    else { u->hasclip = false; SDL_RenderSetClipRect(u->r, NULL); }
}
void osl_clip_push(OslUi *u, SDL_Rect r, SDL_Rect *save, bool *had) {
    *save = u->clip; *had = u->hasclip;
    if (u->hasclip) { SDL_Rect o; if (!SDL_IntersectRect(&u->clip, &r, &o)) o = (SDL_Rect){0, 0, 0, 0}; r = o; }
    SDL_RenderSetClipRect(u->r, &r);
}
void osl_clip_pop(OslUi *u, SDL_Rect save, bool had) { SDL_RenderSetClipRect(u->r, had ? &save : NULL); }
bool osl_hover(OslUi *u, SDL_Rect r) {
    SDL_Point p = {u->in.mx, u->in.my};
    if (u->hasclip && !SDL_PointInRect(&p, &u->clip)) return false;
    return SDL_PointInRect(&p, &r);
}
bool osl_key(OslUi *u, SDL_Keycode k) { for (int i = 0; i < u->in.nkeys; i++) if (u->in.keys[i] == k) return true; return false; }
void osl_focus(OslUi *u, const void *p) { u->focus = (uint32_t)(uintptr_t)p; u->cursor = 1 << 20; }
static void setc(OslUi *u, SDL_Color c) { SDL_SetRenderDrawColor(u->r, c.r, c.g, c.b, c.a); }
void osl_rect(OslUi *u, SDL_Rect r, SDL_Color c) { setc(u, c); SDL_RenderFillRect(u->r, &r); }
void osl_border(OslUi *u, SDL_Rect r, SDL_Color c) { setc(u, c); SDL_RenderDrawRect(u->r, &r); }

/* ------------------------------------------------------------------- texto */
int osl_text_w(OslUi *u, const char *s, bool bold) {
    int w = 0, h = 0;
    if (s && *s) TTF_SizeUTF8(bold ? u->fbold : u->font, s, &w, &h);
    return w;
}
void osl_text(OslUi *u, int x, int y, const char *s, SDL_Color c, bool bold) {
    if (!s || !*s) return;
    TC *e = tc_get(u, s, c, bold ? u->fbold : u->font);
    if (!e) return;
    SDL_Rect d = {x, y, e->w, e->h};
    SDL_RenderCopy(u->r, e->t, NULL, &d);
}
void osl_text_clip(OslUi *u, SDL_Rect r, const char *s, SDL_Color c, bool bold) {
    SDL_Rect sv; bool had;
    osl_clip_push(u, r, &sv, &had);
    osl_text(u, r.x + 4, r.y + (r.h - u->lh) / 2, s, c, bold);
    osl_clip_pop(u, sv, had);
}
static int u8prev(const char *s, int i) { if (i <= 0) return 0; i--; while (i > 0 && (s[i] & 0xC0) == 0x80) i--; return i; }
static int u8next(const char *s, int i) { int n = (int)strlen(s); if (i >= n) return n; i++; while (i < n && (s[i] & 0xC0) == 0x80) i++; return i; }

/* copia s en out recortada con "…" para caber en maxw */
static void fit_copy(OslUi *u, const char *s, int maxw, bool bold, char *out, size_t cap) {
    safe_strlcpy(out, s, cap);
    if (osl_text_w(u, out, bold) <= maxw) return;
    int lo = 0, hi = (int)strlen(out);               /* mayor prefijo (en bytes) que cabe con "…" */
    while (lo < hi) {
        int mid = u8next(out, (lo + hi) / 2);
        if (mid > hi) mid = hi;
        char t[1024];
        size_t n = (size_t)mid < sizeof t - 4 ? (size_t)mid : sizeof t - 4;
        memcpy(t, out, n);
        strcpy(t + n, "\xE2\x80\xA6");
        if (osl_text_w(u, t, bold) <= maxw) { if (lo == mid) break; lo = mid; } else hi = u8prev(out, mid);
        if (hi <= lo) break;
    }
    size_t n = (size_t)lo < cap - 4 ? (size_t)lo : cap - 4;
    out[n] = 0;
    strcat(out, "\xE2\x80\xA6");
}
void osl_text_fit(OslUi *u, SDL_Rect r, const char *s, SDL_Color c, bool bold) {
    char t[1024];
    fit_copy(u, s, r.w - 8, bold, t, sizeof t);
    osl_text(u, r.x + 4, r.y + (r.h - u->lh) / 2, t, c, bold);
}

typedef SAFE_VEC(char *) LineVec;
/* Ajusta un párrafo (sin '\n') por palabras; rompe palabras más largas que la línea. */
static void wrap_para(OslUi *u, const char *p, size_t n, int avail, LineVec *lines) {
    SBuf ln = {0};
    size_t i = 0;
    while (i < n) {
        while (i < n && (p[i] == ' ' || p[i] == '\t')) i++;
        size_t j = i;
        while (j < n && p[j] != ' ' && p[j] != '\t') j++;
        if (j == i) break;
        safe_ptr(char) w = safe_strndup(p + i, j - i);
        i = j;
        SBuf t = {0};
        if (ln.len) { sb_str(&t, ln.d); sb_push(&t, ' '); }
        sb_str(&t, w);
        if (osl_text_w(u, t.d, false) <= avail) { sb_free(&ln); ln = t; continue; }
        sb_free(&t);
        if (ln.len) { char *l = sb_take(&ln); safe_vec_push(*lines, l); }
        size_t off = 0, wl = strlen(w);
        for (;;) {
            if (osl_text_w(u, w + off, false) <= avail) { sb_str(&ln, w + off); break; }
            size_t cut = wl - off;
            for (;;) {
                cut = (size_t)u8prev(w + off, (int)cut);
                if (cut == 0) break;
                char sv = w[off + cut]; w[off + cut] = 0;
                int wd = osl_text_w(u, w + off, false);
                w[off + cut] = sv;
                if (wd <= avail) break;
            }
            if (cut == 0) cut = (size_t)u8next(w + off, 0);          /* al menos un carácter */
            char *l = safe_strndup(w + off, cut);
            safe_vec_push(*lines, l);
            off += cut;
        }
    }
    if (ln.len || n == 0) { char *l = ln.len ? sb_take(&ln) : safe_strdup(""); safe_vec_push(*lines, l); }
    sb_free(&ln);
}

int osl_text_wrap(OslUi *u, SDL_Rect r, const char *s, SDL_Color c, int max_lines, bool draw) {
    LineVec lines = {0};
    int avail = r.w - 8;
    const char *p = s ? s : "";
    for (;;) {
        const char *e = strchr(p, '\n');
        wrap_para(u, p, e ? (size_t)(e - p) : strlen(p), avail, &lines);
        if (!e) break;
        p = e + 1;
    }
    int n = (int)lines.n;
    bool trunc = max_lines > 0 && n > max_lines;
    if (trunc) n = max_lines;
    if (draw) {
        for (int i = 0; i < n; i++) {
            if (i == n - 1 && trunc) {
                char t[1024];
                safe_ptr(char) l2 = safe_asprintf("%s\xE2\x80\xA6", lines.d[i]);
                fit_copy(u, l2, avail, false, t, sizeof t);
                osl_text(u, r.x + 4, r.y + i * u->lh, t, c, false);
            } else osl_text(u, r.x + 4, r.y + i * u->lh, lines.d[i], c, false);
        }
    }
    for (size_t i = 0; i < lines.n; i++) free(lines.d[i]);
    safe_vec_free(lines);
    return n * u->lh;
}

/* ----------------------------------------------------------------- widgets */
bool osl_button(OslUi *u, SDL_Rect r, const char *label, int fl) {
    uint32_t id = hash_str(label) ^ ((uint32_t)r.x * 73856093u) ^ ((uint32_t)r.y * 19349663u);
    bool dis = fl & OSL_DISABLED, hov = !dis && osl_hover(u, r), click = false;
    if (hov && u->in.pressed) u->active = id;
    if (u->in.released && u->active == id && hov) click = true;
    SDL_Color bg = u->th.btn, fg = u->th.text;
    if (fl & OSL_PRIMARY) { bg = u->th.accent; fg = u->th.accent_text; }
    if (fl & OSL_DANGER) { bg = u->th.err; fg = u->th.accent_text; }
    if (fl & OSL_ACTIVE) { bg = u->th.accent; fg = u->th.accent_text; }
    if (dis) { bg = u->th.btn; fg = u->th.dim; }
    if (hov) { bg.r = (uint8_t)(bg.r + (255 - bg.r) / 6); bg.g = (uint8_t)(bg.g + (255 - bg.g) / 6); bg.b = (uint8_t)(bg.b + (255 - bg.b) / 6); }
    if (hov && u->active == id && u->in.mdown) { bg.r = (uint8_t)(bg.r * 3 / 4); bg.g = (uint8_t)(bg.g * 3 / 4); bg.b = (uint8_t)(bg.b * 3 / 4); }
    osl_rect(u, r, bg);
    osl_border(u, r, u->th.border);
    int tw = osl_text_w(u, label, false);
    SDL_Rect sv; bool had;
    osl_clip_push(u, r, &sv, &had);
    osl_text(u, r.x + (r.w - tw) / 2, r.y + (r.h - u->lh) / 2, label, fg, false);
    osl_clip_pop(u, sv, had);
    return click;
}
bool osl_checkbox(OslUi *u, int x, int y, const char *label, bool *v) {
    SDL_Rect box = {x, y, 18, 18}, all = {x, y, 26 + osl_text_w(u, label, false), 18};
    bool hov = osl_hover(u, all), ch = false;
    if (hov && u->in.pressed) { *v = !*v; ch = true; }
    osl_rect(u, box, u->th.field);
    osl_border(u, box, hov ? u->th.accent : u->th.border);
    if (*v) osl_rect(u, (SDL_Rect){x + 4, y + 4, 10, 10}, u->th.accent);
    osl_text(u, x + 26, y + (18 - u->lh) / 2, label, u->th.text, false);
    return ch;
}
static void ins(char *buf, int cap, int *cur, const char *s, int n) {
    int len = (int)strlen(buf);
    if (len + n >= cap) { n = cap - 1 - len; while (n > 0 && (s[n] & 0xC0) == 0x80) n--; }   /* no cortar UTF-8 */
    if (n <= 0) return;
    memmove(buf + *cur + n, buf + *cur, (size_t)(len - *cur + 1));
    memcpy(buf + *cur, s, (size_t)n);
    *cur += n;
}
/* índice de byte más cercano a relx (posición relativa al inicio del texto) */
static int idx_at(OslUi *u, char *buf, int relx) {
    int len = (int)strlen(buf), prevw = 0;
    if (relx <= 0) return 0;
    for (int i = 0; i < len;) {
        int n = u8next(buf, i);
        char sv = buf[n]; buf[n] = 0;
        int w = osl_text_w(u, buf, false);
        buf[n] = sv;
        if (relx < (prevw + w) / 2) return i;
        prevw = w; i = n;
    }
    return len;
}
static int width_to(OslUi *u, char *buf, int idx) { char sv = buf[idx]; buf[idx] = 0; int w = osl_text_w(u, buf, false); buf[idx] = sv; return w; }
static void del_range(char *buf, int lo, int hi) { memmove(buf + lo, buf + hi, strlen(buf + hi) + 1); }

bool osl_input(OslUi *u, SDL_Rect r, char *buf, size_t capz, const char *placeholder) {
    OslInput *in = &u->in;
    int cap = (int)capz;
    uint32_t id = (uint32_t)(uintptr_t)buf;
    bool hov = osl_hover(u, r), enter = false, was_focus = (u->focus == id);
    int len = (int)strlen(buf);
    if (in->pressed && hov) {
        u->focus = id; u->active = id;
        int idx = idx_at(u, buf, in->mx - (r.x + 5) + (was_focus ? u->sx : 0));
        if (in->clicks >= 3) { u->anchor = 0; u->cursor = len; }
        else if (in->clicks == 2) {
            int s = idx, e = idx;
            while (s > 0 && buf[s - 1] != ' ') s--;
            while (e < len && buf[e] != ' ') e++;
            u->anchor = s; u->cursor = e;
        } else u->anchor = u->cursor = idx;
    } else if (in->pressed && u->focus == id) u->focus = 0;
    bool f = (u->focus == id);
    if (f && u->active == id && in->mdown && !in->pressed) u->cursor = idx_at(u, buf, in->mx - (r.x + 5) + u->sx);
    int cur = f ? u->cursor : len, anc = f ? u->anchor : len;
    if (f) {
        if (cur > len) cur = len;
        if (anc > len) anc = len;
        bool shift = (in->mod & KMOD_SHIFT) != 0;
        int lo = cur < anc ? cur : anc, hi = cur < anc ? anc : cur;
        if (in->k_selall) { anc = 0; cur = len; lo = 0; hi = len; }
        if ((in->k_copy || in->k_cut) && hi > lo) {
            char sv = buf[hi]; buf[hi] = 0; SDL_SetClipboardText(buf + lo); buf[hi] = sv;
            if (in->k_cut) { del_range(buf, lo, hi); cur = anc = lo; }
        }
        int tl = (int)strlen(in->textin), pl = 0;
        char pt[4096];
        if (in->k_paste) {
            char *c = SDL_GetClipboardText();
            if (c) { for (const char *p = c; *p && pl < (int)sizeof pt - 1; p++) pt[pl++] = ((unsigned char)*p < 32) ? ' ' : *p; SDL_free(c); }
            pt[pl] = 0;
        }
        if (tl || pl) {
            lo = cur < anc ? cur : anc; hi = cur < anc ? anc : cur;
            if (hi > lo) { del_range(buf, lo, hi); cur = lo; }
            if (tl) ins(buf, cap, &cur, in->textin, tl);
            if (pl) ins(buf, cap, &cur, pt, pl);
            anc = cur;
        }
        len = (int)strlen(buf);
        lo = cur < anc ? cur : anc; hi = cur < anc ? anc : cur;
        if (in->k_bs) { if (hi > lo) { del_range(buf, lo, hi); cur = lo; } else if (cur > 0) { int p = u8prev(buf, cur); del_range(buf, p, cur); cur = p; } anc = cur; }
        len = (int)strlen(buf);
        lo = cur < anc ? cur : anc; hi = cur < anc ? anc : cur;
        if (in->k_del) { if (hi > lo) { del_range(buf, lo, hi); cur = lo; } else if (cur < len) del_range(buf, cur, u8next(buf, cur)); anc = cur; }
        len = (int)strlen(buf);
        if (cur > len) cur = len;
        lo = cur < anc ? cur : anc; hi = cur < anc ? anc : cur;
        if (in->k_left)  { if (!shift && hi > lo) cur = lo; else cur = u8prev(buf, cur); if (!shift) anc = cur; }
        if (in->k_right) { if (!shift && hi > lo) cur = hi; else cur = u8next(buf, cur); if (!shift) anc = cur; }
        if (in->k_home) { cur = 0; if (!shift) anc = cur; }
        if (in->k_end)  { cur = len; if (!shift) anc = cur; }
        if (in->k_enter) enter = true;
        u->cursor = cur; u->anchor = anc;
    }
    osl_rect(u, r, u->th.field);
    osl_border(u, r, f ? u->th.accent : u->th.border);
    int vw = r.w - 10, cw = width_to(u, buf, cur), sx = (f && cw > vw) ? cw - vw : 0;   /* sin foco: se ve el principio del texto */
    if (f) u->sx = sx;
    SDL_Rect sc; bool had;
    osl_clip_push(u, (SDL_Rect){r.x + 3, r.y, r.w - 6, r.h}, &sc, &had);
    if (f && cur != anc) {
        int a1 = width_to(u, buf, cur < anc ? cur : anc), a2 = width_to(u, buf, cur < anc ? anc : cur);
        SDL_Color sel = u->th.accent; sel.a = 110;
        osl_rect(u, (SDL_Rect){r.x + 5 - sx + a1, r.y + 3, a2 - a1, r.h - 6}, sel);
    }
    if (!buf[0] && placeholder && !f) osl_text(u, r.x + 5, r.y + (r.h - u->lh) / 2, placeholder, u->th.dim, false);
    osl_text(u, r.x + 5 - sx, r.y + (r.h - u->lh) / 2, buf, u->th.text, false);
    if (f && cur == anc && ((u->ticks / 500) & 1) == 0) osl_rect(u, (SDL_Rect){r.x + 5 - sx + cw, r.y + 5, 1, r.h - 10}, u->th.text);
    osl_clip_pop(u, sc, had);
    return enter;
}
bool osl_cycle(OslUi *u, SDL_Rect r, const char *const *items, int n, int *sel) {
    if (*sel < 0 || *sel >= n) *sel = 0;
    char lbl[128];
    snprintf(lbl, sizeof lbl, "%s   \xE2\x96\xB8", items[*sel]);
    bool c = osl_button(u, r, lbl, 0);
    if (c) *sel = (*sel + 1) % n;
    return c;
}
void osl_progress(OslUi *u, SDL_Rect r, float pct, SDL_Color c) {
    if (pct < 0) pct = 0;
    if (pct > 100) pct = 100;
    osl_rect(u, r, u->th.field);
    osl_rect(u, (SDL_Rect){r.x, r.y, (int)(r.w * pct / 100.0f), r.h}, c);
    osl_border(u, r, u->th.border);
    char t[16];
    snprintf(t, sizeof t, "%.1f%%", pct);
    osl_text(u, r.x + (r.w - osl_text_w(u, t, false)) / 2, r.y + (r.h - u->lh) / 2, t, u->th.text, false);
}
void osl_tip(OslUi *u, SDL_Rect r, const char *text) {
    if (!osl_hover(u, r)) return;
    safe_strlcpy(u->tip, text, sizeof u->tip);
    u->tipx = u->in.mx; u->tipy = u->in.my; u->tip_set = true;
}

/* ---------------------------------------------------------------- deslizador */
int osl_slider(OslUi *u, SDL_Rect r, double *v, double lo, double hi, double second) {
    uint32_t id = (uint32_t)(uintptr_t)v ^ 0x51d3u;
    int res = OSL_SLIDER_NONE;
    SDL_Rect hit = {r.x - 6, r.y - 6, r.w + 12, r.h + 12};
    bool hov = osl_hover(u, hit);
    if (hov && u->in.pressed) u->active = id;
    bool dragging = (u->active == id);
    if (dragging && (u->in.mdown || u->in.released)) {
        double t = (double)(u->in.mx - r.x) / (r.w > 0 ? r.w : 1);
        if (t < 0) t = 0;
        if (t > 1) t = 1;
        *v = lo + (hi - lo) * t;
        res = u->in.released ? OSL_SLIDER_COMMIT : OSL_SLIDER_DRAG;
    }
    double t = hi > lo ? (*v - lo) / (hi - lo) : 0;
    if (t < 0) t = 0;
    if (t > 1) t = 1;
    int th = 4, ty = r.y + (r.h - th) / 2;
    osl_rect(u, (SDL_Rect){r.x, ty, r.w, th}, u->th.border);
    if (second >= lo && second <= hi && hi > lo) {
        SDL_Color c = u->th.dim; c.a = 140;
        osl_rect(u, (SDL_Rect){r.x, ty, (int)(r.w * (second - lo) / (hi - lo)), th}, c);
    }
    osl_rect(u, (SDL_Rect){r.x, ty, (int)(r.w * t), th}, u->th.accent);
    int kr = (hov || dragging) ? 7 : 5, kx = r.x + (int)(r.w * t);
    osl_rect(u, (SDL_Rect){kx - kr, r.y + r.h / 2 - kr, 2 * kr, 2 * kr}, u->th.accent);
    return res;
}

/* ------------------------------------------------------------------ scroll */
static SDL_Rect thumb_rect(SDL_Rect v, int content_h, int off) {
    int th = content_h > 0 ? (int)((int64_t)v.h * v.h / content_h) : v.h;
    if (th < 24) th = 24;
    if (th > v.h) th = v.h;
    int max = content_h - v.h, ty = max > 0 ? (int)((int64_t)(v.h - th) * off / max) : 0;
    return (SDL_Rect){v.x + v.w - 9, v.y + ty, 8, th};
}
void osl_scroll_update(OslUi *u, SDL_Rect v, int content_h, int *off) {
    int max = content_h > v.h ? content_h - v.h : 0;
    if (osl_hover(u, v) && u->in.wheel) *off -= u->in.wheel * (u->lh * 3);
    uint32_t id = (uint32_t)(uintptr_t)off ^ 0x5c01u;
    if (max > 0) {
        SDL_Rect t = thumb_rect(v, content_h, *off);
        SDL_Rect track = {t.x - 4, v.y, 14, v.h};
        if (u->in.pressed && osl_hover(u, track)) u->active = id;
        if (u->active == id && u->in.mdown) {
            int span = v.h - t.h;
            if (span > 0) *off = (int)((int64_t)(u->in.my - v.y - t.h / 2) * max / span);
        }
    }
    if (*off > max) *off = max;
    if (*off < 0) *off = 0;
}
void osl_scroll_draw(OslUi *u, SDL_Rect v, int content_h, int off) {
    if (content_h <= v.h) return;
    SDL_Rect sv; bool had;
    osl_clip_push(u, v, &sv, &had);
    SDL_Color c = u->th.border;
    osl_rect(u, thumb_rect(v, content_h, off), c);
    osl_clip_pop(u, sv, had);
}

/* -------------------------------------------------------------------- menú */
int osl_menu(OslUi *u, int x, int y, const char *const *items, int n, int *open) {
    if (!*open) return -1;
    int W, H, rh = u->lh + 8, w = 0, res = -1;
    SDL_GetRendererOutputSize(u->r, &W, &H);
    for (int i = 0; i < n; i++) { int t = osl_text_w(u, items[i], false); if (t > w) w = t; }
    w += 28;
    int h = 0;
    for (int i = 0; i < n; i++) h += strcmp(items[i], "---") ? rh : 9;
    if (x + w > W - 4) x = W - w - 4;
    if (y + h > H - 4) y = H - h - 4;
    if (x < 4) x = 4;
    if (y < 4) y = 4;
    SDL_Rect box = {x, y, w, h};
    SDL_Rect sv = u->clip, full = {0, 0, W, H};
    bool had = u->hasclip;
    bool fresh = (*open == 1);                       /* el primer fotograma ignora la entrada */
    osl_clip(u, &full);                              /* el menú se dibuja sobre todo, sin recortes previos */
    osl_rect(u, (SDL_Rect){x + 3, y + 3, w, h}, (SDL_Color){0, 0, 0, 90});
    osl_rect(u, box, u->th.panel);
    osl_border(u, box, u->th.border);
    int cy = y;
    for (int i = 0; i < n; i++) {
        if (!strcmp(items[i], "---")) { osl_rect(u, (SDL_Rect){x + 6, cy + 4, w - 12, 1}, u->th.border); cy += 9; continue; }
        SDL_Rect row = {x, cy, w, rh};
        bool hov = !fresh && osl_hover(u, row);
        if (hov) osl_rect(u, row, u->th.btnhov);
        osl_text(u, x + 14, cy + (rh - u->lh) / 2, items[i], hov ? u->th.text : u->th.text, false);
        if (hov && u->in.pressed) res = i;
        cy += rh;
    }
    if (had) osl_clip(u, &sv); else osl_clip(u, NULL);
    if (fresh) { *open = 2; return -1; }
    SDL_Point p = {u->in.mx, u->in.my};
    if (res >= 0) { *open = 0; return res; }
    if ((u->in.pressed && !SDL_PointInRect(&p, &box)) || u->in.k_esc) *open = 0;
    return -1;
}

/* ---------------------------------------------------------------- texturas */
SDL_Texture *osl_texture_load(OslUi *u, const char *path, int *w, int *h) {
    struct stat st;
    if (!path || !*path || stat(path, &st) != 0 || !S_ISREG(st.st_mode) || st.st_size > (20 << 20)) return NULL;
#ifdef OSL_HAVE_IMAGE
    SDL_Surface *s = IMG_Load(path);
#else
    SDL_Surface *s = SDL_LoadBMP(path);
#endif
    if (!s) return NULL;
    SDL_Texture *t = SDL_CreateTextureFromSurface(u->r, s);
    if (t && w) *w = s->w;
    if (t && h) *h = s->h;
    SDL_FreeSurface(s);
    return t;
}
void osl_texture_draw_fit(OslUi *u, SDL_Texture *t, int tw, int th, SDL_Rect b) {
    if (!t || tw <= 0 || th <= 0) return;
    float s = (float)b.w / tw < (float)b.h / th ? (float)b.w / tw : (float)b.h / th;
    int w = (int)(tw * s), h = (int)(th * s);
    SDL_Rect d = {b.x + (b.w - w) / 2, b.y + (b.h - h) / 2, w, h};
    SDL_RenderCopy(u->r, t, NULL, &d);
}
SDL_Color osl_color_from_str(const char *s, const OslTheme *th) {
    (void)th;
    uint32_t h = hash_str(s ? s : "");
    static const SDL_Color P[] = {{111, 66, 193, 255}, {40, 167, 69, 255}, {0, 123, 255, 255}, {220, 53, 69, 255},
                                  {23, 162, 184, 255}, {253, 126, 20, 255}, {232, 62, 140, 255}, {32, 201, 151, 255}};
    return P[h % (sizeof P / sizeof P[0])];
}
