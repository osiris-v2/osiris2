#include "osl/osl_gfx.h"
#include <stdlib.h>

static void setc(OslUi *u, SDL_Color c) { SDL_SetRenderDrawColor(u->r, c.r, c.g, c.b, c.a); }
void osl_line(OslUi *u, int x1, int y1, int x2, int y2, SDL_Color c) { setc(u, c); SDL_RenderDrawLine(u->r, x1, y1, x2, y2); }

void osl_tri_fill(OslUi *u, int x1, int y1, int x2, int y2, int x3, int y3, SDL_Color c) {
    int ymin = y1 < y2 ? (y1 < y3 ? y1 : y3) : (y2 < y3 ? y2 : y3);
    int ymax = y1 > y2 ? (y1 > y3 ? y1 : y3) : (y2 > y3 ? y2 : y3);
    int xs[3] = {x1, x2, x3}, ys[3] = {y1, y2, y3};
    setc(u, c);
    for (int y = ymin; y <= ymax; y++) {
        int lo = 1 << 30, hi = -(1 << 30);
        for (int i = 0; i < 3; i++) {
            int j = (i + 1) % 3, ya = ys[i], yb = ys[j];
            if ((y < ya && y < yb) || (y > ya && y > yb) || ya == yb) continue;
            int x = xs[i] + (int)((long)(y - ya) * (xs[j] - xs[i]) / (yb - ya));
            if (x < lo) lo = x;
            if (x > hi) hi = x;
        }
        if (lo <= hi) SDL_RenderDrawLine(u->r, lo, y, hi, y);
    }
}
void osl_circle_fill(OslUi *u, int cx, int cy, int r, SDL_Color c) {
    setc(u, c);
    for (int dy = -r; dy <= r; dy++) {
        int dx = (int)(__builtin_sqrt((double)(r * r - dy * dy)) + 0.5);
        SDL_RenderDrawLine(u->r, cx - dx, cy + dy, cx + dx, cy + dy);
    }
}

void osl_icon(OslUi *u, SDL_Rect b, OslIcon ic, SDL_Color c) {
    int s = b.w < b.h ? b.w : b.h, x = b.x + (b.w - s) / 2, y = b.y + (b.h - s) / 2;
    int p = s / 4;                                   /* margen */
    int l = x + p, t = y + p, r = x + s - p, bt = y + s - p, cx = x + s / 2, cy = y + s / 2, w = r - l, h = bt - t;
#define RC(X, Y, W, H) osl_rect(u, (SDL_Rect){X, Y, W, H}, c)
    switch (ic) {
        case OSL_ICON_PLAY:  osl_tri_fill(u, l + w / 8, t, l + w / 8, bt, r, cy, c); break;
        case OSL_ICON_PAUSE: RC(l + w / 6, t, w / 3, h); RC(r - w / 6 - w / 3, t, w / 3, h); break;
        case OSL_ICON_STOP:  RC(l + w / 8, t + h / 8, w - w / 4, h - h / 4); break;
        case OSL_ICON_PREV:  RC(l, t, 2, h); osl_tri_fill(u, r, t, r, bt, l + 3, cy, c); break;
        case OSL_ICON_NEXT:  RC(r - 2, t, 2, h); osl_tri_fill(u, l, t, l, bt, r - 3, cy, c); break;
        case OSL_ICON_VOLUME: case OSL_ICON_MUTE:
            RC(l, cy - h / 6, w / 4, h / 3);
            osl_tri_fill(u, l + w / 4, cy - h / 6, l + w / 4, cy + h / 6, l + w / 2 + 1, cy + h / 2, c);
            osl_tri_fill(u, l + w / 4, cy - h / 6, l + w / 2 + 1, cy - h / 2, l + w / 2 + 1, cy + h / 2, c);
            if (ic == OSL_ICON_VOLUME) { osl_line(u, r - w / 6, cy - h / 4, r - w / 6, cy + h / 4, c); osl_line(u, r, cy - h / 3, r, cy + h / 3, c); }
            else { osl_line(u, r - w / 3, cy - h / 4, r, cy + h / 4, c); osl_line(u, r - w / 3, cy + h / 4, r, cy - h / 4, c); }
            break;
        case OSL_ICON_FULLSCREEN: case OSL_ICON_WINDOWED: {
            int k = w / 3;
            if (ic == OSL_ICON_FULLSCREEN) {
                RC(l, t, k, 2); RC(l, t, 2, k); RC(r - k, t, k, 2); RC(r - 2, t, 2, k);
                RC(l, bt - 2, k, 2); RC(l, bt - k, 2, k); RC(r - k, bt - 2, k, 2); RC(r - 2, bt - k, 2, k);
            } else {
                RC(l + k, t + k, k, 2); RC(l + k, t + k, 2, k); RC(r - 2 * k, t + k, k, 2); RC(r - k - 2, t + k, 2, k);
                RC(l + k, bt - k - 2, k, 2); RC(l + k, bt - 2 * k, 2, k); RC(r - 2 * k, bt - k - 2, k, 2); RC(r - k - 2, bt - 2 * k, 2, k);
            }
            break;
        }
        case OSL_ICON_LIST: for (int i = 0; i < 3; i++) { RC(l, t + i * (h / 2) - (i ? 1 : 0), 3, 2); RC(l + 5, t + i * (h / 2) - (i ? 1 : 0), w - 5, 2); } break;
        case OSL_ICON_CLOSE: osl_line(u, l, t, r, bt, c); osl_line(u, l + 1, t, r, bt - 1, c); osl_line(u, r, t, l, bt, c); osl_line(u, r - 1, t, l, bt - 1, c); break;
        case OSL_ICON_PLUS:  RC(l, cy - 1, w, 2); RC(cx - 1, t, 2, h); break;
        case OSL_ICON_MINUS: RC(l, cy - 1, w, 2); break;
    }
#undef RC
}
bool osl_button_icon(OslUi *u, SDL_Rect r, OslIcon icon, int flags) {
    bool click = osl_button(u, r, "", flags);
    SDL_Color c = (flags & OSL_DISABLED) ? u->th.dim : ((flags & (OSL_ACTIVE | OSL_PRIMARY)) ? u->th.accent_text : u->th.text);
    osl_icon(u, r, icon, c);
    return click;
}
