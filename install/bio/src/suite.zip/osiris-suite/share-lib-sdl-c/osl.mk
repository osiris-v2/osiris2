# osl.mk - fragmento reutilizable de share-lib-sdl-c.
# Uso en el Makefile de un programa:
#     include ../share-lib-sdl-c/osl.mk
#     $(BIN): $(APP_SRC) $(OSL_SRC)
#         $(CC) $(OSL_CFLAGS) $(CFLAGS) $^ $(OSL_LIBS) -o $@
# Variables que define: OSL_DIR OSL_SRC OSL_CFLAGS OSL_LIBS OSL_HAS_IMG
OSL_DIR     := $(patsubst %/,%,$(dir $(lastword $(MAKEFILE_LIST))))
OSL_SRC     := $(wildcard $(OSL_DIR)/src/*.c)
OSL_HDR     := $(wildcard $(OSL_DIR)/include/osl/*.h)
OSL_HAS_IMG := $(shell pkg-config --exists SDL2_image 2>/dev/null && echo 1)
OSL_PKGS    := sdl2 SDL2_ttf $(if $(OSL_HAS_IMG),SDL2_image)
OSL_CFLAGS  := -std=gnu11 -Wall -Wextra -Wno-unused-parameter -I$(OSL_DIR)/include \
               $(shell pkg-config --cflags $(OSL_PKGS)) $(if $(OSL_HAS_IMG),-DOSL_HAVE_IMAGE)
OSL_LIBS    := $(shell pkg-config --libs $(OSL_PKGS)) -lpthread -lm
