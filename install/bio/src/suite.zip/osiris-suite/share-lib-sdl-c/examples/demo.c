/* demo.c - recorrido por widgets y diálogos de share-lib-sdl-c. */
#include "osl/osl.h"
typedef struct { char text[256]; bool chk; int sel, scroll, menu, theme; char last[256]; } Demo;
static const char *ITEMS[] = {"Uno", "Dos", "Tres"};
static const char *MENU[] = {"Abrir", "---", "Salir"};
static void on_path(bool ok, const char *p, void *user) { Demo *d = (Demo *)user; snprintf(d->last, sizeof d->last, ok ? "Elegido: %s" : "Cancelado", p); }
static void on_conf(bool y, void *user) { Demo *d = (Demo *)user; snprintf(d->last, sizeof d->last, y ? "Confirmado" : "Rechazado"); }
static void frame(OslApp *a, void *user) {
    Demo *d = (Demo *)user;
    OslUi *u = osl_app_ui(a);
    int W, H;
    osl_app_size(a, &W, &H);
    osl_text(u, 16, 14, "share-lib-sdl-c · demo", u->th.accent, true);
    osl_input(u, (SDL_Rect){16, 50, 400, u->lh + 10}, d->text, sizeof d->text, "Escribe aquí…");
    osl_checkbox(u, 16, 96, "Casilla de verificación", &d->chk);
    osl_cycle(u, (SDL_Rect){16, 126, 200, u->lh + 10}, ITEMS, 3, &d->sel);
    if (osl_button(u, (SDL_Rect){16, 170, 150, u->lh + 10}, "Menú", 0)) d->menu = 1;
    if (osl_button(u, (SDL_Rect){176, 170, 150, u->lh + 10}, "Confirmar", OSL_PRIMARY)) osl_dlg_confirm(a, "Confirmación", "¿Seguro que quieres continuar con la operación de ejemplo?", "Sí, adelante", "No", on_conf, d);
    if (osl_button(u, (SDL_Rect){336, 170, 150, u->lh + 10}, "Elegir fichero", 0)) osl_dlg_path(a, "Elegir un fichero", OSL_PATH_OPEN_FILE, ".", NULL, on_path, d);
    if (osl_button(u, (SDL_Rect){496, 170, 150, u->lh + 10}, "Tema", 0)) { d->theme = (d->theme + 1) % osl_ui_theme_count(); osl_ui_theme(u, d->theme); }
    osl_progress(u, (SDL_Rect){16, 220, 400, 20}, 62.5f, u->th.accent);
    osl_text(u, 16, 256, d->last, u->th.ok, false);
    osl_text_wrap(u, (SDL_Rect){16, 286, 360, 0}, "Texto con ajuste de línea: esta frase es lo bastante larga para ocupar varias líneas dentro del ancho dado, con una palabra interminable: abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyz.", u->th.text, 0, true);
    int sel = osl_menu(u, 16, 210, MENU, 3, &d->menu);
    if (sel == 2) osl_app_quit(a);
}
int main(void) {
    OslApp *a = osl_app_create(&(OslAppDesc){.title = "osl demo", .w = 800, .h = 520});
    if (!a) return 1;
    Demo d = {0};
    if (getenv("OSL_DEMO_DIALOG")) osl_dlg_path(a, "Elegir un fichero", OSL_PATH_OPEN_FILE, getenv("OSL_DEMO_DIALOG"), "json;md;txt", on_path, &d);
    if (getenv("OSL_DEMO_MENU")) d.menu = 1;
    osl_app_run(a, frame, &d);
    osl_app_destroy(a);
    return 0;
}
