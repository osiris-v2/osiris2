#include "osl/osl_json.h"
#include "osl/osl_fs.h"
#include "osl/osl_proc.h"
#include <assert.h>
#include <stdio.h>
static int fails;
#define CHECK(c) do { if (!(c)) { printf("FALLO %s:%d: %s\n", __FILE__, __LINE__, #c); fails++; } } while (0)
int main(void) {
    char err[200];
    /* JSON: ida y vuelta, escapes y unicode */
    const char *src = "[{\"name\":\"Caf\\u00e9 \\ud83d\\ude80\",\"n\":3,\"f\":1.5,\"ok\":true,\"x\":null,\"l\":[1,[2]],\"s\":\"a\\\"b\\n\"}]";
    OslJson *j = osl_json_parse(src, err, sizeof err);
    CHECK(j && j->t == OSL_J_ARR && j->n == 1);
    OslJson *o = j->v[0];
    CHECK(!strcmp(osl_json_str_or(o, "name", ""), "Café 🚀"));
    CHECK(osl_json_num_or(o, "n", 0) == 3 && osl_json_num_or(o, "f", 0) == 1.5);
    CHECK(osl_json_bool_or(o, "ok", false));
    char *d = osl_json_dump(j, 2);
    OslJson *j2 = osl_json_parse(d, err, sizeof err);
    CHECK(j2 != NULL);
    char *d2 = osl_json_dump(j2, 2);
    CHECK(!strcmp(d, d2));
    free(d); free(d2); osl_json_free(j2);
    /* edición */
    osl_json_obj_set(o, "name", osl_json_str("X")); osl_json_obj_del(o, "x");
    CHECK(!strcmp(osl_json_str_or(o, "name", ""), "X") && !osl_json_obj_get(o, "x"));
    OslJson *t = osl_json_arr_take(j, 0); CHECK(t == o && j->n == 0); osl_json_free(t); osl_json_free(j);
    /* errores */
    const char *bad[] = {"", "[1,]", "{\"a\":}", "{\"a\" 1}", "[1 2]", "\"abc", "[1] x", "{\"a\":\"\\q\"}", "[\"\\ud800\"]", "nul", "-", "[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[1]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]", NULL};
    for (int i = 0; bad[i]; i++) { OslJson *x = osl_json_parse(bad[i], err, sizeof err); CHECK(x == NULL && err[0]); osl_json_free(x); }
    OslJson *e = osl_json_parse("{\n \"a\": [1,\n 2,]}", err, sizeof err); CHECK(!e && strstr(err, "línea 3")); 
    /* split */
    char **a = osl_proc_split("prog --x \"a b\" 'c d' e\\f \"\"");
    CHECK(osl_argv_len(a) == 6 && !strcmp(a[2], "a b") && !strcmp(a[3], "c d") && !strcmp(a[5], ""));
    osl_argv_free(a);
    /* fs */
    char *ex = osl_fs_expand("~/x/${HOME}/$HOME"); CHECK(strstr(ex, osl_fs_home()) == ex); free(ex);
    char *p = osl_fs_join("/a/", "b"); CHECK(!strcmp(p, "/a/b")); free(p);
    CHECK(osl_fs_write_atomic("/tmp/oslt/x/y.json", "{}", 2, true, err, sizeof err));
    CHECK(osl_fs_write_atomic("/tmp/oslt/x/y.json", "[1]", 3, true, err, sizeof err));
    size_t l; char *r = osl_fs_read_all("/tmp/oslt/x/y.json", 100, &l, err, sizeof err); CHECK(r && l == 3); free(r);
    r = osl_fs_read_all("/tmp/oslt/x/y.json.bak", 100, &l, err, sizeof err); CHECK(r && l == 2); free(r);
    CHECK(!osl_fs_read_all("/tmp/oslt/x/y.json", 2, &l, err, sizeof err));
    OslDirList dl = {0}; CHECK(osl_fs_list("/tmp/oslt", &dl, false) && dl.n == 1 && dl.d[0].is_dir); osl_fs_list_free(&dl);
    char pth[256]; CHECK(osl_fs_which("sh", pth, sizeof pth));
    CHECK(!osl_proc_launch((char *[]){"/no/existe", NULL}, err, sizeof err));
    CHECK(osl_proc_launch((char *[]){"true", NULL}, err, sizeof err));
    { char *o; size_t ol; int st;
      CHECK(osl_proc_capture((char *[]){"sh", "-c", "echo hola; exit 3", NULL}, 2000, 1000, &o, &ol, &st, err, sizeof err) && !strcmp(o, "hola\n") && st == 3); free(o);
      CHECK(!osl_proc_capture((char *[]){"sleep", "5", NULL}, 300, 1000, &o, &ol, &st, err, sizeof err) && strstr(err, "tiempo"));
      CHECK(osl_proc_capture((char *[]){"sh", "-c", "yes | head -c 100000", NULL}, 3000, 1000, &o, &ol, &st, err, sizeof err) && ol == 1000); free(o);
      { char *e2; CHECK(osl_proc_capture_ex((char *[]){"sh", "-c", "echo salida; echo problema >&2; exit 1", NULL}, 2000, 1000, &o, &ol, &e2, &st, err, sizeof err) && !strcmp(o, "salida\n") && !strcmp(e2, "problema\n") && st == 1); free(o); free(e2); }
      CHECK(!osl_proc_capture((char *[]){"no-existe-zz", NULL}, 1000, 10, &o, &ol, &st, err, sizeof err)); }
    printf(fails ? "%d fallos\n" : "OK: todos los tests\n", fails);
    return fails != 0;
}
