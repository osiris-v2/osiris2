# share-lib-sdl-c (osl) v0.2

Librería C (GNU C11) compartida por los programas Osiris: memoria y punteros seguros, JSON, ficheros, procesos, fuentes, widgets SDL2 de modo inmediato y gestor de ventana con diálogos.

- Documentación completa (arquitectura, **manual técnico**, API, referencia generada, integración, pruebas, hoja de ruta): **`docs/index.html`**
- Programas que la usan: `osiris-launcher-c`, `osiris-player-c` (el reproductor motivó la v0.2)
- Probar: `make test` · `make demo && ./build/osl-demo`
- Usar: `include ../share-lib-sdl-c/osl.mk` en el Makefile del programa, o `add_subdirectory` en CMake.
- Dependencias: SDL2, SDL2_ttf (y SDL2_image opcional para iconos PNG/JPG/SVG).
