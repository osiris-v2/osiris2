/* osl_proc.h - lanzamiento de procesos sin shell. */
#ifndef OSL_PROC_H
#define OSL_PROC_H
#include <stdbool.h>
#include <stddef.h>
/* Divide una línea de comandos respetando comillas simples y dobles.
 * Devuelve un vector terminado en NULL (liberar con osl_argv_free). */
char **osl_proc_split(const char *cmdline);
void   osl_argv_free(char **argv);
size_t osl_argv_len(char *const *argv);
/* Lanza argv desacoplado (nueva sesión, stdio a /dev/null, sin zombis).
 * No usa shell: los argumentos no se interpretan. false + err si falla. */
bool   osl_proc_launch(char *const argv[], char *err, size_t ec);
/* Envuelve argv en un emulador de terminal disponible; NULL si no hay ninguno. */
char **osl_proc_terminal_wrap(char *const argv[]);
/* Ejecuta argv y captura su salida estándar (stderr se descarta). BLOQUEA: llámala desde un hilo de trabajo.
 * timeout_ms <= 0: sin límite. max_bytes limita la salida (el resto se descarta y truncated=true).
 * Devuelve true si el proceso arrancó y terminó a tiempo; *status = código de salida (o -1 si lo mató una señal).
 * *out es memoria propia terminada en '\0' (libérala con free). Al vencer el tiempo se mata el grupo de procesos. */
bool   osl_proc_capture(char *const argv[], int timeout_ms, size_t max_bytes, char **out, size_t *len, int *status, char *err, size_t ec);
/* Igual que osl_proc_capture pero captura también stderr en *errout (memoria propia; NULL = descartar). max_bytes aplica a cada flujo. */
bool   osl_proc_capture_ex(char *const argv[], int timeout_ms, size_t max_bytes, char **out, size_t *len, char **errout, int *status, char *err, size_t ec);
/* Abre un fichero/carpeta/URL con la aplicación predeterminada (xdg-open / open). */
bool   osl_proc_open(const char *target, char *err, size_t ec);
#endif
