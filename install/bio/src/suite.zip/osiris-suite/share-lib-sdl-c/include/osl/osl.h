/* osl.h - cabecera paraguas de share-lib-sdl-c (versión 0.2). */
#ifndef OSL_H
#define OSL_H
#define OSL_VERSION_MAJOR 0
#define OSL_VERSION_MINOR 2
#include "osl_safe.h"
#include "osl_json.h"
#include "osl_fs.h"
#include "osl_proc.h"
#include "osl_font.h"
#include "osl_ui.h"
#include "osl_gfx.h"
#include "osl_app.h"
#endif
