/* osl_ui.h - widgets de modo inmediato sobre SDL2 + SDL2_ttf. */
#ifndef OSL_UI_H
#define OSL_UI_H
#include <SDL.h>
#include <SDL_ttf.h>
#include <stdbool.h>
#include <stdint.h>

typedef struct {
    SDL_Color bg, panel, field, text, dim, accent, accent_text, ok, err, warn, border, btn, btnhov, card, cardhov;
} OslTheme;

/* Entrada de un fotograma (la rellena osl_app; puede bloquearse para diálogos modales). */
typedef struct {
    int mx, my, wheel, clicks;
    bool pressed, released, mdown, rpressed;
    char textin[128];
    int k_bs, k_del, k_left, k_right, k_home, k_end, k_enter, k_paste, k_up, k_down, k_esc, k_tab, k_pgup, k_pgdn;
    int k_copy, k_cut, k_selall;
    bool moved;                         /* el ratón se movió o hubo clic en este fotograma */
    SDL_Keycode keys[8];
    int nkeys;
    uint16_t mod;
} OslInput;

enum { OSL_DISABLED = 1, OSL_ACTIVE = 2, OSL_PRIMARY = 4, OSL_DANGER = 8 };

typedef struct OslUi {
    SDL_Renderer *r;
    TTF_Font *font, *fbold;
    int px, lh;
    OslTheme th;
    OslInput in;
    uint32_t active, focus, ticks, frame, hover_since;
    int cursor, anchor, sx;             /* cursor/ancla de selección y desplazamiento del campo con foco */
    SDL_Rect clip;
    bool hasclip;
    char tip[256];
    int tipx, tipy;
    bool tip_set;
    struct OslTextCache *tc;
} OslUi;

bool  osl_ui_init(OslUi *u, SDL_Renderer *r, int px);
void  osl_ui_shutdown(OslUi *u);
bool  osl_ui_set_font_px(OslUi *u, int px);
int   osl_ui_theme_count(void);
const char *osl_ui_theme_name(int i);
void  osl_ui_theme(OslUi *u, int preset);
void  osl_ui_end(OslUi *u);                      /* dibuja tooltip y limpia la entrada del fotograma */
OslInput osl_ui_block(OslUi *u);                 /* vacía la entrada y devuelve la anterior */
void  osl_ui_unblock(OslUi *u, OslInput saved);

bool  osl_hover(OslUi *u, SDL_Rect r);
bool  osl_key(OslUi *u, SDL_Keycode k);          /* ¿se pulsó k en este fotograma? */
void  osl_focus(OslUi *u, const void *id_ptr);   /* da foco a un osl_input por su buffer */

void  osl_rect(OslUi *u, SDL_Rect r, SDL_Color c);
void  osl_border(OslUi *u, SDL_Rect r, SDL_Color c);
void  osl_clip(OslUi *u, const SDL_Rect *r);     /* recorte absoluto; NULL lo quita */
void  osl_clip_push(OslUi *u, SDL_Rect r, SDL_Rect *save, bool *had);   /* recorte anidado */
void  osl_clip_pop(OslUi *u, SDL_Rect save, bool had);

int   osl_text_w(OslUi *u, const char *s, bool bold);
void  osl_text(OslUi *u, int x, int y, const char *s, SDL_Color c, bool bold);
void  osl_text_clip(OslUi *u, SDL_Rect r, const char *s, SDL_Color c, bool bold);   /* recorta */
void  osl_text_fit(OslUi *u, SDL_Rect r, const char *s, SDL_Color c, bool bold);    /* acorta con "…" */
/* Ajuste de línea. Devuelve la altura usada. draw=false solo mide. max_lines=0: sin límite. */
int   osl_text_wrap(OslUi *u, SDL_Rect r, const char *s, SDL_Color c, int max_lines, bool draw);

bool  osl_button(OslUi *u, SDL_Rect r, const char *label, int flags);
bool  osl_checkbox(OslUi *u, int x, int y, const char *label, bool *v);
/* Campo de texto UTF-8 con selección: arrastrar, doble clic (palabra), triple (todo), Mayús+flechas,
 * Ctrl+A/C/X/V. Devuelve true al pulsar Enter. */
bool  osl_input(OslUi *u, SDL_Rect r, char *buf, size_t cap, const char *placeholder);
bool  osl_cycle(OslUi *u, SDL_Rect r, const char *const *items, int n, int *sel);
void  osl_progress(OslUi *u, SDL_Rect r, float pct, SDL_Color c);
/* Deslizador horizontal. *v en [lo,hi]; second (opcional, fuera de rango = ninguno) pinta una segunda barra (p.ej. búfer).
 * Devuelve OSL_SLIDER_DRAG mientras se arrastra (*v cambia) y OSL_SLIDER_COMMIT al soltar o al hacer clic. */
enum { OSL_SLIDER_NONE = 0, OSL_SLIDER_DRAG = 1, OSL_SLIDER_COMMIT = 2 };
int   osl_slider(OslUi *u, SDL_Rect r, double *v, double lo, double hi, double second);
void  osl_tip(OslUi *u, SDL_Rect r, const char *text);
/* Scroll vertical: update ANTES de dibujar el contenido, draw DESPUÉS. */
void  osl_scroll_update(OslUi *u, SDL_Rect view, int content_h, int *offset);
void  osl_scroll_draw(OslUi *u, SDL_Rect view, int content_h, int offset);
/* Menú emergente. *open: 0 cerrado, ponlo a 1 para abrirlo. Devuelve el índice elegido o -1.
 * "---" crea un separador. Se cierra al elegir, pulsar fuera o Esc. */
int   osl_menu(OslUi *u, int x, int y, const char *const *items, int n, int *open);

SDL_Texture *osl_texture_load(OslUi *u, const char *path, int *w, int *h);   /* PNG/JPG/SVG con SDL2_image, si no BMP */
void  osl_texture_draw_fit(OslUi *u, SDL_Texture *t, int tw, int th, SDL_Rect box);
SDL_Color osl_color_from_str(const char *s, const OslTheme *th);              /* color estable por texto */
#endif
