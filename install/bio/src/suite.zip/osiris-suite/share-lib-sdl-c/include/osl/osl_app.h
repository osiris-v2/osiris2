/* osl_app.h - ventana, bucle de eventos y diálogos modales.
 * Modelo: el programa da una función de fotograma que dibuja la UI (modo inmediato). */
#ifndef OSL_APP_H
#define OSL_APP_H
#include "osl_ui.h"

typedef struct OslApp OslApp;
typedef struct {
    const char *title, *app_id;
    int w, h, min_w, min_h;
    int font_px;       /* 0 = 15 */
    int theme;
} OslAppDesc;
typedef void (*OslFrameFn)(OslApp *app, void *user);

OslApp *osl_app_create(const OslAppDesc *d);          /* NULL si falla (mensaje en stderr) */
void    osl_app_destroy(OslApp *a);
void    osl_app_run(OslApp *a, OslFrameFn frame, void *user);
void    osl_app_quit(OslApp *a);
void    osl_app_wake(OslApp *a);                      /* fuerza un redibujado (seguro desde otros hilos) */
OslUi  *osl_app_ui(OslApp *a);
SDL_Window *osl_app_window(OslApp *a);
void    osl_app_size(OslApp *a, int *w, int *h);
void    osl_app_set_continuous(OslApp *a, bool on);   /* dibuja sin pausas (vídeo/animación); ~vsync */
void    osl_app_set_fullscreen(OslApp *a, bool on);
bool    osl_app_is_fullscreen(OslApp *a);
void    osl_app_set_title(OslApp *a, const char *title);
void    osl_app_show_cursor(OslApp *a, bool show);
/* Arrastrar y soltar: se llama con la ruta del fichero o el texto (p.ej. una URL) soltado. */
typedef void (*OslDropFn)(const char *what, void *user);
void    osl_app_on_drop(OslApp *a, OslDropFn fn, void *user);
void    osl_app_toast(OslApp *a, const char *fmt, ...) __attribute__((format(printf, 2, 3)));

/* Diálogos modales no bloqueantes: el resultado llega por callback. */
typedef void (*OslConfirmFn)(bool yes, void *user);
typedef void (*OslPromptFn)(bool ok, const char *text, void *user);
typedef void (*OslPathFn)(bool ok, const char *path, void *user);
typedef enum { OSL_PATH_OPEN_FILE, OSL_PATH_SAVE_FILE, OSL_PATH_OPEN_DIR } OslPathMode;

void osl_dlg_message(OslApp *a, const char *title, const char *text);
void osl_dlg_confirm(OslApp *a, const char *title, const char *text, const char *yes, const char *no, OslConfirmFn cb, void *user);
void osl_dlg_prompt(OslApp *a, const char *title, const char *label, const char *initial, OslPromptFn cb, void *user);
/* ext_filter: extensiones sin punto separadas por ';' (p.ej. "png;jpg;svg") o NULL para todo. */
void osl_dlg_path(OslApp *a, const char *title, OslPathMode mode, const char *start, const char *ext_filter, OslPathFn cb, void *user);
bool osl_dlg_active(OslApp *a);
#endif
