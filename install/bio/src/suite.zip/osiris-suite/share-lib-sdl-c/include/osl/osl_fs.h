/* osl_fs.h - rutas, ficheros y directorios con comprobaciones seguras. */
#ifndef OSL_FS_H
#define OSL_FS_H
#include <stdbool.h>
#include <stddef.h>
#include "osl_safe.h"
typedef struct { char *name; bool is_dir; } OslDirEnt;
typedef SAFE_VEC(OslDirEnt) OslDirList;

bool  osl_fs_exists(const char *p);
bool  osl_fs_is_dir(const char *p);
bool  osl_fs_is_exec(const char *p);                 /* fichero regular ejecutable */
const char *osl_fs_home(void);
char *osl_fs_expand(const char *p);                  /* ~, $VAR y ${VAR}; malloc */
char *osl_fs_join(const char *a, const char *b);     /* une con '/', malloc */
const char *osl_fs_basename(const char *p);
char *osl_fs_dirname(const char *p);                 /* malloc */
char *osl_fs_exe_dir(void);                          /* carpeta del ejecutable; malloc */
char *osl_fs_config_dir(const char *app);            /* $XDG_CONFIG_HOME/app o ~/.config/app; malloc */
bool  osl_fs_mkdir_p(const char *path);
bool  osl_fs_which(const char *name, char *out, size_t n);   /* búsqueda en PATH */
/* Lee un fichero completo (terminado en '\0'). max limita el tamaño. NULL si falla. */
char *osl_fs_read_all(const char *path, size_t max, size_t *len, char *err, size_t ec);
/* Escritura atómica (tmp + fsync + rename). backup=true conserva path.bak del contenido anterior. */
bool  osl_fs_write_atomic(const char *path, const char *data, size_t len, bool backup, char *err, size_t ec);
/* Lista un directorio: carpetas primero, orden alfabético sin distinguir mayúsculas. */
bool  osl_fs_list(const char *dir, OslDirList *out, bool show_hidden);
void  osl_fs_list_free(OslDirList *l);
#endif
