/* osl_safe.h - memoria y punteros seguros (GCC/Clang). Parte de share-lib-sdl-c.
 * Convención: este módulo conserva el prefijo corto safe_* (compatible con proyectos anteriores). */
#ifndef OSL_SAFE_H
#define OSL_SAFE_H
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <stddef.h>
#include <stdint.h>

#ifndef __GNUC__
#error "share-lib-sdl-c requiere GCC o Clang (computed goto y __attribute__((cleanup)))"
#endif

static inline void safe_die(const char *m) { fprintf(stderr, "osl: %s\n", m); abort(); }
static inline void *safe_malloc(size_t n) { void *p = malloc(n ? n : 1); if (!p) safe_die("sin memoria"); return p; }
static inline void *safe_calloc(size_t n, size_t s) { void *p = calloc(n ? n : 1, s ? s : 1); if (!p) safe_die("sin memoria"); return p; }
static inline void *safe_realloc(void *o, size_t n) { void *p = realloc(o, n ? n : 1); if (!p) safe_die("sin memoria"); return p; }
/* variantes con comprobación de desbordamiento de n*sz */
static inline void *safe_array(size_t n, size_t sz) { if (sz && n > SIZE_MAX / sz) safe_die("desbordamiento de tamaño"); return safe_malloc(n * sz); }
static inline void *safe_reallocarray(void *o, size_t n, size_t sz) { if (sz && n > SIZE_MAX / sz) safe_die("desbordamiento de tamaño"); return safe_realloc(o, n * sz); }
static inline char *safe_strndup(const char *s, size_t n) { size_t l = strnlen(s, n); char *p = (char *)safe_malloc(l + 1); memcpy(p, s, l); p[l] = 0; return p; }
static inline char *safe_strdup(const char *s) { return safe_strndup(s, strlen(s)); }
/* Copia acotada; siempre termina en '\0'. Devuelve strlen(src). */
static inline size_t safe_strlcpy(char *d, const char *s, size_t n) {
    size_t l = strlen(s);
    if (n) { size_t c = l >= n ? n - 1 : l; memcpy(d, s, c); d[c] = 0; }
    return l;
}
__attribute__((format(printf, 1, 2)))
static inline char *safe_asprintf(const char *fmt, ...) {
    va_list a, b;
    va_start(a, fmt); va_copy(b, a);
    int n = vsnprintf(NULL, 0, fmt, a);
    va_end(a);
    if (n < 0) { va_end(b); return safe_strdup(""); }
    char *s = (char *)safe_malloc((size_t)n + 1);
    vsnprintf(s, (size_t)n + 1, fmt, b);
    va_end(b);
    return s;
}

/* Liberación automática y segura */
static inline void safe_autofree(void *pp) { void **p = (void **)pp; if (*p) { free(*p); *p = NULL; } }
#define safe_ptr(T) T *__attribute__((cleanup(safe_autofree)))
#define safe_free(pp) do { __typeof__(pp) _pp = (pp); if (_pp && *_pp) { free(*_pp); *_pp = NULL; } } while (0)
#define SAFE_MOVE(p) ({ __typeof__(p) _t = (p); (p) = NULL; _t; })

/* Cadena dinámica */
typedef struct { char *d; size_t len, cap; } SBuf;
static inline void sb_push(SBuf *b, char c) {
    if (b->len + 2 > b->cap) { b->cap = b->cap ? b->cap * 2 : 128; b->d = (char *)safe_realloc(b->d, b->cap); }
    b->d[b->len++] = c; b->d[b->len] = 0;
}
static inline void sb_str(SBuf *b, const char *s) { while (*s) sb_push(b, *s++); }
static inline void sb_clear(SBuf *b) { b->len = 0; if (b->d) b->d[0] = 0; }
static inline void sb_free(SBuf *b) { free(b->d); b->d = NULL; b->len = b->cap = 0; }
static inline char *sb_take(SBuf *b) { char *s = b->d ? b->d : safe_strdup(""); b->d = NULL; b->len = b->cap = 0; return s; }

/* Vector tipado. Los macros reciben el vector como lvalue (no puntero):
 *   SAFE_VEC(int) v = {0};  safe_vec_push(v, 3);  safe_vec_free(v);
 * Para insertar structs con comas usa una variable temporal. */
#define SAFE_VEC(T) struct { T *d; size_t n, cap; }
#define safe_vec_reserve(v, want) do { size_t _w = (want); if (_w > (v).cap) { size_t _c = (v).cap ? (v).cap : 8; \
    while (_c < _w) { _c *= 2; } (v).d = safe_reallocarray((v).d, _c, sizeof *(v).d); (v).cap = _c; } } while (0)
#define safe_vec_push(v, x) do { safe_vec_reserve(v, (v).n + 1); (v).d[(v).n++] = (x); } while (0)
#define safe_vec_remove(v, i) do { size_t _i = (i); if (_i < (v).n) { \
    memmove(&(v).d[_i], &(v).d[_i + 1], ((v).n - _i - 1) * sizeof *(v).d); (v).n--; } } while (0)
#define safe_vec_free(v) do { free((v).d); (v).d = NULL; (v).n = (v).cap = 0; } while (0)
#endif
