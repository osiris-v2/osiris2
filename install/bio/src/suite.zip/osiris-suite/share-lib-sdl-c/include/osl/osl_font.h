/* osl_font.h - descubrimiento de fuentes TTF (share-fonts primero, después el sistema). */
#ifndef OSL_FONT_H
#define OSL_FONT_H
#include <stdbool.h>
#include <stddef.h>
/* Rellena out con carpetas candidatas en orden de prioridad. Devuelve cuántas. */
size_t osl_font_dirs(char out[][512], size_t max);
/* Ruta de la fuente regular o negrita (malloc) o NULL. Respeta OSL_FONT y OSL_FONT_BOLD. */
char *osl_font_find(bool bold);
#endif
