/* osl_json.h - parser/serializador JSON mínimo y seguro. Los objetos conservan el orden de claves. */
#ifndef OSL_JSON_H
#define OSL_JSON_H
#include <stdbool.h>
#include <stddef.h>
typedef enum { OSL_J_NULL, OSL_J_BOOL, OSL_J_NUM, OSL_J_STR, OSL_J_ARR, OSL_J_OBJ } OslJType;
typedef struct OslJson OslJson;
struct OslJson {
    OslJType t;
    bool b;
    double num;
    char *str;
    OslJson **v;   /* elementos (array) o valores (objeto) */
    char **k;      /* claves (solo objeto) */
    size_t n, cap;
};
/* Devuelve NULL y escribe un mensaje "línea/columna" en err si el texto es inválido. */
OslJson *osl_json_parse(const char *text, char *err, size_t errcap);
void     osl_json_free(OslJson *j);
char    *osl_json_dump(const OslJson *j, int indent);   /* malloc; indent 0 = compacto */
OslJson *osl_json_clone(const OslJson *j);
OslJson *osl_json_new(OslJType t);
OslJson *osl_json_str(const char *s);
OslJson *osl_json_bool(bool b);
OslJson *osl_json_num(double d);
/* Las funciones que reciben OslJson* "item/val" TOMAN su propiedad. */
void     osl_json_arr_push(OslJson *arr, OslJson *item);
void     osl_json_arr_insert(OslJson *arr, size_t i, OslJson *item);
OslJson *osl_json_arr_take(OslJson *arr, size_t i);     /* extrae sin liberar */
void     osl_json_obj_set(OslJson *obj, const char *key, OslJson *val);
bool     osl_json_obj_del(OslJson *obj, const char *key);
OslJson *osl_json_obj_get(const OslJson *obj, const char *key);
const char *osl_json_str_or(const OslJson *obj, const char *key, const char *def);
bool     osl_json_bool_or(const OslJson *obj, const char *key, bool def);
double   osl_json_num_or(const OslJson *obj, const char *key, double def);
#endif
