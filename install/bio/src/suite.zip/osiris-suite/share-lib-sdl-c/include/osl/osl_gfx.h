/* osl_gfx.h - primitivas 2D e iconos vectoriales (sin depender de fuentes). */
#ifndef OSL_GFX_H
#define OSL_GFX_H
#include "osl_ui.h"
typedef enum { OSL_ICON_PLAY, OSL_ICON_PAUSE, OSL_ICON_STOP, OSL_ICON_PREV, OSL_ICON_NEXT, OSL_ICON_VOLUME, OSL_ICON_MUTE,
               OSL_ICON_FULLSCREEN, OSL_ICON_WINDOWED, OSL_ICON_LIST, OSL_ICON_CLOSE, OSL_ICON_PLUS, OSL_ICON_MINUS } OslIcon;
void osl_line(OslUi *u, int x1, int y1, int x2, int y2, SDL_Color c);
void osl_tri_fill(OslUi *u, int x1, int y1, int x2, int y2, int x3, int y3, SDL_Color c);   /* por scanlines: portable */
void osl_circle_fill(OslUi *u, int cx, int cy, int r, SDL_Color c);
void osl_icon(OslUi *u, SDL_Rect box, OslIcon icon, SDL_Color c);
/* Botón cuadrado con icono (mismos flags que osl_button). */
bool osl_button_icon(OslUi *u, SDL_Rect r, OslIcon icon, int flags);
#endif
