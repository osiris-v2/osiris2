#!/usr/bin/env bash
# fonts-sync.sh - reúne fuentes TTF en esta carpeta (share-fonts) para todos los programas Osiris.
#   ./fonts-sync.sh               busca en el sistema y copia las familias conocidas (por defecto)
#   ./fonts-sync.sh --link        igual, pero con enlaces simbólicos en vez de copias
#   ./fonts-sync.sh --download    descarga DejaVu (licencia libre) si faltan
#   ./fonts-sync.sh --list        solo muestra qué hay (aquí y en el sistema)
# Las fuentes que SDL2_ttf puede usar son .ttf/.otf. Se ignoran las de color (emoji).
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
MODE=copy; DOWNLOAD=0; LIST=0
for a in "$@"; do case "$a" in
  --link) MODE=link;; --download) DOWNLOAD=1;; --list) LIST=1;;
  -h|--help) sed -n '2,8p' "$0"; exit 0;;
  *) echo "Opción desconocida: $a" >&2; exit 2;; esac; done

WANTED=(DejaVuSans.ttf DejaVuSans-Bold.ttf DejaVuSansMono.ttf DejaVuSansMono-Bold.ttf
        LiberationSans-Regular.ttf LiberationSans-Bold.ttf LiberationMono-Regular.ttf
        NotoSans-Regular.ttf NotoSans-Bold.ttf NotoSansMono-Regular.ttf
        Ubuntu-R.ttf Ubuntu-B.ttf Roboto-Regular.ttf Roboto-Bold.ttf FiraSans-Regular.ttf FiraSans-Bold.ttf)
ROOTS=(/usr/share/fonts /usr/local/share/fonts "$HOME/.fonts" "$HOME/.local/share/fonts"
       /Library/Fonts /System/Library/Fonts /System/Library/Fonts/Supplemental)
EXIST=(); for r in "${ROOTS[@]}"; do [ -d "$r" ] && EXIST+=("$r"); done

find_font() { [ ${#EXIST[@]} -gt 0 ] && find "${EXIST[@]}" -type f -iname "$1" 2>/dev/null | head -n1 || true; }

if [ $LIST -eq 1 ]; then
  echo "== En $HERE =="; ls -1 "$HERE"/*.ttf "$HERE"/*.otf 2>/dev/null | xargs -n1 basename 2>/dev/null || echo "(vacía)"
  echo "== En el sistema =="; for w in "${WANTED[@]}"; do f="$(find_font "$w")"; [ -n "$f" ] && echo "$f"; done
  exit 0
fi

n=0
for w in "${WANTED[@]}"; do
  [ -e "$HERE/$w" ] && continue
  src="$(find_font "$w")"
  [ -z "$src" ] && continue
  if [ "$MODE" = link ]; then ln -sf "$src" "$HERE/$w"; else cp -f "$src" "$HERE/$w"; fi
  echo "  + $w  <-  $src"; n=$((n+1))
done
echo "Añadidas desde el sistema: $n"

if [ $DOWNLOAD -eq 1 ] && { [ ! -e "$HERE/DejaVuSans.ttf" ] || [ ! -e "$HERE/DejaVuSans-Bold.ttf" ]; }; then
  URL="https://github.com/dejavu-fonts/dejavu-fonts/releases/download/version_2_37/dejavu-fonts-ttf-2.37.zip"
  TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
  echo "Descargando DejaVu 2.37 ..."
  if command -v curl >/dev/null; then curl -fL --retry 2 -o "$TMP/d.zip" "$URL"; else wget -q -O "$TMP/d.zip" "$URL"; fi
  command -v unzip >/dev/null || { echo "Falta 'unzip'." >&2; exit 1; }
  unzip -q "$TMP/d.zip" -d "$TMP"
  for f in DejaVuSans.ttf DejaVuSans-Bold.ttf DejaVuSansMono.ttf DejaVuSansMono-Bold.ttf; do
    cp -f "$TMP"/dejavu-fonts-ttf-*/ttf/$f "$HERE/$f"; echo "  + $f (descargada)"; done
  cp -f "$TMP"/dejavu-fonts-ttf-*/LICENSE "$HERE/LICENSE-DejaVu.txt" 2>/dev/null || true
fi

if [ ! -e "$HERE/DejaVuSans.ttf" ] && ! ls "$HERE"/*.ttf >/dev/null 2>&1; then
  echo "No hay ninguna fuente en share-fonts. Prueba: ./fonts-sync.sh --download" >&2; exit 1
fi
echo "Listo. Fuentes en $HERE:"; ls -1 "$HERE"/*.ttf "$HERE"/*.otf 2>/dev/null | xargs -n1 basename
