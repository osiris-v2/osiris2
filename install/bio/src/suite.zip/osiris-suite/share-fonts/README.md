# share-fonts

Fuentes TTF compartidas por todos los programas Osiris (las busca `osl_font_find`, antes que las del sistema).

Incluidas: **DejaVu Sans / Sans Bold / Sans Mono / Mono Bold** (licencia libre, ver `LICENSE-DejaVu.txt`).

    ./fonts-sync.sh              # copia desde el sistema (DejaVu, Liberation, Noto, Ubuntu, Roboto, Fira)
    ./fonts-sync.sh --link       # enlaces simbólicos en vez de copias
    ./fonts-sync.sh --download   # descarga DejaVu 2.37 si faltan
    ./fonts-sync.sh --list       # qué hay aquí y en el sistema

Orden de búsqueda: `OSL_FONT` → `OSL_FONT_DIR` → esta carpeta (junto al ejecutable, `../`, `../../`, cwd, `~/.local/share/osiris/share-fonts`) → fuentes del sistema.
Para la interfaz se prefiere `DejaVuSans.ttf` + `DejaVuSans-Bold.ttf`. Si añades otras familias, el orden de preferencia está en `osl_font.c`.
