/* model.h - datos del lanzador: aplicaciones (JSON), ajustes y estadísticas. Sin dependencias de UI salvo SDL_Texture. */
#ifndef LAUNCHER_MODEL_H
#define LAUNCHER_MODEL_H
#include "osl/osl.h"

#define LAUNCHER_VERSION "3.0.0"

typedef struct {
    char *name, *alias, *path, *args, *cwd, *icon, *category, *desc;
    bool enabled, terminal, shell, valid, isobj;
    SDL_Texture *tex; int tw, th; bool tex_tried;
    int runs; long last; bool fav;
    char warn[160];
} AppEntry;
typedef SAFE_VEC(AppEntry) AppList;

typedef struct {
    int theme, font_px, card_size, sort, after_launch;
    bool show_desc, show_icons, confirm_launch;
    char apps_file[512];
} Settings;

typedef struct {
    OslJson *doc;               /* lista de aplicaciones: fuente de verdad (conserva campos desconocidos) */
    OslJson *cfg;               /* {"settings":{...},"stats":{...}} */
    char apps_path[512], cfg_path[512], cfg_dir[512];
    AppList apps;               /* una entrada por elemento de doc, en el mismo orden */
    SAFE_VEC(char *) warns;
    Settings set;
    bool dirty;                 /* doc modificado sin guardar */
    char init_msg[300];         /* aviso de arranque (fichero ilegible, etc.) */
} Model;

void model_init(Model *m, const char *cli_apps);
void model_free(Model *m);
bool model_load_apps(Model *m, const char *path, char *err, size_t ec);
bool model_save_apps(Model *m, char *err, size_t ec);
void model_rebuild(Model *m);                       /* doc -> apps, validación y estadísticas */
void model_check(AppEntry *e);                      /* rellena e->valid y e->warn */
bool model_save_cfg(Model *m);
/* Construye argv. wrap=true añade cd/terminal. Libera con osl_argv_free. */
bool model_argv(const AppEntry *e, char ***out, char *err, size_t ec, bool wrap);
bool model_launch(Model *m, int idx, char *err, size_t ec);
void model_set_fav(Model *m, int idx, bool fav);
#endif
