#define _GNU_SOURCE
#include "model.h"
#include <time.h>

static const char *S(const OslJson *o, const char *k) { return osl_json_str_or(o, k, ""); }

static const char *DEFAULT_APPS =
"[\n"
"    {\"name\": \"Terminal\", \"alias\": \"x-terminal-emulator\", \"category\": \"Sistema\", \"description\": \"Emulador de terminal del sistema\", \"enabled\": true},\n"
"    {\"name\": \"Gestor de archivos\", \"alias\": \"xdg-open\", \"args\": \"~\", \"category\": \"Sistema\", \"description\": \"Abre tu carpeta personal\", \"enabled\": true},\n"
"    {\"name\": \"Navegador web\", \"alias\": \"xdg-open\", \"args\": \"https://www.wikipedia.org\", \"category\": \"Internet\", \"description\": \"Abre el navegador predeterminado\", \"enabled\": true},\n"
"    {\"name\": \"Monitor (htop)\", \"alias\": \"htop\", \"terminal\": true, \"category\": \"Sistema\", \"description\": \"Se ejecuta dentro de una terminal\", \"enabled\": true}\n"
"]\n";

/* ------------------------------------------------------------------ entradas */
static void entry_free(AppEntry *e) {
    free(e->name); free(e->alias); free(e->path); free(e->args); free(e->cwd); free(e->icon); free(e->category); free(e->desc);
    if (e->tex) SDL_DestroyTexture(e->tex);
    memset(e, 0, sizeof *e);
}
static void entry_from_json(AppEntry *e, const OslJson *o) {
    memset(e, 0, sizeof *e);
    if (!o || o->t != OSL_J_OBJ) {
        e->name = safe_strdup("(entrada inválida)");
        e->alias = safe_strdup(""); e->path = safe_strdup(""); e->args = safe_strdup(""); e->cwd = safe_strdup("");
        e->icon = safe_strdup(""); e->category = safe_strdup(""); e->desc = safe_strdup("");
        snprintf(e->warn, sizeof e->warn, "El elemento no es un objeto JSON");
        return;
    }
    e->isobj = true;
    const char *al = S(o, "alias");
    if (!*al) al = S(o, "command");
    e->name = safe_strdup(S(o, "name")); e->alias = safe_strdup(al); e->path = safe_strdup(S(o, "path"));
    e->args = safe_strdup(S(o, "args")); e->cwd = safe_strdup(S(o, "cwd")); e->icon = safe_strdup(S(o, "icon"));
    e->category = safe_strdup(S(o, "category")); e->desc = safe_strdup(S(o, "description"));
    e->enabled = osl_json_bool_or(o, "enabled", true);          /* por defecto HABILITADA (el original ocultaba) */
    e->terminal = osl_json_bool_or(o, "terminal", false);
    e->shell = osl_json_bool_or(o, "shell", false);
}

/* ------------------------------------------------------------- comando seguro */
static char *expand_tok(const char *t) { return (t[0] == '~' && (t[1] == '/' || !t[1])) ? osl_fs_expand(t) : safe_strdup(t); }
static char **argv_cat(char **a, char **b) {
    SAFE_VEC(char *) v = {0};
    for (size_t i = 0; a && a[i]; i++) safe_vec_push(v, a[i]);
    for (size_t i = 0; b && b[i]; i++) { char *t = expand_tok(b[i]); safe_vec_push(v, t); }
    safe_vec_push(v, (char *)NULL);
    free(a);
    osl_argv_free(b);
    return v.d;
}
bool model_argv(const AppEntry *e, char ***out, char *err, size_t ec, bool wrap) {
    char **argv = NULL;
    *out = NULL;
    if (!e->alias[0]) { snprintf(err, ec, "El comando (alias) está vacío"); return false; }
    if (e->shell) {
        char *cmd = safe_asprintf("%s%s%s", e->alias, e->args[0] ? " " : "", e->args);
        argv = (char **)safe_calloc(4, sizeof *argv);
        argv[0] = safe_strdup("/bin/sh"); argv[1] = safe_strdup("-c"); argv[2] = cmd;
    } else {
        safe_ptr(char) al = osl_fs_expand(e->alias);
        safe_ptr(char) pa = e->path[0] ? osl_fs_expand(e->path) : NULL;
        safe_ptr(char) full = pa ? osl_fs_join(pa, al) : safe_strdup(al);
        if (osl_fs_exists(full) && !osl_fs_is_dir(full)) {       /* ruta con espacios sin comillas */
            argv = (char **)safe_calloc(2, sizeof *argv);
            argv[0] = safe_strdup(full);
        } else argv = osl_proc_split(full);
        if (!argv[0]) { osl_argv_free(argv); snprintf(err, ec, "Comando vacío"); return false; }
        if (e->args[0]) argv = argv_cat(argv, osl_proc_split(e->args));
    }
    if (wrap && e->cwd[0]) {
        safe_ptr(char) cwd = osl_fs_expand(e->cwd);
        if (!osl_fs_is_dir(cwd)) { osl_argv_free(argv); snprintf(err, ec, "El directorio de trabajo no existe: %s", cwd); return false; }
        SAFE_VEC(char *) v = {0};
        char *s1 = safe_strdup("/bin/sh"), *s2 = safe_strdup("-c"), *s3 = safe_strdup("cd \"$0\" && exec \"$@\""), *s4 = safe_strdup(cwd);
        safe_vec_push(v, s1); safe_vec_push(v, s2); safe_vec_push(v, s3); safe_vec_push(v, s4);
        for (size_t i = 0; argv[i]; i++) safe_vec_push(v, argv[i]);
        safe_vec_push(v, (char *)NULL);
        free(argv);
        argv = v.d;
    }
    if (wrap && e->terminal) {
        char **t = osl_proc_terminal_wrap(argv);
        osl_argv_free(argv);
        if (!t) { snprintf(err, ec, "No se encontró ningún emulador de terminal (xterm, gnome-terminal, konsole…)"); return false; }
        argv = t;
    }
    *out = argv;
    return true;
}

void model_check(AppEntry *e) {
    e->warn[0] = 0;
    if (!e->isobj) { e->valid = false; snprintf(e->warn, sizeof e->warn, "El elemento no es un objeto JSON"); return; }
    if (!e->name[0] || !e->alias[0]) { e->valid = false; snprintf(e->warn, sizeof e->warn, "Falta 'name' o 'alias'"); return; }
    e->valid = true;
    if (!e->shell) {
        char **argv, err[160];
        if (!model_argv(e, &argv, err, sizeof err, false)) { snprintf(e->warn, sizeof e->warn, "%s", err); return; }
        const char *c = argv[0];
        bool ok = strchr(c, '/') ? osl_fs_is_exec(c) : osl_fs_which(c, NULL, 0);
        if (!ok) snprintf(e->warn, sizeof e->warn, "Comando no encontrado o no ejecutable: %.100s", c);
        osl_argv_free(argv);
    }
    if (!e->warn[0] && e->cwd[0]) {
        safe_ptr(char) c = osl_fs_expand(e->cwd);
        if (!osl_fs_is_dir(c)) snprintf(e->warn, sizeof e->warn, "El directorio de trabajo no existe");
    }
    if (!e->warn[0] && e->icon[0]) {
        safe_ptr(char) c = osl_fs_expand(e->icon);
        if (!osl_fs_exists(c)) snprintf(e->warn, sizeof e->warn, "No se encuentra el icono");
    }
}

/* ---------------------------------------------------------------- estadísticas */
static OslJson *stats_obj(Model *m) {
    OslJson *s = osl_json_obj_get(m->cfg, "stats");
    if (!s || s->t != OSL_J_OBJ) { s = osl_json_new(OSL_J_OBJ); osl_json_obj_set(m->cfg, "stats", s); }
    return s;
}
static char *entry_key(const AppEntry *e) { return safe_asprintf("%s|%s", e->name, e->alias); }
static void stat_write(Model *m, const AppEntry *e) {
    safe_ptr(char) k = entry_key(e);
    OslJson *o = osl_json_new(OSL_J_OBJ);
    osl_json_obj_set(o, "runs", osl_json_num(e->runs));
    osl_json_obj_set(o, "last", osl_json_num((double)e->last));
    osl_json_obj_set(o, "fav", osl_json_bool(e->fav));
    osl_json_obj_set(stats_obj(m), k, o);
}

void model_rebuild(Model *m) {
    for (size_t i = 0; i < m->apps.n; i++) entry_free(&m->apps.d[i]);
    m->apps.n = 0;
    for (size_t i = 0; i < m->warns.n; i++) free(m->warns.d[i]);
    m->warns.n = 0;
    OslJson *st = stats_obj(m);
    for (size_t i = 0; m->doc && i < m->doc->n; i++) {
        AppEntry e;
        entry_from_json(&e, m->doc->v[i]);
        model_check(&e);
        if (e.valid) {
            safe_ptr(char) k = entry_key(&e);
            OslJson *s = osl_json_obj_get(st, k);
            if (s) { e.runs = (int)osl_json_num_or(s, "runs", 0); e.last = (long)osl_json_num_or(s, "last", 0); e.fav = osl_json_bool_or(s, "fav", false); }
        }
        if (e.warn[0] && (e.enabled || !e.isobj)) {
            char *w = safe_asprintf("Entrada %zu «%s»: %s", i + 1, e.name[0] ? e.name : "sin nombre", e.warn);
            safe_vec_push(m->warns, w);
        }
        safe_vec_push(m->apps, e);
    }
}

void model_set_fav(Model *m, int idx, bool fav) {
    if (idx < 0 || (size_t)idx >= m->apps.n) return;
    m->apps.d[idx].fav = fav;
    stat_write(m, &m->apps.d[idx]);
    model_save_cfg(m);
}

bool model_launch(Model *m, int idx, char *err, size_t ec) {
    if (idx < 0 || (size_t)idx >= m->apps.n) { snprintf(err, ec, "índice inválido"); return false; }
    AppEntry *e = &m->apps.d[idx];
    char **argv;
    if (!model_argv(e, &argv, err, ec, true)) return false;
    bool ok = osl_proc_launch(argv, err, ec);
    osl_argv_free(argv);
    if (ok) { e->runs++; e->last = (long)time(NULL); stat_write(m, e); model_save_cfg(m); }
    return ok;
}

/* ----------------------------------------------------------- ajustes y ficheros */
static void settings_defaults(Settings *s) {
    memset(s, 0, sizeof *s);
    s->theme = 2; s->font_px = 15; s->card_size = 1; s->show_desc = true; s->show_icons = true;
}
bool model_save_cfg(Model *m) {
    Settings *s = &m->set;
    OslJson *o = osl_json_new(OSL_J_OBJ);
    osl_json_obj_set(o, "theme", osl_json_num(s->theme));
    osl_json_obj_set(o, "font_px", osl_json_num(s->font_px));
    osl_json_obj_set(o, "card_size", osl_json_num(s->card_size));
    osl_json_obj_set(o, "sort", osl_json_num(s->sort));
    osl_json_obj_set(o, "after_launch", osl_json_num(s->after_launch));
    osl_json_obj_set(o, "show_desc", osl_json_bool(s->show_desc));
    osl_json_obj_set(o, "show_icons", osl_json_bool(s->show_icons));
    osl_json_obj_set(o, "confirm_launch", osl_json_bool(s->confirm_launch));
    osl_json_obj_set(o, "apps_file", osl_json_str(s->apps_file));
    osl_json_obj_set(m->cfg, "settings", o);
    safe_ptr(char) txt = osl_json_dump(m->cfg, 2);
    char err[200];
    return osl_fs_write_atomic(m->cfg_path, txt, strlen(txt), false, err, sizeof err);
}
static int clampi(double v, int lo, int hi) { int i = (int)v; return i < lo ? lo : i > hi ? hi : i; }

bool model_load_apps(Model *m, const char *path, char *err, size_t ec) {
    safe_ptr(char) p = osl_fs_expand(path);
    char *txt = osl_fs_read_all(p, 8u << 20, NULL, err, ec);
    if (!txt) return false;
    OslJson *j = osl_json_parse(txt, err, ec);
    free(txt);
    if (!j) return false;
    if (j->t != OSL_J_ARR) { osl_json_free(j); snprintf(err, ec, "El archivo debe contener una lista de objetos [ {...}, {...} ]"); return false; }
    osl_json_free(m->doc);
    m->doc = j;
    safe_strlcpy(m->apps_path, p, sizeof m->apps_path);
    m->dirty = false;
    model_rebuild(m);
    return true;
}
bool model_save_apps(Model *m, char *err, size_t ec) {
    safe_ptr(char) txt = osl_json_dump(m->doc, 4);
    safe_ptr(char) full = safe_asprintf("%s\n", txt);
    if (!osl_fs_write_atomic(m->apps_path, full, strlen(full), true, err, ec)) return false;
    m->dirty = false;
    return true;
}

void model_init(Model *m, const char *cli) {
    memset(m, 0, sizeof *m);
    settings_defaults(&m->set);
    char *cd = osl_fs_config_dir("osiris-launcher");
    safe_strlcpy(m->cfg_dir, cd, sizeof m->cfg_dir);
    snprintf(m->cfg_path, sizeof m->cfg_path, "%s/config.json", cd);
    free(cd);
    char err[300] = "";
    char *txt = osl_fs_exists(m->cfg_path) ? osl_fs_read_all(m->cfg_path, 4u << 20, NULL, err, sizeof err) : NULL;
    if (txt) {
        m->cfg = osl_json_parse(txt, err, sizeof err);
        free(txt);
        if (!m->cfg) snprintf(m->init_msg, sizeof m->init_msg, "config.json ilegible (se usan valores por defecto): %.200s", err);
    }
    if (!m->cfg || m->cfg->t != OSL_J_OBJ) { osl_json_free(m->cfg); m->cfg = osl_json_new(OSL_J_OBJ); }
    OslJson *s = osl_json_obj_get(m->cfg, "settings");
    Settings *st = &m->set;
    if (s) {
        st->theme = clampi(osl_json_num_or(s, "theme", st->theme), 0, osl_ui_theme_count() - 1);
        st->font_px = clampi(osl_json_num_or(s, "font_px", st->font_px), 11, 24);
        st->card_size = clampi(osl_json_num_or(s, "card_size", st->card_size), 0, 2);
        st->sort = clampi(osl_json_num_or(s, "sort", st->sort), 0, 3);
        st->after_launch = clampi(osl_json_num_or(s, "after_launch", st->after_launch), 0, 2);
        st->show_desc = osl_json_bool_or(s, "show_desc", st->show_desc);
        st->show_icons = osl_json_bool_or(s, "show_icons", st->show_icons);
        st->confirm_launch = osl_json_bool_or(s, "confirm_launch", st->confirm_launch);
        safe_strlcpy(st->apps_file, osl_json_str_or(s, "apps_file", ""), sizeof st->apps_file);
    }
    /* resolución del fichero de aplicaciones */
    char *exe = osl_fs_exe_dir();
    char cand[4][512] = {"", "", "", ""};
    if (cli && *cli) safe_strlcpy(cand[0], cli, 512);
    if (st->apps_file[0]) safe_strlcpy(cand[1], st->apps_file, 512);
    snprintf(cand[2], 512, "./aplicaciones.json");
    snprintf(cand[3], 512, "%s/aplicaciones.json", exe);
    free(exe);
    const char *chosen = NULL;
    for (int i = 0; i < 4 && !chosen; i++) {
        safe_ptr(char) e = cand[i][0] ? osl_fs_expand(cand[i]) : NULL;
        if (e && osl_fs_exists(e)) chosen = cand[i];
        else if (i == 0 && cli && *cli) { chosen = cand[0]; break; }      /* ruta explícita inexistente: avisar */
    }
    char path[512];
    if (chosen) safe_strlcpy(path, chosen, sizeof path);
    else {
        snprintf(path, sizeof path, "%.480s/aplicaciones.json", m->cfg_dir);
        if (!osl_fs_exists(path)) {
            osl_fs_write_atomic(path, DEFAULT_APPS, strlen(DEFAULT_APPS), false, err, sizeof err);
            snprintf(m->init_msg, sizeof m->init_msg, "No había lista de aplicaciones: se creó una de ejemplo en %.200s", path);
        }
    }
    if (!model_load_apps(m, path, err, sizeof err)) {
        snprintf(m->init_msg, sizeof m->init_msg, "No se pudo cargar '%.120s': %.140s", path, err);
        m->doc = osl_json_new(OSL_J_ARR);
        safe_strlcpy(m->apps_path, path, sizeof m->apps_path);
        model_rebuild(m);
    }
}
void model_free(Model *m) {
    for (size_t i = 0; i < m->apps.n; i++) entry_free(&m->apps.d[i]);
    safe_vec_free(m->apps);
    for (size_t i = 0; i < m->warns.n; i++) free(m->warns.d[i]);
    safe_vec_free(m->warns);
    osl_json_free(m->doc); osl_json_free(m->cfg);
}
