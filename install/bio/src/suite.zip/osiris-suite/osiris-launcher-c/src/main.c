/* main.c - Osiris Launcher (C + SDL2 + share-lib-sdl-c): vistas, menús y diálogos. */
#define _GNU_SOURCE
#include <strings.h>
#include <time.h>
#include "model.h"

enum { V_GRID, V_EDIT, V_SET };
enum { A_NONE, A_LAUNCH, A_INFO, A_FAV, A_EDIT, A_COPY, A_FOLDER };

typedef struct {
    char name[256], alias[512], path[512], args[512], cwd[512], icon[512], category[128], desc[1024];
    bool enabled, terminal, shell;
} EdBuf;
typedef struct { char *buf; size_t cap; } Browse;

typedef struct {
    OslApp *app;
    Model m;
    int view;
    char search[256], search_prev[256];
    SAFE_VEC(int) order;
    SAFE_VEC(char *) cats;
    int cat_sel, sel, scroll, ctx_idx, ctx_x, ctx_y, menu_file, menu_help, menu_ctx;
    bool want_visible, first;
    int ed_sel, ed_scroll; EdBuf ed; bool ed_loaded;
    Browse browse; int pending_idx;
    char set_apps[512];
    int set_scroll;
} L;
static L g;

static const char *SIZE_NAMES[] = {"Compacta", "Normal", "Grande"};
static const char *SORT_NAMES[] = {"Orden del JSON", "Nombre (A-Z)", "Más usadas", "Recientes"};
static const char *AFTER_NAMES[] = {"Mantener abierto", "Minimizar", "Cerrar el lanzador"};

/* ------------------------------------------------------------------- vista */
static const AppEntry *G_APPS; static int G_SORT;
static int cmp_apps(const void *a, const void *b) {
    int ia = *(const int *)a, ib = *(const int *)b;
    const AppEntry *x = &G_APPS[ia], *y = &G_APPS[ib];
    if (G_SORT != 0 && x->fav != y->fav) return x->fav ? -1 : 1;
    int r = 0;
    if (G_SORT == 1) r = strcasecmp(x->name, y->name);
    else if (G_SORT == 2) r = y->runs - x->runs;
    else if (G_SORT == 3) r = (y->last > x->last) - (y->last < x->last);
    return r ? r : ia - ib;
}
static int cmp_str(const void *a, const void *b) { return strcasecmp(*(char *const *)a, *(char *const *)b); }

static void view_rebuild(void) {
    Model *m = &g.m;
    for (size_t i = 0; i < g.cats.n; i++) free(g.cats.d[i]);
    g.cats.n = 0;
    for (size_t i = 0; i < m->apps.n; i++) {
        AppEntry *e = &m->apps.d[i];
        if (!e->valid || !e->enabled || !e->category[0]) continue;
        bool have = false;
        for (size_t k = 0; k < g.cats.n; k++) if (!strcasecmp(g.cats.d[k], e->category)) have = true;
        if (!have) { char *c = safe_strdup(e->category); safe_vec_push(g.cats, c); }
    }
    if (g.cats.n) qsort(g.cats.d, g.cats.n, sizeof *g.cats.d, cmp_str);
    if (g.cat_sel >= (int)g.cats.n + 2) g.cat_sel = 0;
    g.order.n = 0;
    for (size_t i = 0; i < m->apps.n; i++) {
        AppEntry *e = &m->apps.d[i];
        if (!e->valid || !e->enabled) continue;
        if (g.cat_sel == 1 && !e->fav) continue;
        if (g.cat_sel >= 2 && strcasecmp(g.cats.d[g.cat_sel - 2], e->category)) continue;
        if (g.search[0] && !strcasestr(e->name, g.search) && !strcasestr(e->alias, g.search) &&
            !strcasestr(e->desc, g.search) && !strcasestr(e->category, g.search)) continue;
        int idx = (int)i;
        safe_vec_push(g.order, idx);
    }
    G_APPS = m->apps.d; G_SORT = m->set.sort;
    if (g.order.n > 1) qsort(g.order.d, g.order.n, sizeof *g.order.d, cmp_apps);
    if (g.sel >= (int)g.order.n) g.sel = (int)g.order.n - 1;
    if (g.sel < 0) g.sel = 0;
}

/* ------------------------------------------------------------ utilidades UI */
static void toast(const char *fmt, ...) __attribute__((format(printf, 1, 2)));
static void toast(const char *fmt, ...) {
    char b[256];
    va_list ap; va_start(ap, fmt); vsnprintf(b, sizeof b, fmt, ap); va_end(ap);
    osl_app_toast(g.app, "%s", b);
}
static void do_launch_now(int idx) {
    char err[300];
    AppEntry *e = &g.m.apps.d[idx];
    if (!model_launch(&g.m, idx, err, sizeof err)) { osl_dlg_message(g.app, "No se pudo lanzar", err); return; }
    toast("Lanzado: %s", e->name);
    view_rebuild();
    if (g.m.set.after_launch == 1) SDL_MinimizeWindow(osl_app_window(g.app));
    else if (g.m.set.after_launch == 2) osl_app_quit(g.app);
}
static void cb_confirm_launch(bool yes, void *u) { (void)u; if (yes && g.pending_idx >= 0 && (size_t)g.pending_idx < g.m.apps.n) do_launch_now(g.pending_idx); }
static void do_launch(int idx) {
    if (g.m.set.confirm_launch) {
        g.pending_idx = idx;
        char t[400];
        snprintf(t, sizeof t, "¿Lanzar «%s»?", g.m.apps.d[idx].name);
        osl_dlg_confirm(g.app, "Confirmar lanzamiento", t, "Lanzar", "Cancelar", cb_confirm_launch, NULL);
    } else do_launch_now(idx);
}
static void show_info(int idx) {
    AppEntry *e = &g.m.apps.d[idx];
    char when[64] = "nunca";
    if (e->last > 0) { time_t t = (time_t)e->last; struct tm tv; localtime_r(&t, &tv); strftime(when, sizeof when, "%Y-%m-%d %H:%M", &tv); }
    safe_ptr(char) t = safe_asprintf("Nombre: %s\nComando: %s\nCarpeta: %s\nArgumentos: %s\nDirectorio de trabajo: %s\nIcono: %s\nCategoría: %s\n"
        "Habilitada: %s   Terminal: %s   Shell: %s\nUsos: %d   Último uso: %s\n\n%s%s%s",
        e->name, e->alias, e->path[0] ? e->path : "—", e->args[0] ? e->args : "—", e->cwd[0] ? e->cwd : "—", e->icon[0] ? e->icon : "—",
        e->category[0] ? e->category : "—", e->enabled ? "sí" : "no", e->terminal ? "sí" : "no", e->shell ? "sí" : "no", e->runs, when,
        e->desc[0] ? e->desc : "Sin descripción.", e->warn[0] ? "\n\nAviso: " : "", e->warn);
    safe_ptr(char) title = safe_asprintf("Información de %s", e->name);
    osl_dlg_message(g.app, title, t);
}
static void copy_command(int idx) {
    char **argv, err[200];
    if (!model_argv(&g.m.apps.d[idx], &argv, err, sizeof err, false)) { toast("%s", err); return; }
    SBuf b = {0};
    for (size_t i = 0; argv[i]; i++) { if (i) sb_push(&b, ' '); sb_str(&b, argv[i]); }
    SDL_SetClipboardText(b.d ? b.d : "");
    sb_free(&b); osl_argv_free(argv);
    toast("Comando copiado al portapapeles");
}
static void open_folder(int idx) {
    char **argv, err[200], full[1024];
    if (!model_argv(&g.m.apps.d[idx], &argv, err, sizeof err, false)) { toast("%s", err); return; }
    const char *c = argv[0];
    if (!strchr(c, '/') && osl_fs_which(c, full, sizeof full)) c = full;
    safe_ptr(char) dir = osl_fs_dirname(c);
    if (!osl_proc_open(dir, err, sizeof err)) toast("%s", err);
    osl_argv_free(argv);
}
static void load_apps_path(const char *p) {
    char err[300];
    if (!model_load_apps(&g.m, p, err, sizeof err)) { osl_dlg_message(g.app, "No se pudo cargar el JSON", err); return; }
    safe_strlcpy(g.m.set.apps_file, g.m.apps_path, sizeof g.m.set.apps_file);
    safe_strlcpy(g.set_apps, g.m.apps_path, sizeof g.set_apps);
    model_save_cfg(&g.m);
    g.ed_loaded = false; g.ed_sel = 0; g.sel = 0; g.scroll = 0;
    view_rebuild();
    toast("Cargado: %s (%zu entradas)", osl_fs_basename(g.m.apps_path), g.m.apps.n);
}
static void cb_load_json(bool ok, const char *p, void *u) { (void)u; if (ok) load_apps_path(p); }
static void cb_browse(bool ok, const char *p, void *u) { (void)u; if (ok && g.browse.buf) safe_strlcpy(g.browse.buf, p, g.browse.cap); }
static void browse(const char *title, OslPathMode mode, char *buf, size_t cap, const char *ext) {
    g.browse = (Browse){buf, cap};
    osl_dlg_path(g.app, title, mode, buf[0] ? buf : osl_fs_home(), ext, cb_browse, NULL);
}
static void reload_now(void) {
    char err[300];
    if (!model_load_apps(&g.m, g.m.apps_path, err, sizeof err)) { osl_dlg_message(g.app, "No se pudo recargar", err); return; }
    g.ed_loaded = false; view_rebuild(); toast("Lista recargada");
}
static void cb_confirm_reload(bool y, void *u) { (void)u; if (y) reload_now(); }
static void ask_reload(void) {
    if (g.m.dirty) osl_dlg_confirm(g.app, "Recargar", "Hay cambios sin guardar en el editor. ¿Descartarlos y recargar desde el disco?", "Descartar y recargar", "Cancelar", cb_confirm_reload, NULL);
    else reload_now();
}

static const char *HELP_TEXT =
    "Osiris Launcher lanza tus programas desde una lista que tú controlas.\n\n"
    "• Buscar: escribe en la barra (nombre, comando, descripción o categoría). Enter lanza el resaltado.\n"
    "• Lanzar: botón «Lanzar», doble clic sobre la tarjeta o Enter. Clic derecho abre el menú de la tarjeta.\n"
    "• Favoritas: la estrella fija una aplicación arriba. Las categorías aparecen como filtros bajo la búsqueda.\n"
    "• Editor: pestaña «Editor» para añadir, duplicar, ordenar o borrar entradas sin tocar el JSON a mano. "
    "Los campos desconocidos de tu JSON se conservan y al guardar se crea un respaldo .bak.\n"
    "• Cargar otro JSON: menú Archivo. También puedes abrir el JSON en tu editor de texto desde ahí.\n"
    "• Ajustes: tema, tamaño de letra y de tarjetas, orden, y qué hacer tras lanzar.\n\n"
    "Campos de cada entrada del JSON:\n"
    "  name, alias (comando), path (carpeta del programa), args, cwd (directorio de trabajo), icon, category, "
    "description, enabled (por defecto true), terminal (ejecutar en terminal), shell (usar /bin/sh -c).";
static const char *KEYS_TEXT =
    "Ctrl+F       Ir a la búsqueda\nEsc          Borrar la búsqueda\nEnter        Lanzar la aplicación resaltada\n"
    "Flechas      Moverse por las tarjetas\nRe Pág / Av Pág   Desplazar la lista\nF5           Recargar el JSON\n"
    "Doble clic   Lanzar\nClic derecho  Menú de la tarjeta";
static const char *ABOUT_TEXT =
    "Osiris Launcher " LAUNCHER_VERSION " (C + SDL2)\n\nReescritura del lanzador Python/PyQt5 (o3launcher 2.0) sobre share-lib-sdl-c: "
    "memoria segura, sin shell por defecto, sin procesos zombi y con editor integrado.\n\nCompatible con tu aplicaciones.json existente.";

/* ------------------------------------------------------------------ tarjetas */
static const int CW[3] = {232, 276, 336}, DL[3] = {0, 1, 2};

static void ensure_tex(OslUi *u, AppEntry *e) {
    if (e->tex_tried) return;
    e->tex_tried = true;
    if (!e->icon[0]) return;
    safe_ptr(char) p = osl_fs_expand(e->icon);
    e->tex = osl_texture_load(u, p, &e->tw, &e->th);
}

static int draw_card(OslUi *u, SDL_Rect r, AppEntry *e, bool selected, int size) {
    int action = A_NONE, pad = 10, icon = size == 0 ? 34 : 40, bh = u->lh + 8;
    bool hov = osl_hover(u, r);
    osl_rect(u, r, (hov || selected) ? u->th.cardhov : u->th.card);
    osl_border(u, r, selected ? u->th.accent : u->th.border);
    SDL_Rect ib = {r.x + pad, r.y + pad, icon, icon};
    ensure_tex(u, e);
    if (g.m.set.show_icons && e->tex) osl_texture_draw_fit(u, e->tex, e->tw, e->th, ib);
    else {
        osl_rect(u, ib, osl_color_from_str(e->name, &u->th));
        char ini[8] = {0};
        unsigned char c = (unsigned char)e->name[0];
        if (c < 0x80) ini[0] = (char)((c >= 'a' && c <= 'z') ? c - 32 : c);
        else { int n = (c >= 0xF0) ? 4 : (c >= 0xE0) ? 3 : 2; memcpy(ini, e->name, (size_t)n); }
        osl_text(u, ib.x + (ib.w - osl_text_w(u, ini, true)) / 2, ib.y + (ib.h - u->lh) / 2, ini, (SDL_Color){255, 255, 255, 255}, true);
    }
    int tx = ib.x + icon + 8, tw = r.x + r.w - pad - tx;
    osl_text_fit(u, (SDL_Rect){tx, r.y + pad - 1, tw - (e->warn[0] ? 18 : 0), u->lh}, e->name, u->th.accent, true);
    osl_text_fit(u, (SDL_Rect){tx, r.y + pad - 1 + u->lh + 1, tw, u->lh}, e->category[0] ? e->category : e->alias, u->th.dim, false);
    if (e->warn[0]) {
        SDL_Rect wr = {r.x + r.w - pad - 14, r.y + pad - 1, 14, u->lh};
        osl_text(u, wr.x + 3, wr.y, "!", u->th.warn, true);
        osl_tip(u, wr, e->warn);
    }
    int dl = g.m.set.show_desc ? DL[size] : 0, y = ib.y + icon + 6;
    if (dl && e->desc[0]) {
        if (dl == 1) osl_text_fit(u, (SDL_Rect){r.x + pad - 4, y, r.w - 2 * pad + 8, u->lh}, e->desc, u->th.dim, false);
        else osl_text_wrap(u, (SDL_Rect){r.x + pad - 4, y, r.w - 2 * pad + 8, 0}, e->desc, u->th.dim, dl, true);
    }
    int by = r.y + r.h - pad - bh, sw = 34, iw = 62;
    SDL_Rect bl = {r.x + pad, by, r.w - 2 * pad - sw - iw - 12, bh}, bi = {bl.x + bl.w + 6, by, iw, bh}, bs = {bi.x + iw + 6, by, sw, bh};
    if (osl_button(u, bl, "Lanzar", OSL_PRIMARY)) action = A_LAUNCH;
    if (osl_button(u, bi, "Info", 0)) action = A_INFO;
    if (osl_button(u, bs, e->fav ? "\xE2\x98\x85" : "\xE2\x98\x86", e->fav ? OSL_ACTIVE : 0)) action = A_FAV;
    osl_tip(u, bs, e->fav ? "Quitar de favoritas" : "Añadir a favoritas");
    if (!action && hov && !u->active) {
        osl_tip(u, (SDL_Rect){ib.x, ib.y, r.w - 2 * pad, icon}, e->desc[0] ? e->desc : e->alias);
    }
    return action;
}

static void do_action(int act, int idx) {
    Model *m = &g.m;
    if (idx < 0 || (size_t)idx >= m->apps.n) return;
    switch (act) {
        case A_LAUNCH: do_launch(idx); break;
        case A_INFO: show_info(idx); break;
        case A_FAV: model_set_fav(m, idx, !m->apps.d[idx].fav); view_rebuild(); break;
        case A_EDIT: g.view = V_EDIT; g.ed_sel = idx; g.ed_loaded = false; break;
        case A_COPY: copy_command(idx); break;
        case A_FOLDER: open_folder(idx); break;
    }
}
/* Menú contextual: se dibuja DESPUÉS de desbloquear la entrada (ver frame()). */
static void ctx_menu(OslUi *u) {
    static const char *CTX[] = {"Lanzar", "Información", "Marcar / quitar favorita", "Editar…", "Copiar comando", "Abrir carpeta del programa"};
    static const int ACT[] = {A_LAUNCH, A_INFO, A_FAV, A_EDIT, A_COPY, A_FOLDER};
    if (!g.menu_ctx) return;
    int r = osl_menu(u, g.ctx_x, g.ctx_y, CTX, 6, &g.menu_ctx);
    if (r >= 0) do_action(ACT[r], g.ctx_idx);
}

static void draw_grid(OslUi *u, int W, int H, int y0) {
    int fh = u->lh + 10, x = 12, y = y0;
    Model *m = &g.m;
    bool nav_lr = !g.search[0] || u->focus != (uint32_t)(uintptr_t)g.search;
    /* teclado global de la vista */
    if (osl_key(u, SDLK_f) && (u->in.mod & (KMOD_CTRL | KMOD_GUI))) osl_focus(u, g.search);
    if (u->in.k_esc && g.search[0]) { g.search[0] = 0; osl_focus(u, g.search); }
    /* fila 1: búsqueda + orden + avisos */
    int wsort = 200, wbadge = m->warns.n ? 96 : 0;
    SDL_Rect sr = {x, y, W - 2 * x - wsort - 8 - (wbadge ? wbadge + 8 : 0), fh};
    if (!u->focus && u->in.textin[0]) osl_focus(u, g.search);      /* escribir en cualquier sitio busca */
    osl_input(u, sr, g.search, sizeof g.search, "Buscar por nombre, comando, descripción o categoría…");
    if (g.first) { osl_focus(u, g.search); g.first = false; }
    int so = m->set.sort;
    if (osl_cycle(u, (SDL_Rect){sr.x + sr.w + 8, y, wsort, fh}, SORT_NAMES, 4, &so)) { m->set.sort = so; model_save_cfg(m); view_rebuild(); }
    if (wbadge) {
        char b[32]; snprintf(b, sizeof b, "\xE2\x9A\xA0 %zu", m->warns.n);
        SDL_Rect br = {W - x - wbadge, y, wbadge, fh};
        if (osl_button(u, br, b, 0)) {
            SBuf t = {0};
            for (size_t i = 0; i < m->warns.n; i++) { sb_str(&t, "• "); sb_str(&t, m->warns.d[i]); sb_push(&t, '\n'); }
            osl_dlg_message(g.app, "Avisos de la lista de aplicaciones", t.d);
            sb_free(&t);
        }
        osl_tip(u, br, "Entradas con problemas (comando inexistente, falta nombre…)");
    }
    if (strcmp(g.search, g.search_prev)) { safe_strlcpy(g.search_prev, g.search, sizeof g.search_prev); g.sel = 0; g.scroll = 0; view_rebuild(); }
    y += fh + 8;
    /* fila 2: chips de categoría */
    {
        int cx = x, cs = g.cat_sel;
        const char *fixed[2] = {"Todas", "\xE2\x98\x85 Favoritas"};
        for (int i = 0; i < 2 + (int)g.cats.n; i++) {
            const char *lbl = i < 2 ? fixed[i] : g.cats.d[i - 2];
            int w = osl_text_w(u, lbl, false) + 24;
            if (cx + w > W - x) break;
            if (osl_button(u, (SDL_Rect){cx, y, w, fh - 4}, lbl, cs == i ? OSL_ACTIVE : 0)) { g.cat_sel = i; g.sel = 0; g.scroll = 0; view_rebuild(); }
            cx += w + 6;
        }
        y += fh + 4;
    }
    int size = m->set.card_size, gap = 10, cw = CW[size], icon = size == 0 ? 34 : 40, dl = m->set.show_desc ? DL[size] : 0;
    int ch = 10 + icon + (dl ? 6 + dl * u->lh : 0) + 10 + (u->lh + 8) + 10;
    SDL_Rect view = {x, y, W - 2 * x, H - y - 30};
    int cols = (view.w - 12 + gap) / (cw + gap);
    if (cols < 1) cols = 1;
    int n = (int)g.order.n, rows = (n + cols - 1) / cols, content = rows * (ch + gap) + gap;
    /* navegación por teclado */
    int old = g.sel;
    if (n) {
        if (u->in.k_down) g.sel += cols;
        if (u->in.k_up) g.sel -= cols;
        if (nav_lr && u->in.k_right) g.sel += 1;
        if (nav_lr && u->in.k_left) g.sel -= 1;
        if (g.sel < 0) g.sel = 0;
        if (g.sel > n - 1) g.sel = n - 1;
        if (g.sel != old) g.want_visible = true;
        if (u->in.k_pgdn) g.scroll += view.h;
        if (u->in.k_pgup) g.scroll -= view.h;
    }
    if (g.want_visible && n) {
        int top = gap + (g.sel / cols) * (ch + gap);
        if (top < g.scroll) g.scroll = top - gap;
        if (top + ch > g.scroll + view.h) g.scroll = top + ch - view.h + gap;
        g.want_visible = false;
    }
    osl_scroll_update(u, view, content, &g.scroll);
    int act = A_NONE, act_idx = -1;
    int total = cols * cw + (cols - 1) * gap, x0 = view.x + (view.w - 12 - total) / 2;
    osl_rect(u, view, u->th.bg);
    if (!n) {
        const char *msg = m->apps.n == 0 ? "La lista está vacía. Usa la pestaña «Editor» para añadir aplicaciones." :
                          "Ninguna aplicación coincide con el filtro actual.";
        osl_text(u, view.x + 12, view.y + 12, msg, u->th.dim, false);
    }
    SDL_Rect sv; bool had;
    osl_clip_push(u, view, &sv, &had);
    for (int i = 0; i < n; i++) {
        int row = i / cols, col = i % cols;
        SDL_Rect r = {x0 + col * (cw + gap), view.y + gap + row * (ch + gap) - g.scroll, cw, ch};
        if (r.y + ch < view.y || r.y > view.y + view.h) continue;
        int idx = g.order.d[i];
        AppEntry *e = &m->apps.d[idx];
        bool hov = osl_hover(u, r);
        int a = draw_card(u, r, e, i == g.sel, size);
        if (!a && hov && u->in.pressed && !u->active) { g.sel = i; if (u->in.clicks >= 2) a = A_LAUNCH; }
        if (hov && u->in.rpressed) { g.sel = i; g.ctx_idx = idx; g.ctx_x = u->in.mx; g.ctx_y = u->in.my; g.menu_ctx = 1; }
        if (a) { act = a; act_idx = idx; g.sel = i; }
    }
    osl_clip_pop(u, sv, had);
    osl_scroll_draw(u, view, content, g.scroll);
    if (!act && u->in.k_enter && n) { act = A_LAUNCH; act_idx = g.order.d[g.sel]; }
    do_action(act, act_idx);
}

/* ------------------------------------------------------------------- editor */
static EdBuf ed_prev;
static void ed_load(int idx) {
    memset(&g.ed, 0, sizeof g.ed);
    g.ed.enabled = true;
    if (g.m.doc && idx >= 0 && (size_t)idx < g.m.doc->n && g.m.doc->v[idx]->t == OSL_J_OBJ) {
        AppEntry *e = &g.m.apps.d[idx];
        safe_strlcpy(g.ed.name, e->name, sizeof g.ed.name); safe_strlcpy(g.ed.alias, e->alias, sizeof g.ed.alias);
        safe_strlcpy(g.ed.path, e->path, sizeof g.ed.path); safe_strlcpy(g.ed.args, e->args, sizeof g.ed.args);
        safe_strlcpy(g.ed.cwd, e->cwd, sizeof g.ed.cwd); safe_strlcpy(g.ed.icon, e->icon, sizeof g.ed.icon);
        safe_strlcpy(g.ed.category, e->category, sizeof g.ed.category); safe_strlcpy(g.ed.desc, e->desc, sizeof g.ed.desc);
        g.ed.enabled = e->enabled; g.ed.terminal = e->terminal; g.ed.shell = e->shell;
    }
    g.ed_loaded = true;
    ed_prev = g.ed;
}
static bool ed_changed(void) {
    EdBuf *a = &g.ed, *b = &ed_prev;
    return strcmp(a->name, b->name) || strcmp(a->alias, b->alias) || strcmp(a->path, b->path) || strcmp(a->args, b->args) ||
           strcmp(a->cwd, b->cwd) || strcmp(a->icon, b->icon) || strcmp(a->category, b->category) || strcmp(a->desc, b->desc) ||
           a->enabled != b->enabled || a->terminal != b->terminal || a->shell != b->shell;
}
static void setstr(OslJson *o, const char *k, const char *v) { if (v[0] || osl_json_obj_get(o, k)) osl_json_obj_set(o, k, osl_json_str(v)); }
static void setbool(OslJson *o, const char *k, bool v, bool def) { if (v != def || osl_json_obj_get(o, k)) osl_json_obj_set(o, k, osl_json_bool(v)); }
/* vuelca los buffers al JSON (si cambió algo) */
static void ed_apply(void) {
    Model *m = &g.m;
    if (!g.ed_loaded || !m->doc || g.ed_sel < 0 || (size_t)g.ed_sel >= m->doc->n || !ed_changed()) return;
    OslJson *o = m->doc->v[g.ed_sel];
    if (o->t != OSL_J_OBJ) { osl_json_free(o); o = osl_json_new(OSL_J_OBJ); m->doc->v[g.ed_sel] = o; }
    EdBuf *b = &g.ed;
    setstr(o, "name", b->name); setstr(o, "alias", b->alias);
    if (b->alias[0]) osl_json_obj_del(o, "command");
    setstr(o, "path", b->path); setstr(o, "args", b->args); setstr(o, "cwd", b->cwd); setstr(o, "icon", b->icon);
    setstr(o, "category", b->category); setstr(o, "description", b->desc);
    setbool(o, "enabled", b->enabled, true); setbool(o, "terminal", b->terminal, false); setbool(o, "shell", b->shell, false);
    m->dirty = true;
    ed_prev = g.ed;
    model_rebuild(m);
    view_rebuild();
}
static void ed_select(int idx) { ed_apply(); g.ed_sel = idx; ed_load(idx); }

static void cb_del(bool yes, void *u) {
    (void)u;
    if (!yes || !g.m.doc || (size_t)g.ed_sel >= g.m.doc->n) return;
    osl_json_free(osl_json_arr_take(g.m.doc, (size_t)g.ed_sel));
    g.m.dirty = true;
    if (g.ed_sel >= (int)g.m.doc->n) g.ed_sel = (int)g.m.doc->n - 1;
    model_rebuild(&g.m); view_rebuild();
    ed_load(g.ed_sel);
}
static void save_apps_now(void) {
    char err[300];
    ed_apply();
    if (!model_save_apps(&g.m, err, sizeof err)) { osl_dlg_message(g.app, "No se pudo guardar", err); return; }
    toast("Guardado en %s (copia previa: .bak)", osl_fs_basename(g.m.apps_path));
}

static void draw_edit(OslUi *u, int W, int H, int y0) {
    Model *m = &g.m;
    int fh = u->lh + 10, x = 12, y = y0, lw = 332, rh = u->lh + 8;
    if (!g.ed_loaded) { if (g.ed_sel >= (int)m->apps.n) g.ed_sel = (int)m->apps.n - 1; if (g.ed_sel < 0) g.ed_sel = 0; ed_load(g.ed_sel); }
    int act = 0;
    /* barra de acciones de la lista */
    {
        bool has = m->apps.n > 0;
        int bx = x;
        if (osl_button(u, (SDL_Rect){bx, y, 72, fh}, "Nuevo", OSL_PRIMARY)) act = 1;
        bx += 76;
        if (osl_button(u, (SDL_Rect){bx, y, 92, fh}, "Duplicar", has ? 0 : OSL_DISABLED)) act = 2;
        bx += 96;
        if (osl_button(u, (SDL_Rect){bx, y, 34, fh}, "\xE2\x86\x91", has ? 0 : OSL_DISABLED)) act = 3;
        bx += 38;
        if (osl_button(u, (SDL_Rect){bx, y, 34, fh}, "\xE2\x86\x93", has ? 0 : OSL_DISABLED)) act = 4;
        if (osl_button(u, (SDL_Rect){x + lw - 72, y, 72, fh}, "Borrar", has ? OSL_DANGER : OSL_DISABLED)) act = 5;
    }
    y += fh + 8;
    SDL_Rect lv = {x, y, lw, H - y - 80};
    osl_rect(u, lv, u->th.field);
    int content = (int)m->apps.n * rh;
    osl_scroll_update(u, lv, content, &g.ed_scroll);
    SDL_Rect sv; bool had;
    osl_clip_push(u, lv, &sv, &had);
    int click = -1;
    for (int i = 0; i < (int)m->apps.n; i++) {
        SDL_Rect row = {lv.x, lv.y + i * rh - g.ed_scroll, lv.w - 10, rh};
        if (row.y + rh < lv.y || row.y > lv.y + lv.h) continue;
        AppEntry *e = &m->apps.d[i];
        bool hov = osl_hover(u, row), sel = i == g.ed_sel;
        if (sel) osl_rect(u, row, u->th.accent); else if (hov) osl_rect(u, row, u->th.btnhov);
        SDL_Color c = sel ? u->th.accent_text : (e->enabled ? u->th.text : u->th.dim);
        safe_ptr(char) lbl = safe_asprintf("%s%s", e->warn[0] ? "! " : "", e->name[0] ? e->name : "(sin nombre)");
        osl_text_fit(u, (SDL_Rect){row.x + 2, row.y, row.w - 4, rh}, lbl, e->warn[0] && !sel ? u->th.warn : c, false);
        if (hov && u->in.pressed) click = i;
    }
    osl_clip_pop(u, sv, had);
    osl_scroll_draw(u, lv, content, g.ed_scroll);
    /* formulario */
    int fx = x + lw + 20, fw = W - fx - 12, lab = 190;
    int ry = y0;
    if (m->apps.n) {
        EdBuf *b = &g.ed;
#define ROW(label, buf, extra_w) do { osl_text(u, fx, ry + 5, label, u->th.dim, false); \
        SDL_Rect _r = {fx + lab, ry, fw - lab - (extra_w), fh}; osl_input(u, _r, buf, sizeof buf, NULL); \
        if (extra_w) { rbtn = (SDL_Rect){_r.x + _r.w + 6, ry, (extra_w) - 6, fh}; } ry += fh + 8; } while (0)
        SDL_Rect rbtn;
        ROW("Nombre", b->name, 0);
        ROW("Comando (alias)", b->alias, 100);
        if (osl_button(u, rbtn, "Examinar", 0)) browse("Elegir programa o script", OSL_PATH_OPEN_FILE, b->alias, sizeof b->alias, NULL);
        ROW("Carpeta (path)", b->path, 100);
        if (osl_button(u, rbtn, "Examinar", 0)) browse("Carpeta del programa", OSL_PATH_OPEN_DIR, b->path, sizeof b->path, NULL);
        ROW("Argumentos", b->args, 0);
        ROW("Directorio de trabajo", b->cwd, 100);
        if (osl_button(u, rbtn, "Examinar", 0)) browse("Directorio de trabajo", OSL_PATH_OPEN_DIR, b->cwd, sizeof b->cwd, NULL);
        ROW("Icono", b->icon, 100);
        if (osl_button(u, rbtn, "Examinar", 0)) browse("Elegir icono", OSL_PATH_OPEN_FILE, b->icon, sizeof b->icon, "png;jpg;jpeg;svg;webp;bmp");
        ROW("Categoría", b->category, 0);
        ROW("Descripción", b->desc, 0);
        osl_checkbox(u, fx + lab, ry + 2, "Habilitada (visible en el lanzador)", &b->enabled); ry += 28;
        osl_checkbox(u, fx + lab, ry + 2, "Ejecutar dentro de una terminal", &b->terminal); ry += 28;
        osl_checkbox(u, fx + lab, ry + 2, "Usar shell (/bin/sh -c): permite variables, tuberías…", &b->shell); ry += 32;
        AppEntry t = {0};
        t.name = b->name; t.alias = b->alias; t.path = b->path; t.args = b->args; t.cwd = b->cwd; t.icon = b->icon;
        t.category = b->category; t.desc = b->desc; t.shell = b->shell; t.terminal = b->terminal; t.isobj = true;
        model_check(&t);
        osl_text_fit(u, (SDL_Rect){fx, ry, fw, u->lh}, t.warn[0] ? t.warn : "\xE2\x9C\x93 Entrada válida: el comando existe", t.warn[0] ? u->th.warn : u->th.ok, false);
        if (osl_button(u, (SDL_Rect){fx + lab, ry + u->lh + 10, 120, fh}, "Probar", t.valid ? 0 : OSL_DISABLED)) { ed_apply(); do_launch(g.ed_sel); }
        if (m->doc && g.ed_sel >= 0 && (size_t)g.ed_sel < m->doc->n) {}
    } else osl_text(u, fx, ry + 4, "No hay entradas. Pulsa «Nuevo» para crear la primera.", u->th.dim, false);
    /* barra inferior */
    int by = H - 30 - fh - 6;
    if (osl_button(u, (SDL_Rect){x, by, 170, fh}, "Guardar archivo", OSL_PRIMARY)) act = 6;
    if (osl_button(u, (SDL_Rect){x + 178, by, 150, fh}, "Recargar (F5)", 0)) act = 7;
    if (osl_button(u, (SDL_Rect){x + 336, by, 220, fh}, "Abrir en editor externo", 0)) { char err[200]; if (!osl_proc_open(m->apps_path, err, sizeof err)) toast("%s", err); }
    osl_text_fit(u, (SDL_Rect){x + 570, by, W - x - 570 - 12, fh}, m->dirty ? "\xE2\x97\x8F Cambios sin guardar" : m->apps_path, m->dirty ? u->th.warn : u->th.dim, false);
    /* acciones diferidas */
    if (click >= 0 && click != g.ed_sel) ed_select(click);
    int n = m->doc ? (int)m->doc->n : 0;
    switch (act) {
        case 1: {
            ed_apply();
            OslJson *o = osl_json_new(OSL_J_OBJ);
            osl_json_obj_set(o, "name", osl_json_str("Nueva aplicación")); osl_json_obj_set(o, "alias", osl_json_str(""));
            osl_json_obj_set(o, "enabled", osl_json_bool(true));
            osl_json_arr_push(m->doc, o); m->dirty = true;
            model_rebuild(m); view_rebuild();
            g.ed_sel = (int)m->doc->n - 1; ed_load(g.ed_sel);
            g.ed_scroll = 1 << 20;
            break;
        }
        case 2: if (n) {
            ed_apply();
            OslJson *c = osl_json_clone(m->doc->v[g.ed_sel]);
            if (c->t == OSL_J_OBJ) { safe_ptr(char) nn = safe_asprintf("%s (copia)", osl_json_str_or(c, "name", "")); osl_json_obj_set(c, "name", osl_json_str(nn)); }
            osl_json_arr_insert(m->doc, (size_t)g.ed_sel + 1, c); m->dirty = true;
            model_rebuild(m); view_rebuild(); g.ed_sel++; ed_load(g.ed_sel);
        } break;
        case 3: case 4: if (n) {
            ed_apply();
            int to = g.ed_sel + (act == 3 ? -1 : 1);
            if (to >= 0 && to < n) {
                OslJson *t = osl_json_arr_take(m->doc, (size_t)g.ed_sel);
                osl_json_arr_insert(m->doc, (size_t)to, t);
                g.ed_sel = to; m->dirty = true; model_rebuild(m); view_rebuild(); ed_load(to);
            }
        } break;
        case 5: if (n) {
            safe_ptr(char) t = safe_asprintf("¿Borrar «%s» de la lista? (no se borra el programa, solo la entrada)", g.ed.name[0] ? g.ed.name : "(sin nombre)");
            osl_dlg_confirm(g.app, "Borrar entrada", t, "Borrar", "Cancelar", cb_del, NULL);
        } break;
        case 6: save_apps_now(); break;
        case 7: ask_reload(); break;
    }
    if (n && g.ed_loaded && act == 0) ed_apply();     /* solo actúa si hubo cambios: la vista Aplicaciones siempre está al día */
}

/* ------------------------------------------------------------------- ajustes */
static void draw_settings(OslUi *u, int W, int H, int y0) {
    (void)H;
    Model *m = &g.m;
    Settings *s = &m->set;
    int fh = u->lh + 10, x = 12, y = y0, lab = 260, fw = W - 2 * x - lab;
    bool ch = false;
#define LBL(t) osl_text(u, x, y + 5, t, u->th.dim, false)
    int th = s->theme;
    const char *themes[8]; int nt = osl_ui_theme_count();
    for (int i = 0; i < nt && i < 8; i++) themes[i] = osl_ui_theme_name(i);
    LBL("Tema"); if (osl_cycle(u, (SDL_Rect){x + lab, y, 240, fh}, themes, nt, &th)) { s->theme = th; osl_ui_theme(u, th); ch = true; } y += fh + 10;
    LBL("Tamaño de letra");
    if (osl_button(u, (SDL_Rect){x + lab, y, 34, fh}, "-", 0) && s->font_px > 11) { s->font_px--; osl_ui_set_font_px(u, s->font_px); ch = true; }
    char nb[16]; snprintf(nb, sizeof nb, "%d px", s->font_px);
    osl_text(u, x + lab + 44, y + 5, nb, u->th.text, false);
    if (osl_button(u, (SDL_Rect){x + lab + 110, y, 34, fh}, "+", 0) && s->font_px < 24) { s->font_px++; osl_ui_set_font_px(u, s->font_px); ch = true; }
    y += fh + 10;
    LBL("Tamaño de las tarjetas"); if (osl_cycle(u, (SDL_Rect){x + lab, y, 240, fh}, SIZE_NAMES, 3, &s->card_size)) ch = true; y += fh + 10;
    LBL("Orden de la lista"); if (osl_cycle(u, (SDL_Rect){x + lab, y, 240, fh}, SORT_NAMES, 4, &s->sort)) { ch = true; view_rebuild(); } y += fh + 10;
    LBL("Después de lanzar"); if (osl_cycle(u, (SDL_Rect){x + lab, y, 240, fh}, AFTER_NAMES, 3, &s->after_launch)) ch = true; y += fh + 14;
    ch |= osl_checkbox(u, x + lab, y, "Mostrar descripciones en las tarjetas", &s->show_desc); y += 30;
    ch |= osl_checkbox(u, x + lab, y, "Mostrar iconos", &s->show_icons); y += 30;
    ch |= osl_checkbox(u, x + lab, y, "Pedir confirmación antes de lanzar", &s->confirm_launch); y += 40;
    LBL("Archivo de aplicaciones");
    if (!g.set_apps[0]) safe_strlcpy(g.set_apps, m->apps_path, sizeof g.set_apps);
    bool en = osl_input(u, (SDL_Rect){x + lab, y, fw - 220, fh}, g.set_apps, sizeof g.set_apps, NULL);
    if (osl_button(u, (SDL_Rect){x + lab + fw - 212, y, 100, fh}, "Examinar", 0)) { osl_dlg_path(g.app, "Elegir JSON de aplicaciones", OSL_PATH_OPEN_FILE, g.set_apps, "json", cb_load_json, NULL); }
    if (osl_button(u, (SDL_Rect){x + lab + fw - 106, y, 106, fh}, "Cargar", OSL_PRIMARY) || en) load_apps_path(g.set_apps);
    y += fh + 24;
    osl_text(u, x, y, "Configuración y estadísticas:", u->th.dim, false);
    osl_text_fit(u, (SDL_Rect){x + lab, y - 4, fw, fh}, m->cfg_path, u->th.text, false); y += fh;
    osl_text(u, x, y, "Versión:", u->th.dim, false);
    osl_text(u, x + lab + 4, y, "Osiris Launcher " LAUNCHER_VERSION " · share-lib-sdl-c 0.1", u->th.text, false); y += fh + 10;
    if (osl_button(u, (SDL_Rect){x + lab, y, 320, fh}, "Reiniciar estadísticas y favoritas", OSL_DANGER)) {
        osl_json_obj_del(m->cfg, "stats"); ch = true; model_rebuild(m); view_rebuild(); toast("Estadísticas reiniciadas");
    }
    if (ch) model_save_cfg(m);
}

/* ------------------------------------------------------------------- marco */
static void frame(OslApp *app, void *user) {
    (void)user;
    OslUi *u = osl_app_ui(app);
    int W, H;
    osl_app_size(app, &W, &H);
    int fh = u->lh + 10, y = 8;
    bool menus = g.menu_file || g.menu_help || g.menu_ctx;
    OslInput saved;
    if (menus) saved = osl_ui_block(u);
    /* global */
    if (osl_key(u, SDLK_F5)) { if (g.view == V_EDIT) ask_reload(); else reload_now(); }
    osl_text(u, 12, y + (fh - u->lh) / 2, "Osiris Launcher", u->th.accent, true);
    int tx = 12 + osl_text_w(u, "Osiris Launcher", true) + 24;
    const char *tabs[3] = {"Aplicaciones", "Editor", "Ajustes"};
    for (int i = 0; i < 3; i++) {
        int w = osl_text_w(u, tabs[i], false) + 30;
        if (osl_button(u, (SDL_Rect){tx, y, w, fh}, tabs[i], g.view == i ? OSL_ACTIVE : 0)) { if (g.view == V_EDIT && i != V_EDIT) ed_apply(); g.view = i; if (i == V_EDIT) g.ed_loaded = false; }
        tx += w + 6;
    }
    SDL_Rect bf = {W - 12 - 100 - 6 - 90, y, 100, fh}, bh = {W - 12 - 90, y, 90, fh};
    if (osl_button(u, bf, "Archivo \xE2\x96\xBE", 0)) g.menu_file = 1;
    if (osl_button(u, bh, "Ayuda \xE2\x96\xBE", 0)) g.menu_help = 1;
    int y0 = y + fh + 12;
    switch (g.view) {
        case V_GRID: draw_grid(u, W, H, y0); break;
        case V_EDIT: draw_edit(u, W, H, y0); break;
        default: draw_settings(u, W, H, y0); break;
    }
    /* barra de estado */
    {
        int shown = (int)g.order.n, total = 0;
        for (size_t i = 0; i < g.m.apps.n; i++) if (g.m.apps.d[i].valid && g.m.apps.d[i].enabled) total++;
        char sb[200];
        snprintf(sb, sizeof sb, "%d de %d aplicaciones   ·   %s", shown, total, osl_fs_basename(g.m.apps_path));
        osl_text(u, 12, H - u->lh - 6, sb, u->th.dim, false);
    }
    if (menus) osl_ui_unblock(u, saved);
    ctx_menu(u);
    /* menús desplegables */
    static const char *FILE_M[] = {"Cargar otro JSON…", "Recargar (F5)", "Abrir JSON en editor externo", "Abrir carpeta de configuración", "---", "Salir"};
    static const char *HELP_M[] = {"Ayuda", "Atajos de teclado", "---", "Acerca de Osiris Launcher"};
    if (g.menu_file) {
        int r = osl_menu(u, bf.x, bf.y + fh + 2, FILE_M, 6, &g.menu_file);
        char err[200];
        if (r == 0) { g.browse = (Browse){0, 0}; safe_ptr(char) dn = osl_fs_dirname(g.m.apps_path); osl_dlg_path(app, "Cargar archivo JSON de aplicaciones", OSL_PATH_OPEN_FILE, dn, "json", cb_load_json, NULL); }
        else if (r == 1) ask_reload();
        else if (r == 2) { if (!osl_proc_open(g.m.apps_path, err, sizeof err)) toast("%s", err); }
        else if (r == 3) { if (!osl_proc_open(g.m.cfg_dir, err, sizeof err)) toast("%s", err); }
        else if (r == 5) osl_app_quit(app);
    }
    if (g.menu_help) {
        int r = osl_menu(u, bh.x - 60, bh.y + fh + 2, HELP_M, 4, &g.menu_help);
        if (r == 0) osl_dlg_message(app, "Ayuda de Osiris Launcher", HELP_TEXT);
        else if (r == 1) osl_dlg_message(app, "Atajos de teclado", KEYS_TEXT);
        else if (r == 3) osl_dlg_message(app, "Acerca de", ABOUT_TEXT);
    }
}

static void usage(void) {
    puts("Uso: osiris-launcher [opciones] [aplicaciones.json]\n"
         "  --apps FICHERO     lista de aplicaciones a cargar\n"
         "  --view VISTA       vista inicial: apps | editor | ajustes\n"
         "  -h, --help         esta ayuda\n  -v, --version      versión\n"
         "Variables: OSL_FONT, OSL_FONT_DIR (fuentes), OSL_SHOT=fichero.bmp (captura y salir)");
}

int main(int argc, char **argv) {
    const char *apps = NULL;
    int view = V_GRID;
    for (int i = 1; i < argc; i++) {
        if (!strcmp(argv[i], "-h") || !strcmp(argv[i], "--help")) { usage(); return 0; }
        else if (!strcmp(argv[i], "-v") || !strcmp(argv[i], "--version")) { puts("Osiris Launcher " LAUNCHER_VERSION); return 0; }
        else if (!strcmp(argv[i], "--apps") && i + 1 < argc) apps = argv[++i];
        else if (!strcmp(argv[i], "--view") && i + 1 < argc) { const char *v = argv[++i]; view = !strcmp(v, "editor") ? V_EDIT : !strcmp(v, "ajustes") ? V_SET : V_GRID; }
        else if (argv[i][0] != '-') apps = argv[i];
        else { fprintf(stderr, "Opción desconocida: %s\n", argv[i]); usage(); return 2; }
    }
    model_init(&g.m, apps);
    g.app = osl_app_create(&(OslAppDesc){.title = "Osiris Launcher", .app_id = "osiris-launcher", .w = 1040, .h = 720,
                                         .min_w = 640, .min_h = 420, .font_px = g.m.set.font_px, .theme = g.m.set.theme});
    if (!g.app) { model_free(&g.m); return 1; }
    g.view = view; g.first = true; g.pending_idx = -1;
    view_rebuild();
    if (g.m.init_msg[0]) osl_dlg_message(g.app, "Aviso", g.m.init_msg);
    osl_app_run(g.app, frame, NULL);
    ed_apply();
    model_save_cfg(&g.m);
    osl_app_destroy(g.app);
    for (size_t i = 0; i < g.cats.n; i++) free(g.cats.d[i]);
    safe_vec_free(g.cats); safe_vec_free(g.order);
    model_free(&g.m);
    return 0;
}
