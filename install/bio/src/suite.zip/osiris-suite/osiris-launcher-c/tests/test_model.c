/* Test del modelo: carga, validación, comandos seguros, lanzamiento real, guardado y estadísticas. */
#include "../src/model.h"
#include <unistd.h>
static int fails;
#define CHECK(c) do { if (!(c)) { printf("FALLO línea %d: %s\n", __LINE__, #c); fails++; } } while (0)
static bool wait_file(const char *p) { for (int i = 0; i < 40; i++) { if (osl_fs_exists(p)) return true; usleep(50000); } return false; }
int main(void) {
    setenv("XDG_CONFIG_HOME", "/tmp/lmt/cfg", 1);
    system("rm -rf /tmp/lmt; mkdir -p /tmp/lmt/w");
    const char *json =
        "[{\"name\":\"A\",\"alias\":\"sh\",\"extra\":\"conservar\"},"
        " {\"name\":\"Args\",\"alias\":\"touch\",\"args\":\"\\\"/tmp/lmt/a b.txt\\\"\"},"
        " {\"name\":\"Shell\",\"alias\":\"echo hola > /tmp/lmt/shell.txt\",\"shell\":true},"
        " {\"name\":\"Cwd\",\"alias\":\"touch\",\"args\":\"aqui.txt\",\"cwd\":\"/tmp/lmt/w\"},"
        " {\"name\":\"Path\",\"path\":\"/usr/bin\",\"alias\":\"touch\",\"args\":\"/tmp/lmt/path.txt\"},"
        " {\"name\":\"Off\",\"alias\":\"sh\",\"enabled\":false},"
        " {\"name\":\"Roto\",\"alias\":\"no-existe-zzz\"}, {\"alias\":\"x\"}, 42]";
    system("true");
    FILE *f = fopen("/tmp/lmt/apps.json", "w"); fputs(json, f); fclose(f);
    Model m;
    model_init(&m, "/tmp/lmt/apps.json");
    CHECK(m.init_msg[0] == 0);
    CHECK(m.apps.n == 9);
    CHECK(m.apps.d[0].enabled && m.apps.d[0].valid && !m.apps.d[0].warn[0]);   /* enabled por defecto = true */
    CHECK(!m.apps.d[5].enabled);
    CHECK(m.apps.d[6].warn[0] && m.apps.d[7].warn[0] && m.apps.d[8].warn[0] && !m.apps.d[8].valid);
    CHECK(m.warns.n == 3);
    char err[300];
    CHECK(model_launch(&m, 1, err, sizeof err)); CHECK(wait_file("/tmp/lmt/a b.txt"));      /* comillas / espacios */
    CHECK(model_launch(&m, 2, err, sizeof err)); CHECK(wait_file("/tmp/lmt/shell.txt"));    /* shell opt-in */
    CHECK(model_launch(&m, 3, err, sizeof err)); CHECK(wait_file("/tmp/lmt/w/aqui.txt"));   /* cwd sin shell inyectable */
    CHECK(model_launch(&m, 4, err, sizeof err)); CHECK(wait_file("/tmp/lmt/path.txt"));     /* path + alias */
    CHECK(!model_launch(&m, 6, err, sizeof err) && strstr(err, "PATH"));
    CHECK(m.apps.d[1].runs == 1 && m.apps.d[6].runs == 0);
    /* sin inyección: una URL/args con ; no se interpreta */
    OslJson *o = m.doc->v[3]; osl_json_obj_set(o, "args", osl_json_str("'a; touch PWNED'"));
    model_rebuild(&m); CHECK(model_launch(&m, 3, err, sizeof err)); usleep(300000);
    CHECK(osl_fs_exists("/tmp/lmt/w/a; touch PWNED") && !osl_fs_exists("/tmp/lmt/w/PWNED"));
    /* guardado: conserva campos desconocidos, crea .bak, relee igual */
    model_set_fav(&m, 0, true);
    CHECK(model_save_apps(&m, err, sizeof err) && osl_fs_exists("/tmp/lmt/apps.json.bak"));
    Model m2; model_init(&m2, "/tmp/lmt/apps.json");
    CHECK(m2.apps.n == 9 && !strcmp(osl_json_str_or(m2.doc->v[0], "extra", ""), "conservar"));
    CHECK(m2.apps.d[0].fav && m2.apps.d[1].runs == 1 && m2.apps.d[3].runs == 2);                                       /* estadísticas persistentes */
    /* errores de carga */
    FILE *g = fopen("/tmp/lmt/bad.json", "w"); fputs("[{\"a\":1,}]", g); fclose(g);
    CHECK(!model_load_apps(&m2, "/tmp/lmt/bad.json", err, sizeof err) && strstr(err, "línea 1") && m2.apps.n == 9);   /* no pierde la lista actual */
    g = fopen("/tmp/lmt/obj.json", "w"); fputs("{\"x\":1}", g); fclose(g);
    CHECK(!model_load_apps(&m2, "/tmp/lmt/obj.json", err, sizeof err) && strstr(err, "lista"));
    /* sin lista: crea una de ejemplo */
    Model m3; setenv("XDG_CONFIG_HOME", "/tmp/lmt/cfg3", 1); chdir("/tmp"); model_init(&m3, NULL);
    CHECK(m3.apps.n == 4 && strstr(m3.init_msg, "ejemplo"));
    model_free(&m); model_free(&m2); model_free(&m3);
    printf(fails ? "%d fallos\n" : "OK: modelo del lanzador\n", fails);
    return fails != 0;
}
