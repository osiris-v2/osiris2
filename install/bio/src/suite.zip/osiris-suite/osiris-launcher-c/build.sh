#!/usr/bin/env bash
# Compila el lanzador (usa ../share-lib-sdl-c y ../share-fonts). Funciona desde cualquier directorio.
set -e
cd "$(dirname "$0")"
[ -d ../share-lib-sdl-c ] || { echo "Falta ../share-lib-sdl-c: descomprime el paquete completo." >&2; exit 1; }
if command -v make >/dev/null; then make release
else cmake -S . -B build/cmake -DCMAKE_BUILD_TYPE=Release && cmake --build build/cmake && mkdir -p build && cp build/cmake/bin/osiris-launcher build/; fi
echo; echo "Ejecuta: ./build/osiris-launcher   (o: ./build/osiris-launcher mis-apps.json)"
