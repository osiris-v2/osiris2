/* main.c - Osiris Downloader AI (C puro + SDL2): interfaz y cola de descargas. */
#define _GNU_SOURCE
#include <signal.h>
#include <stdarg.h>
#include "core.h"
#include "ui.h"

enum { TAB_DL, TAB_LOG, TAB_OPT };

typedef struct {
    UI ui;
    Options opt, edit, saved;          /* opt = aplicadas; edit = formulario; saved = lo que hay en disco */
    bool show_envs; int env_scroll;
    int sel_row, log_a, log_b, last_dups; bool log_drag;
    Download **dl;
    int ndl, cap;
    char url_in[4096];
    char cfg[512];
    char toast[160];
    uint32_t toast_until;
    int tab, scroll_dl, scroll_log;
    bool queue_active, autoscroll, found;
} App;

static void toast(App *a, const char *fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(a->toast, sizeof a->toast, fmt, ap);
    va_end(ap);
    a->toast_until = SDL_GetTicks() + 3500;
}

static void added_toast(App *a, int n) {
    if (a->last_dups) toast(a, "%d URL(s) añadida(s), %d repetida(s) ignorada(s)", n, a->last_dups);
    else toast(a, "%d URL(s) añadida(s)", n);
}

/* ------------------------------------------------------------------- cola */
static int add_urls(App *a, const char *text) {
    int added = 0;
    safe_ptr(char) cp = safe_strdup(text);
    char *sv = NULL;
    for (char *t = strtok_r(cp, " \t\r\n", &sv); t; t = strtok_r(NULL, " \t\r\n", &sv)) {
        if (strncmp(t, "http://", 7) && strncmp(t, "https://", 8)) {
            log_push("Ignorado (no es una URL http/https): %s", t);
            continue;
        }
        bool dup = false;
        for (int i = 0; i < a->ndl; i++) if (!strcmp(a->dl[i]->url, t)) { dup = true; break; }
        if (dup) { log_push("Ignorada (ya está en la lista): %s", t); a->last_dups++; continue; }
        if (a->ndl == a->cap) {
            a->cap = a->cap ? a->cap * 2 : 16;
            a->dl = (Download **)safe_realloc(a->dl, a->cap * sizeof *a->dl);
        }
        a->dl[a->ndl++] = dl_new(t);
        added++;
    }
    return added;
}

static DlState dl_state(Download *d) { DlSnap s; dl_snapshot(d, &s); return s.state; }

static void schedule(App *a) {
    if (!a->queue_active) return;
    int running = 0, queued = 0;
    for (int i = 0; i < a->ndl; i++) if (dl_state(a->dl[i]) == DL_RUNNING) running++;
    for (int i = 0; i < a->ndl; i++) {
        if (dl_state(a->dl[i]) != DL_QUEUED) continue;
        if (running < a->opt.max_par) { dl_start(a->dl[i], &a->opt); running++; }
        else queued++;
    }
    if (!running && !queued) { a->queue_active = false; log_push("Cola terminada."); }
}

static void remove_at(App *a, int i) {
    if (a->sel_row == i) a->sel_row = -1; else if (a->sel_row > i) a->sel_row--;
    dl_free(a->dl[i]);
    memmove(&a->dl[i], &a->dl[i + 1], (size_t)(a->ndl - i - 1) * sizeof *a->dl);
    a->ndl--;
}

static void start_queue(App *a) {
    if (!a->found) a->found = ytdlp_detect(&a->opt);
    if (!a->found) { toast(a, "yt-dlp no encontrado: indica su ruta en Opciones"); return; }
    a->queue_active = true;
}

/* -------------------------------------------------------------- pantallas */
static SDL_Color state_color(UI *u, DlState s) {
    switch (s) {
        case DL_DONE: return u->th.ok;
        case DL_ERROR: return u->th.err;
        case DL_CANCELLED: return u->th.dim;
        default: return u->th.accent;
    }
}

static void draw_downloads(App *a, int W, int H, int y0) {
    UI *u = &a->ui;
    int fh = u->lh + 10, x = 12, y = y0, bw = 96;
    SDL_Rect in = {x, y, W - 2 * x - 2 * bw - 16, fh};
    bool enter = ui_input(u, in, a->url_in, sizeof a->url_in);
    SDL_Rect b1 = {in.x + in.w + 8, y, bw, fh}, b2 = {b1.x + bw + 8, y, bw, fh};
    if (ui_button(u, b1, "Añadir", 0) || enter) {
        if (a->url_in[0]) { a->last_dups = 0; int n = add_urls(a, a->url_in); a->url_in[0] = 0; added_toast(a, n); }
    }
    if (ui_button(u, b2, "Pegar", 0)) {
        char *c = SDL_GetClipboardText();
        if (c && *c) { a->last_dups = 0; int n = add_urls(a, c); added_toast(a, n); }
        SDL_free(c);
    }
    y += fh + 8;
    int cx = x;
    if (ui_button(u, (SDL_Rect){cx, y, 110, fh}, "Iniciar", a->queue_active ? UI_ACTIVE : 0)) {
        for (int i = 0; i < a->ndl; i++) if (dl_state(a->dl[i]) == DL_CANCELLED) dl_requeue(a->dl[i]);   /* reanuda las detenidas */
        start_queue(a);
    }
    cx += 118;
    if (ui_button(u, (SDL_Rect){cx, y, 130, fh}, "Detener todas", 0)) {
        a->queue_active = false;
        for (int i = 0; i < a->ndl; i++) if (dl_state(a->dl[i]) <= DL_RUNNING) dl_cancel(a->dl[i]);
        toast(a, "Descargas detenidas");
    }
    cx += 138;
    if (ui_button(u, (SDL_Rect){cx, y, 160, fh}, "Limpiar terminadas", 0)) {      /* solo las COMPLETADAS */
        int n = 0;
        for (int i = a->ndl - 1; i >= 0; i--) if (dl_state(a->dl[i]) == DL_DONE) { remove_at(a, i); n++; }
        toast(a, "%d completada(s) quitada(s)", n);
    }
    cx += 168;
    if (ui_button(u, (SDL_Rect){cx, y, 150, fh}, "Limpiar fallidas", 0)) {         /* errores y canceladas */
        int n = 0;
        for (int i = a->ndl - 1; i >= 0; i--) { DlState st = dl_state(a->dl[i]); if (st == DL_ERROR || st == DL_CANCELLED) { remove_at(a, i); n++; } }
        toast(a, "%d fallida(s)/cancelada(s) quitada(s)", n);
    }
    cx += 158;
    if (ui_button(u, (SDL_Rect){cx, y, 140, fh}, "Abrir carpeta", 0)) open_path(a->opt.outdir);
    y += fh + 8;
    char st[1400];
    char ver[48] = "";
    if (a->found) ytscan_version(a->opt.ytdlp, ver, sizeof ver);
    if (a->found) snprintf(st, sizeof st, "yt-dlp %s: %s   |   salida: %s", ver, a->opt.ytdlp, a->opt.outdir);
    else snprintf(st, sizeof st, "yt-dlp NO encontrado: instálalo o indica la ruta en Opciones");
    ui_text(u, x, y, st, a->found ? u->th.dim : u->th.err);
    y += u->lh + 10;

    /* tabla */
    int cw[7] = {32, 0, 150, 230, 95, 70, 170}, fixed = 0;
    for (int k = 0; k < 7; k++) fixed += cw[k];
    cw[1] = W - 2 * x - fixed;
    if (cw[1] < 120) cw[1] = 120;
    int px[7];
    px[0] = x;
    for (int k = 1; k < 7; k++) px[k] = px[k - 1] + cw[k - 1];
    const char *hd[7] = {"#", "URL  (clic + Ctrl+C: copiar)", "Progreso", "Estado", "Velocidad", "ETA", "Acciones"};
    int rh = u->lh + 14, hh = u->lh + 8;
    ui_rect(u, (SDL_Rect){x, y, W - 2 * x, hh}, u->th.panel);
    for (int k = 0; k < 7; k++) ui_text(u, px[k] + 4, y + 4, hd[k], u->th.dim);
    SDL_Rect reg = {x, y + hh, W - 2 * x, H - (y + hh) - 30};
    ui_rect(u, reg, u->th.field);
    if (ui_hover(u, reg)) a->scroll_dl -= u->wheel * 40;
    int total = a->ndl * rh, maxs = total > reg.h ? total - reg.h : 0;
    if (a->scroll_dl > maxs) a->scroll_dl = maxs;
    if (a->scroll_dl < 0) a->scroll_dl = 0;
    if (!a->ndl) ui_text(u, reg.x + 12, reg.y + 12, "Sin descargas. Pega una o varias URLs arriba y pulsa Añadir.", u->th.dim);

    int rem = -1;
    ui_clip(u, &reg);
    for (int i = 0; i < a->ndl; i++) {
        int ry = reg.y + i * rh - a->scroll_dl;
        if (ry + rh < reg.y || ry > reg.y + reg.h) continue;
        DlSnap s;
        dl_snapshot(a->dl[i], &s);
        SDL_Rect rowr = {reg.x, ry, reg.w, rh};
        if (i == a->sel_row) ui_rect(u, rowr, (SDL_Color){50, 95, 160, 255});
        else if (i & 1) ui_rect(u, rowr, u->th.bg);
        char n[16];
        snprintf(n, sizeof n, "%d", i + 1);
        ui_text(u, px[0] + 4, ry + (rh - u->lh) / 2, n, u->th.dim);
        ui_text_clip(u, (SDL_Rect){px[1], ry, cw[1] - 6, rh}, a->dl[i]->url, u->th.text);
        ui_progress(u, (SDL_Rect){px[2] + 2, ry + 5, cw[2] - 10, rh - 10}, s.pct, state_color(u, s.state));
        ui_text_clip(u, (SDL_Rect){px[3], ry, cw[3] - 6, rh}, s.status, state_color(u, s.state));
        ui_text_clip(u, (SDL_Rect){px[4], ry, cw[4] - 4, rh}, s.speed, u->th.text);
        ui_text_clip(u, (SDL_Rect){px[5], ry, cw[5] - 4, rh}, s.eta, u->th.text);
        SDL_Rect ba = {px[6] + 2, ry + 3, 80, rh - 6}, bq = {px[6] + 88, ry + 3, 76, rh - 6};
        if (s.state == DL_RUNNING) { if (ui_button(u, ba, "Parar", 0)) dl_cancel(a->dl[i]); }
        else if (s.state != DL_QUEUED) { if (ui_button(u, ba, "Reintentar", 0)) { dl_requeue(a->dl[i]); start_queue(a); } }
        if (ui_button(u, bq, "Quitar", 0)) rem = i;
        if (ui_hover(u, rowr)) {
            if (u->pressed && !u->active) a->sel_row = i;
            if (u->rpressed) { SDL_SetClipboardText(a->dl[i]->url); a->sel_row = i; toast(a, "URL copiada"); }
        }
    }
    ui_clip(u, NULL);
    ui_border(u, reg, u->th.border);
    if (u->copy && !u->focus && a->sel_row >= 0 && a->sel_row < a->ndl) { SDL_SetClipboardText(a->dl[a->sel_row]->url); toast(a, "URL copiada"); }
    if (rem >= 0) remove_at(a, rem);
}

static void copy_log(App *a, int lo, int hi) {
    SBuf b = {0};
    int n = log_count(), cnt = 0;
    if (lo < 0) lo = 0;
    if (hi > n - 1) hi = n - 1;
    for (int i = lo; i <= hi; i++) { char ln[512]; if (log_get(i, ln, sizeof ln)) { sb_str(&b, ln); sb_push(&b, '\n'); cnt++; } }
    SDL_SetClipboardText(b.d ? b.d : "");
    sb_free(&b);
    toast(a, "%d línea(s) copiada(s)", cnt);
}

static void draw_log(App *a, int W, int H, int y0) {
    UI *u = &a->ui;
    int fh = u->lh + 10, x = 12, y = y0, n = log_count();
    int lo = a->log_a < a->log_b ? a->log_a : a->log_b, hi = a->log_a < a->log_b ? a->log_b : a->log_a;
    bool has = a->log_a >= 0;
    if (ui_button(u, (SDL_Rect){x, y, 150, fh}, "Limpiar registro", 0)) { log_clear(); a->log_a = a->log_b = -1; }
    if (ui_button(u, (SDL_Rect){x + 160, y, 170, fh}, has ? "Copiar selección" : "Copiar todo", 0)) { if (has) copy_log(a, lo, hi); else copy_log(a, 0, n - 1); }
    ui_checkbox(u, x + 350, y + (fh - 18) / 2, "Scroll automático", &a->autoscroll);
    ui_text(u, x + 540, y + (fh - u->lh) / 2, "Arrastra para seleccionar líneas · Ctrl+C copia", u->th.dim);
    y += fh + 8;
    SDL_Rect reg = {x, y, W - 2 * x, H - y - 30};
    ui_rect(u, reg, u->th.field);
    int lines = reg.h / u->lh;
    if (ui_hover(u, reg) && u->wheel) { a->scroll_log -= u->wheel * 3; if (u->wheel > 0) a->autoscroll = false; }
    int maxs = n > lines ? n - lines : 0;
    if (a->autoscroll) a->scroll_log = maxs;
    if (a->scroll_log > maxs) a->scroll_log = maxs;
    if (a->scroll_log < 0) a->scroll_log = 0;
    int li = a->scroll_log + (u->my - reg.y - 2) / u->lh;
    if (li < 0) li = 0;
    if (li > n - 1) li = n - 1;
    if (u->pressed && ui_hover(u, reg) && n) { a->log_a = a->log_b = li; a->log_drag = true; a->autoscroll = false; u->focus = 0; }
    if (a->log_drag) { if (u->down) a->log_b = li; else a->log_drag = false; }
    if (u->copy && !u->focus && has) copy_log(a, lo, hi);
    ui_clip(u, &reg);
    for (int i = 0; i < lines && a->scroll_log + i < n; i++) {
        int idx = a->scroll_log + i;
        char ln[512];
        if (!log_get(idx, ln, sizeof ln)) break;
        if (has && idx >= lo && idx <= hi) ui_rect(u, (SDL_Rect){reg.x + 1, reg.y + 2 + i * u->lh, reg.w - 2, u->lh}, (SDL_Color){50, 95, 160, 255});
        SDL_Color c = strstr(ln, "ERROR") || strstr(ln, "Falló") || strstr(ln, "No se pudo") ? u->th.err
                    : strstr(ln, "WARNING") ? u->th.warn : strstr(ln, "Completado") ? u->th.ok : u->th.text;
        ui_text(u, reg.x + 6, reg.y + 2 + i * u->lh, ln, c);
    }
    ui_clip(u, NULL);
    ui_border(u, reg, u->th.border);
}

#define LBLW 240
static SDL_Rect orow(App *a, int *y, int W, const char *label, int rw) {
    UI *u = &a->ui;
    int fh = u->lh + 10;
    ui_text(u, 12, *y + 5, label, u->th.dim);
    SDL_Rect r = {12 + LBLW, *y, rw > 0 ? rw : W - 24 - LBLW, fh};
    *y += fh + 8;
    return r;
}

static void apply_opts(App *a) {
    a->opt = a->edit;
    a->found = ytdlp_detect(&a->opt);
    if (a->found) safe_strlcpy(a->edit.ytdlp, a->opt.ytdlp, sizeof a->edit.ytdlp);
    log_push(a->found ? "Opciones aplicadas. yt-dlp: %s" : "Opciones aplicadas, pero yt-dlp no se encuentra (%s)", a->opt.ytdlp);
}
static void save_opts(App *a) {
    apply_opts(a);
    if (options_save(&a->opt, a->cfg)) { a->saved = a->opt; toast(a, "Guardado en %s", a->cfg); }
    else toast(a, "No se pudo guardar %s", a->cfg);
}

/* Panel de entornos / instalaciones de yt-dlp (superpuesto a la pestaña Opciones). */
static void draw_env_panel(App *a, int W, int H, int py) {
    UI *u = &a->ui;
    Options *o = &a->edit;
    int fh = u->lh + 10, x = 12, rh = u->lh + 8;
    YtCand c[64];
    bool scanning = false;
    int n = ytscan_get(c, 64, &scanning);
    SDL_Rect p = {x, py, W - 2 * x, H - py - 44 - (u->lh + 10)};   /* hasta la barra inferior */
    ui_rect(u, p, u->th.panel);
    ui_border(u, p, u->th.accent);
    int y = p.y + 8;
    char hd[96];
    snprintf(hd, sizeof hd, scanning ? "Buscando yt-dlp… (%d encontrados)" : "Instalaciones y entornos de yt-dlp encontrados: %d", n);
    ui_text(u, p.x + 10, y + 5, hd, scanning ? u->th.warn : u->th.accent);
    if (ui_button(u, (SDL_Rect){p.x + p.w - 10 - 90, y, 90, fh}, "Cerrar", 0)) a->show_envs = false;
    if (ui_button(u, (SDL_Rect){p.x + p.w - 10 - 90 - 8 - 150, y, 150, fh}, "Buscar de nuevo", scanning ? UI_DISABLED : 0)) ytscan_start(o);
    y += fh + 8;
    ui_text(u, p.x + 10, y + 5, "Carpetas extra (separadas por :)", u->th.dim);
    int lw = ui_text_w(u, "Carpetas extra (separadas por :)") + 20;
    ui_input(u, (SDL_Rect){p.x + 10 + lw, y, p.w - 20 - lw, fh}, o->extra_dirs, sizeof o->extra_dirs);
    y += fh + 6;
    ui_text(u, p.x + 10, y, "Se buscan entornos (carpetas con bin/yt-dlp) hasta 6 niveles dentro de ellas. Pulsa «Buscar de nuevo» tras cambiarlas.", u->th.dim);
    y += u->lh + 8;
    SDL_Rect lv = {p.x + 10, y, p.w - 20, p.y + p.h - y - 10};
    ui_rect(u, lv, u->th.field);
    int total = n * rh, maxs = total > lv.h ? total - lv.h : 0;
    if (ui_hover(u, lv)) a->env_scroll -= u->wheel * 30;
    if (a->env_scroll > maxs) a->env_scroll = maxs;
    if (a->env_scroll < 0) a->env_scroll = 0;
    ui_clip(u, &lv);
    if (!n) ui_text(u, lv.x + 8, lv.y + 6, scanning ? "Buscando…" : "No se encontró ninguno. Instálalo (pip install yt-dlp) o añade una carpeta extra.", u->th.dim);
    for (int i = 0; i < n; i++) {
        SDL_Rect row = {lv.x, lv.y + i * rh - a->env_scroll, lv.w, rh};
        if (row.y + rh < lv.y || row.y > lv.y + lv.h) continue;
        bool hov = ui_hover(u, row), cur = !strcmp(c[i].path, o->ytdlp);
        if (cur) ui_rect(u, row, (SDL_Color){50, 95, 160, 255});
        else if (hov) ui_rect(u, row, u->th.btnhov);
        ui_text_clip(u, (SDL_Rect){row.x, row.y, 210, rh}, c[i].label, u->th.accent);
        ui_text_clip(u, (SDL_Rect){row.x + 214, row.y, row.w - 214 - 130, rh}, c[i].path, u->th.text);
        ui_text_clip(u, (SDL_Rect){row.x + row.w - 124, row.y, 120, rh}, c[i].ver[0] ? c[i].ver : "…", u->th.dim);
        if (hov && u->pressed) {
            safe_strlcpy(o->ytdlp, c[i].path, sizeof o->ytdlp);
            a->show_envs = false;
            toast(a, "Seleccionado: %s (pulsa «Aplicar»)", c[i].label);
        }
    }
    ui_clip(u, NULL);
    ui_border(u, lv, u->th.border);
}

static void draw_options(App *a, int W, int H, int y0) {
    UI *u = &a->ui;
    Options *o = &a->edit;                         /* el formulario edita una COPIA */
    int y = y0, fh = u->lh + 10;
    SDL_Rect r;
    UISave sv;
    if (a->show_envs) sv = ui_block(u);            /* el panel está encima: lo de debajo no reacciona */

    r = orow(a, &y, W, "Ruta de yt-dlp", W - 24 - LBLW - 130);
    int row_y = r.y;
    ui_input(u, r, o->ytdlp, sizeof o->ytdlp);
    SDL_Rect benv = {r.x + r.w + 8, r.y, 122, fh};
    bool open_env = ui_button(u, benv, "Entornos…", a->show_envs ? UI_ACTIVE : 0);
    r = orow(a, &y, W, "Directorio de salida", W - 24 - LBLW - 130);
    ui_input(u, r, o->outdir, sizeof o->outdir);
    if (ui_button(u, (SDL_Rect){r.x + r.w + 8, r.y, 122, fh}, "Abrir", 0)) open_path(o->outdir);

    r = orow(a, &y, W, "Formato de salida", 240);
    ui_cycle(u, r, FORMAT_NAMES, FORMAT_COUNT, &o->format);
    ui_text(u, 12, y + 2, "Solo audio", u->th.dim);
    ui_checkbox(u, 12 + LBLW, y + 2, "Extraer solo la pista de audio", &o->audio_only);
    y += fh + 8;

    r = orow(a, &y, W, "Descargas en paralelo", 34);
    if (ui_button(u, r, "-", 0) && o->max_par > 1) o->max_par--;
    char nb[8];
    snprintf(nb, sizeof nb, "%d", o->max_par);
    ui_text(u, r.x + 46, r.y + 5, nb, u->th.text);
    if (ui_button(u, (SDL_Rect){r.x + 76, r.y, 34, fh}, "+", 0) && o->max_par < 8) o->max_par++;

    r = orow(a, &y, W, "Límite velocidad (1M, 500K)", 160);
    ui_input(u, r, o->rate, sizeof o->rate);
    r = orow(a, &y, W, "Plantilla de nombre (-o)", 0);
    ui_input(u, r, o->tmpl, sizeof o->tmpl);

    ui_text(u, 12, y + 2, "Incrustar", u->th.dim);
    ui_checkbox(u, 12 + LBLW, y + 2, "Miniatura", &o->thumb);
    ui_checkbox(u, 12 + LBLW + 140, y + 2, "Metadatos", &o->meta);
    y += fh + 8;

    r = orow(a, &y, W, "Proxy (http://host:puerto)", 0);
    ui_input(u, r, o->proxy, sizeof o->proxy);
    r = orow(a, &y, W, "Cookies del navegador", 240);
    ui_cycle(u, r, BROWSER_NAMES, BROWSER_COUNT, &o->browser);
    r = orow(a, &y, W, "User-Agent", 0);
    ui_input(u, r, o->ua, sizeof o->ua);
    r = orow(a, &y, W, "Rango de playlist (1:5)", 160);
    ui_input(u, r, o->playlist, sizeof o->playlist);
    r = orow(a, &y, W, "Argumentos extra", 0);
    ui_input(u, r, o->custom, sizeof o->custom);

    if (a->show_envs) ui_unblock(u, sv);
    if (open_env) {
        a->show_envs = !a->show_envs;
        YtCand tmp[1]; bool sc = false;
        if (a->show_envs && !ytscan_get(tmp, 1, &sc) && !sc) ytscan_start(o);
    }
    if (a->show_envs) draw_env_panel(a, W, H, row_y + fh + 6);

    /* barra inferior: aplicar / guardar / descartar */
    bool pending = !options_equal(&a->edit, &a->opt), unsaved = !options_equal(&a->opt, &a->saved) || !options_equal(&a->edit, &a->saved);
    int by = H - 30 - fh - 4, x = 12;
    if (ui_button(u, (SDL_Rect){x, by, 210, fh}, "Aplicar sin guardar", pending ? UI_ACTIVE : UI_DISABLED)) apply_opts(a);
    if (ui_button(u, (SDL_Rect){x + 218, by, 160, fh}, "Guardar opciones", unsaved ? 0 : UI_DISABLED)) save_opts(a);
    if (ui_button(u, (SDL_Rect){x + 386, by, 190, fh}, "Descartar cambios", pending ? 0 : UI_DISABLED)) { a->edit = a->opt; toast(a, "Cambios descartados"); }
    const char *msg = pending ? "\xE2\x97\x8F Cambios sin aplicar (no afectan a las descargas hasta pulsar Aplicar)"
                    : unsaved ? "Aplicadas pero NO guardadas: se perderán al cerrar" : "Opciones guardadas";
    ui_text(u, x + 592, by + (fh - u->lh) / 2, msg, pending || unsaved ? u->th.warn : u->th.ok);
}

/* --------------------------------------------------------------- eventos */
/* Despacho de eventos SDL mediante tabla de etiquetas (computed goto). */
static bool handle_event(App *a, SDL_Event *e) {
    static const void *const T[] = {&&ev_other, &&ev_quit, &&ev_motion, &&ev_down, &&ev_up, &&ev_wheel, &&ev_text, &&ev_key};
    UI *u = &a->ui;
    int k = 0;
    switch (e->type) {
        case SDL_QUIT: k = 1; break;
        case SDL_MOUSEMOTION: k = 2; break;
        case SDL_MOUSEBUTTONDOWN: k = 3; break;
        case SDL_MOUSEBUTTONUP: k = 4; break;
        case SDL_MOUSEWHEEL: k = 5; break;
        case SDL_TEXTINPUT: k = 6; break;
        case SDL_KEYDOWN: k = 7; break;
        default: break;
    }
    goto *T[k];
ev_quit:   return false;
ev_motion: u->mx = e->motion.x; u->my = e->motion.y; return true;
ev_down:
    if (e->button.button == SDL_BUTTON_LEFT) { u->mx = e->button.x; u->my = e->button.y; u->pressed = u->down = true; u->clicks = e->button.clicks; }
    else if (e->button.button == SDL_BUTTON_RIGHT) { u->mx = e->button.x; u->my = e->button.y; u->rpressed = true; }
    return true;
ev_up:
    if (e->button.button == SDL_BUTTON_LEFT) { u->mx = e->button.x; u->my = e->button.y; u->released = true; u->down = false; }
    return true;
ev_wheel:  u->wheel += e->wheel.y; return true;
ev_text:   strncat(u->textin, e->text.text, sizeof u->textin - strlen(u->textin) - 1); return true;
ev_key: {
    SDL_Keycode s = e->key.keysym.sym;
    bool ctl = (e->key.keysym.mod & (KMOD_CTRL | KMOD_GUI)) != 0;
    u->mod = e->key.keysym.mod;
    if (ctl && s == SDLK_v) u->paste = 1;
    else if (ctl && s == SDLK_c) u->copy = 1;
    else if (ctl && s == SDLK_x) u->cut = 1;
    else if (ctl && s == SDLK_a) u->selall = 1;
    else if (s == SDLK_BACKSPACE) u->bs++;
    else if (s == SDLK_DELETE) u->del++;
    else if (s == SDLK_LEFT) u->left++;
    else if (s == SDLK_RIGHT) u->right++;
    else if (s == SDLK_HOME) u->home++;
    else if (s == SDLK_END) u->end++;
    else if (s == SDLK_RETURN || s == SDLK_KP_ENTER) u->enter++;
    return true;
}
ev_other:  return true;
}

int main(void) {
    signal(SIGPIPE, SIG_IGN);
    App *a = (App *)safe_calloc(1, sizeof *a);
    a->autoscroll = true;
    options_defaults(&a->opt);
    settings_path(a->cfg, sizeof a->cfg);
    options_load(&a->opt, a->cfg);
    a->found = ytdlp_detect(&a->opt);
    a->edit = a->saved = a->opt;
    a->sel_row = a->log_a = a->log_b = -1;

    if (SDL_Init(SDL_INIT_VIDEO) != 0) { fprintf(stderr, "SDL_Init: %s\n", SDL_GetError()); return 1; }
    if (TTF_Init() != 0) { fprintf(stderr, "TTF_Init: %s\n", TTF_GetError()); return 1; }
    SDL_Window *win = SDL_CreateWindow("Osiris Downloader AI (C / SDL2)", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
                                       1100, 720, SDL_WINDOW_RESIZABLE);
    if (!win) { fprintf(stderr, "SDL_CreateWindow: %s\n", SDL_GetError()); return 1; }
    SDL_Renderer *ren = SDL_CreateRenderer(win, -1, SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC);
    if (!ren) ren = SDL_CreateRenderer(win, -1, SDL_RENDERER_SOFTWARE);
    if (!ren) { fprintf(stderr, "SDL_CreateRenderer: %s\n", SDL_GetError()); return 1; }
    if (!ui_init(&a->ui, ren, 15)) return 1;
    SDL_StartTextInput();

    log_push("Osiris Downloader iniciado. Configuración: %s", a->cfg);
    if (!a->found) log_push("ERROR: yt-dlp no encontrado. Instálalo o indica la ruta en Opciones.");
    else log_push("yt-dlp detectado: %s", a->opt.ytdlp);

    ytscan_start(&a->opt);                         /* escaneo de entornos en segundo plano */
    bool run = true;
    while (run) {
        SDL_Event e;
        if (SDL_WaitEventTimeout(&e, 33)) {
            do { if (!handle_event(a, &e)) run = false; } while (SDL_PollEvent(&e));
        }
        UI *u = &a->ui;
        u->ticks = SDL_GetTicks();
        schedule(a);

        SDL_SetRenderDrawColor(ren, u->th.bg.r, u->th.bg.g, u->th.bg.b, 255);
        SDL_RenderClear(ren);
        int W, H;
        SDL_GetRendererOutputSize(ren, &W, &H);
        int tb = u->lh + 4;                          /* barra superior compacta */
        ui_rect(u, (SDL_Rect){0, 0, W, tb + 6}, u->th.panel);
        ui_text(u, 12, 3 + (tb - u->lh) / 2, "Osiris Downloader AI", u->th.accent);
        const char *names[3] = {"Descargas", "Registro", options_equal(&a->edit, &a->opt) ? "Opciones" : "Opciones \xE2\x97\x8F"};
        for (int t = 0; t < 3; t++)
            if (ui_button(u, (SDL_Rect){250 + t * 118, 3, 110, tb}, names[t], a->tab == t ? UI_ACTIVE : 0)) {
                if (a->tab != t) { a->tab = t; u->focus = 0; a->show_envs = false; }
            }
        int y0 = tb + 6 + 8;
        switch (a->tab) {
            case TAB_DL:  draw_downloads(a, W, H, y0); break;
            case TAB_LOG: draw_log(a, W, H, y0); break;
            default:      draw_options(a, W, H, y0); break;
        }
        int q = 0, r = 0, d = 0, er = 0;
        for (int i = 0; i < a->ndl; i++) {
            switch (dl_state(a->dl[i])) {
                case DL_QUEUED: q++; break; case DL_RUNNING: r++; break;
                case DL_DONE: d++; break; case DL_ERROR: er++; break; default: break;
            }
        }
        char sb[200];
        snprintf(sb, sizeof sb, "En cola: %d   Activas: %d   Completadas: %d   Errores: %d", q, r, d, er);
        ui_text(u, 12, H - u->lh - 6, sb, u->th.dim);
        if (SDL_GetTicks() < a->toast_until) {
            int tw = ui_text_w(u, a->toast);
            ui_rect(u, (SDL_Rect){W - tw - 36, H - u->lh - 14, tw + 24, u->lh + 10}, u->th.btnhov);
            ui_text(u, W - tw - 24, H - u->lh - 9, a->toast, u->th.text);
        }
        SDL_RenderPresent(ren);
        ui_end(u);
    }

    for (int i = 0; i < a->ndl; i++) dl_cancel(a->dl[i]);
    for (int i = 0; i < a->ndl; i++) dl_free(a->dl[i]);
    safe_free(&a->dl);               /* las opciones solo se guardan con «Guardar opciones» */
    ui_shutdown(&a->ui);
    SDL_DestroyRenderer(ren);
    SDL_DestroyWindow(win);
    TTF_Quit();
    SDL_Quit();
    safe_free(&a);
    return 0;
}
